<?php

namespace App\Http\Controllers;

use App\Http\Requests\Auth\RegisterUserRequest;
use Carbon\Carbon;
use App\Models\User;
use Tymon\JWTAuth\Facades\JWTAuth;
use App\Http\Controllers\Controller;
use App\Repositories\UserRepository;
use Illuminate\Support\Facades\Auth;
use App\Http\Requests\Auth\AuthUserRequest;
use App\Http\Requests\User\StoreUserRequest;

class AuthController extends Controller
{
    /**
     * Create a new AuthController instance.
     *
     * @return void
     */
    private $userRepository;
    public function __construct(UserRepository $userRepository)
    {
        $this->middleware('auth:api', ['except' => ['login', 'register']]);
        $this->userRepository = $userRepository;
    }

    /**
     * Get a JWT via given credentials.
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function login(AuthUserRequest $request)
    {
        $credentials = $request->only('username', 'password');
        $rememberMe = $request->input('remember');

        if ($rememberMe == 'false' || $rememberMe == null) {
            $ttl = 60;
        } else {
            $ttl = 20160;
        }

        $token = auth()->setTTL($ttl)->attempt($credentials);

        if (!$token) {
            return response()->json([
                'status' => false,
                'code' => 200,
                'message' => 'Username / password salah'
            ]);
        }

        return $this->respondWithToken($token, $ttl);
    }

    public function register(RegisterUserRequest $request)
    {
        return $this->userRepository->register($request)->toJson();
    }

    public function sendCode()
    {
        return $this->userRepository->sendCode()->toJson();
    }
    public function verifCode()
    {
        return $this->userRepository->verifCode(request())->toJson();
    }

    /**
     * Get the authenticated User.
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function me()
    {
        $user = User::with([
            'roles:id,name',
            'roles.permissions:id,name,model_name',
            'ident'
        ])->where('id', auth()->user()->id)->first();
        return response()->json($user);
    }

    /**
     * Log the user out (Invalidate the token).
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function logout()
    {
        auth()->logout();

        return response()->json(['message' => 'Successfully logged out']);
    }

    /**
     * Refresh a token.
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function refresh()
    {
        return $this->respondWithToken(auth()->refresh());
    }

    /**
     * Get the token array structure.
     *
     * @param  string $token
     *
     * @return \Illuminate\Http\JsonResponse
     */
    protected function respondWithToken($token, $ttl = 60)
    {
        return response()->json([
            'access_token' => $token,
            'token_type' => 'bearer',
            'expires_in' => auth()->factory()->getTTL() * $ttl
        ]);
    }
}