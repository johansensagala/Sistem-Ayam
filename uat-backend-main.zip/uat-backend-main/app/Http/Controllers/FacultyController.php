<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Repositories\FacultyRepository;
use App\Http\Resources\FacultyResource;
use App\Http\Requests\Faculty\UpdateFacultyRequest;
use App\Http\Requests\Faculty\StoreFacultyRequest;
use App\Models\Faculty;

class FacultyController extends Controller
{

    /**
     * For identity menu dashboard active
     *
     * @var [string]
     */
    private $facultyRepository;

    public function __construct(FacultyRepository $facultyRepository)
    {
        $this->facultyRepository = $facultyRepository;
    }

    /**
     * Display a listing of the resource.
     *
     * @return mixed|\Illuminate\Contracts\View\View
     */
    public function index(Request $request)
    {
        $result = $this->facultyRepository->filter($request->all())->toJson();
        // return $result;
        return FacultyResource::paginateCollection($result);
    }

    public function trashed(Request $request)
    {
        $result = $this->facultyRepository->trashed($request->all())->toJson();
        // return $result;
        return FacultyResource::paginateCollection($result);
    }

    public function show($id)
    {
        $result = $this->facultyRepository->findOrFail($id)->toJson();
        // return $result;
        return FacultyResource::otherCollection($result);
    }

    public function store(StoreFacultyRequest $request)
    {
        $result = $this->facultyRepository->create($request)->toJson();
         // return $result;
        return FacultyResource::otherCollection($result);
    }

      public function update(UpdateFacultyRequest $request, $id)
    {
        $result = $this->facultyRepository->update($id, $request)->toJson();
        return FacultyResource::otherCollection($result);
    }

    public function delete($id)
    {
        return $this->facultyRepository->delete($id)->toJson();
    }
    public function forceDelete($id)
    {
        return $this->facultyRepository->forceDelete($id)->toJson();
    }
    public function restore($id)
    {
        return $this->facultyRepository->restore($id)->toJson();
    }
}
