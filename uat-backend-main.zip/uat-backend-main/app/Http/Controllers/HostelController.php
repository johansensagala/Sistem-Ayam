<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Repositories\HostelRepository;
use App\Http\Resources\DefaultResource;
use App\Http\Requests\Hostel\UpdateHostelRequest;
use App\Http\Requests\Hostel\StoreHostelRequest;
use App\Models\Hostel;

class HostelController extends Controller
{

    /**
     * For identity menu dashboard active
     *
     * @var [string]
     */
    private $hostelRepository;

    public function __construct(HostelRepository $hostelRepository)
    {
        $this->hostelRepository = $hostelRepository;
    }

    /**
     * Display a listing of the resource.
     *
     * @return mixed|\Illuminate\Contracts\View\View
     */
    public function index(Request $request)
    {
        $result = $this->hostelRepository->filter($request->all())->toJson();
        // return $result;
        return DefaultResource::paginateCollection($result);
    }

    public function trashed(Request $request)
    {
        $result = $this->hostelRepository->trashed($request->all())->toJson();
        // return $result;
        return DefaultResource::paginateCollection($result);
    }

    public function show($id)
    {
        $result = $this->hostelRepository->findOrFail($id)->toJson();
        // return $result;
        return DefaultResource::otherCollection($result);
    }

    public function store(StoreHostelRequest $request)
    {
        $result = $this->hostelRepository->create($request)->toJson();
        // return $result;
        return DefaultResource::otherCollection($result);
    }

    public function update(UpdateHostelRequest $request, $id)
    {
        $result = $this->hostelRepository->update($id, $request)->toJson();
        return DefaultResource::otherCollection($result);
    }

    public function delete($id)
    {
        return $this->hostelRepository->delete($id)->toJson();
    }
    public function forceDelete($id)
    {
        return $this->hostelRepository->forceDelete($id)->toJson();
    }
    public function restore($id)
    {
        return $this->hostelRepository->restore($id)->toJson();
    }
}
