<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Repositories\MajorRepository;
use App\Http\Resources\MajorResource;
use App\Http\Requests\Major\UpdateMajorRequest;
use App\Http\Requests\Major\StoreMajorRequest;
use App\Models\Major;

class MajorController extends Controller
{

    /**
     * For identity menu dashboard active
     *
     * @var [string]
     */
    private $majorRepository;

    public function __construct(MajorRepository $majorRepository)
    {
        $this->majorRepository = $majorRepository;
    }

    /**
     * Display a listing of the resource.
     *
     * @return mixed|\Illuminate\Contracts\View\View
     */
    public function index(Request $request)
    {
        $result = $this->majorRepository->filter($request->all())->toJson();
        // return $result;
        return MajorResource::paginateCollection($result);
    }

    public function trashed(Request $request)
    {
        $result = $this->majorRepository->trashed($request->all())->toJson();
        // return $result;
        return MajorResource::paginateCollection($result);
    }

    public function show($id)
    {
        $result = $this->majorRepository->findOrFail($id)->toJson();
        // return $result;
        return MajorResource::otherCollection($result);
    }

    public function store(StoreMajorRequest $request)
    {
        $result = $this->majorRepository->create($request)->toJson();
         // return $result;
        return MajorResource::otherCollection($result);
    }

      public function update(UpdateMajorRequest $request, $id)
    {
        $result = $this->majorRepository->update($id, $request)->toJson();
        return MajorResource::otherCollection($result);
    }

    public function delete($id)
    {
        return $this->majorRepository->delete($id)->toJson();
    }
    public function forceDelete($id)
    {
        return $this->majorRepository->forceDelete($id)->toJson();
    }
    public function restore($id)
    {
        return $this->majorRepository->restore($id)->toJson();
    }
}
