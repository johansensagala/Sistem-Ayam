<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Repositories\OfferStudentRepository;
use App\Http\Resources\DefaultResource;
use App\Http\Requests\OfferStudent\UpdateOfferStudentRequest;
use App\Http\Requests\OfferStudent\StoreOfferStudentRequest;
use App\Models\OfferStudent;

class OfferStudentController extends Controller
{

    /**
     * For identity menu dashboard active
     *
     * @var [string]
     */
    private $offerStudentRepository;

    public function __construct(OfferStudentRepository $offerStudentRepository)
    {
        $this->offerStudentRepository = $offerStudentRepository;
    }

    /**
     * Display a listing of the resource.
     *
     * @return mixed|\Illuminate\Contracts\View\View
     */
    public function index(Request $request)
    {
        $result = $this->offerStudentRepository->filter($request->all())->toJson();
        // return $result;
        return DefaultResource::paginateCollection($result);
    }

    public function trashed(Request $request)
    {
        $result = $this->offerStudentRepository->trashed($request->all())->toJson();
        // return $result;
        return DefaultResource::paginateCollection($result);
    }

    public function show($id)
    {
        $result = $this->offerStudentRepository->findOrFail($id)->toJson();
        // return $result;
        return DefaultResource::otherCollection($result);
    }

    public function store(StoreOfferStudentRequest $request)
    {
        $result = $this->offerStudentRepository->create($request)->toJson();
        // return $result;
        return DefaultResource::otherCollection($result);
    }

    public function update(UpdateOfferStudentRequest $request, $id)
    {
        $result = $this->offerStudentRepository->update($id, $request)->toJson();
        return DefaultResource::otherCollection($result);
    }

    public function delete($id)
    {
        return $this->offerStudentRepository->delete($id)->toJson();
    }
    public function forceDelete($id)
    {
        return $this->offerStudentRepository->forceDelete($id)->toJson();
    }
    public function restore($id)
    {
        return $this->offerStudentRepository->restore($id)->toJson();
    }
}
