<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Repositories\ParentStudentRepository;
use App\Http\Resources\ParentStudentResource;
use App\Http\Requests\ParentStudent\UpdateParentStudentRequest;
use App\Http\Requests\ParentStudent\StoreParentStudentRequest;
use App\Models\ParentStudent;

class ParentStudentController extends Controller
{

    /**
     * For identity menu dashboard active
     *
     * @var [string]
     */
    private $parentStudentRepository;

    public function __construct(ParentStudentRepository $parentStudentRepository)
    {
        $this->parentStudentRepository = $parentStudentRepository;
    }

    /**
     * Display a listing of the resource.
     *
     * @return mixed|\Illuminate\Contracts\View\View
     */
    public function index(Request $request)
    {
        $result = $this->parentStudentRepository->filter($request->all())->toJson();
        // return $result;
        return ParentStudentResource::paginateCollection($result);
    }

    public function trashed(Request $request)
    {
        $result = $this->parentStudentRepository->trashed($request->all())->toJson();
        // return $result;
        return ParentStudentResource::paginateCollection($result);
    }

    public function show($id)
    {
        $result = $this->parentStudentRepository->findOrFail($id)->toJson();
        // return $result;
        return ParentStudentResource::otherCollection($result);
    }

    public function store(StoreParentStudentRequest $request)
    {
        $result = $this->parentStudentRepository->create($request)->toJson();
         // return $result;
        return ParentStudentResource::otherCollection($result);
    }

      public function update(UpdateParentStudentRequest $request, $id)
    {
        $result = $this->parentStudentRepository->update($id, $request)->toJson();
        return ParentStudentResource::otherCollection($result);
    }

    public function delete($id)
    {
        return $this->parentStudentRepository->delete($id)->toJson();
    }
    public function forceDelete($id)
    {
        return $this->parentStudentRepository->forceDelete($id)->toJson();
    }
    public function restore($id)
    {
        return $this->parentStudentRepository->restore($id)->toJson();
    }
}
