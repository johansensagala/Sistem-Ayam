<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Repositories\PaymentRepository;
use App\Http\Resources\PaymentResource;
use App\Http\Requests\Payment\UpdatePaymentRequest;
use App\Http\Requests\Payment\StorePaymentRequest;
use App\Models\Payment;

class PaymentController extends Controller
{

    /**
     * For identity menu dashboard active
     *
     * @var [string]
     */
    private $paymentRepository;

    public function __construct(PaymentRepository $paymentRepository)
    {
        $this->paymentRepository = $paymentRepository;
    }

    /**
     * Display a listing of the resource.
     *
     * @return mixed|\Illuminate\Contracts\View\View
     */
    public function index(Request $request)
    {
        $result = $this->paymentRepository->filter($request->all())->toJson();
        // return $result;
        return PaymentResource::paginateCollection($result);
    }

    public function trashed(Request $request)
    {
        $result = $this->paymentRepository->trashed($request->all())->toJson();
        // return $result;
        return PaymentResource::paginateCollection($result);
    }

    public function show($id)
    {
        $result = $this->paymentRepository->findOrFail($id)->toJson();
        // return $result;
        return PaymentResource::otherCollection($result);
    }

    public function store(StorePaymentRequest $request)
    {
        $result = $this->paymentRepository->create($request)->toJson();
        // return $result;
        return PaymentResource::otherCollection($result);
    }

    public function update(UpdatePaymentRequest $request, $id)
    {
        $result = $this->paymentRepository->update($id, $request)->toJson();
        return PaymentResource::otherCollection($result);
    }

    public function delete($id)
    {
        return $this->paymentRepository->delete($id)->toJson();
    }
    public function forceDelete($id)
    {
        return $this->paymentRepository->forceDelete($id)->toJson();
    }
    public function restore($id)
    {
        return $this->paymentRepository->restore($id)->toJson();
    }
}
