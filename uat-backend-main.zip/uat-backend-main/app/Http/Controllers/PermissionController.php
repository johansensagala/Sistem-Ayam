<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Repositories\PermissionRepository;
use App\Http\Resources\PermissionResource;
use App\Http\Requests\Permission\UpdatePermissionRequest;
use App\Http\Requests\Permission\StorePermissionRequest;
use App\Models\Permission;

class PermissionController extends Controller
{

    /**
     * For identity menu dashboard active
     *
     * @var [string]
     */
    private $permissionRepository;

    public function __construct(PermissionRepository $permissionRepository)
    {
        $this->permissionRepository = $permissionRepository;
    }

    /**
     * Display a listing of the resource.
     *
     * @return mixed|\Illuminate\Contracts\View\View
     */
    public function index(Request $request)
    {
        $result = $this->permissionRepository->filter($request->all())->toJson();
        // return $result;
        return PermissionResource::paginateCollection($result);
    }

    public function trashed(Request $request)
    {
        $result = $this->permissionRepository->trashed($request->all())->toJson();
        // return $result;
        return PermissionResource::paginateCollection($result);
    }

    public function show($id)
    {
        $result = $this->permissionRepository->findOrFail($id)->toJson();
        // return $result;
        return PermissionResource::otherCollection($result);
    }

    public function store(StorePermissionRequest $request)
    {
        $result = $this->permissionRepository->create($request)->toJson();
         // return $result;
        return PermissionResource::otherCollection($result);
    }

      public function update(UpdatePermissionRequest $request, $id)
    {
        $result = $this->permissionRepository->update($id, $request)->toJson();
        return PermissionResource::otherCollection($result);
    }

    public function delete($id)
    {
        return $this->permissionRepository->delete($id)->toJson();
    }
    public function forceDelete($id)
    {
        return $this->permissionRepository->forceDelete($id)->toJson();
    }
    public function restore($id)
    {
        return $this->permissionRepository->restore($id)->toJson();
    }
}
