<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Repositories\RoleRepository;
use App\Http\Resources\RoleResource;
use App\Http\Requests\Role\UpdateRoleRequest;
use App\Http\Requests\Role\StoreRoleRequest;
use App\Models\Role;

class RoleController extends Controller
{

    /**
     * For identity menu dashboard active
     *
     * @var [string]
     */
    private $roleRepository;

    public function __construct(RoleRepository $roleRepository)
    {
        $this->roleRepository = $roleRepository;
    }

    /**
     * Display a listing of the resource.
     *
     * @return mixed|\Illuminate\Contracts\View\View
     */
    public function index(Request $request)
    {
        $result = $this->roleRepository->filter($request->all())->toJson();
        // return $result;
        return RoleResource::paginateCollection($result);
    }

    public function trashed(Request $request)
    {
        $result = $this->roleRepository->trashed($request->all())->toJson();
        // return $result;
        return RoleResource::paginateCollection($result);
    }

    public function show($id)
    {
        $result = $this->roleRepository->findOrFail($id)->toJson();
        // return $result;
        return RoleResource::otherCollection($result);
    }

    public function store(StoreRoleRequest $request)
    {
        $result = $this->roleRepository->create($request)->toJson();
         // return $result;
        return RoleResource::otherCollection($result);
    }

      public function update(UpdateRoleRequest $request, $id)
    {
        $result = $this->roleRepository->update($id, $request)->toJson();
        return RoleResource::otherCollection($result);
    }

    public function delete($id)
    {
        return $this->roleRepository->delete($id)->toJson();
    }
    public function forceDelete($id)
    {
        return $this->roleRepository->forceDelete($id)->toJson();
    }
    public function restore($id)
    {
        return $this->roleRepository->restore($id)->toJson();
    }
}
