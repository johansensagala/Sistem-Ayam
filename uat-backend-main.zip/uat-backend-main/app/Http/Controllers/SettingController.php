<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Repositories\SettingRepository;
use App\Http\Resources\DefaultResource;
use App\Http\Requests\Setting\UpdateSettingRequest;
use App\Http\Requests\Setting\StoreSettingRequest;
use App\Models\Setting;

class SettingController extends Controller
{

    /**
     * For identity menu dashboard active
     *
     * @var [string]
     */
    private $settingRepository;

    public function __construct(SettingRepository $settingRepository)
    {
        $this->settingRepository = $settingRepository;
    }

    /**
     * Display a listing of the resource.
     *
     * @return mixed|\Illuminate\Contracts\View\View
     */
    public function index(Request $request)
    {
        $result = $this->settingRepository->findOrFail(1)->toJson();
        // return $result;
        return DefaultResource::otherCollection($result);
    }

    public function trashed(Request $request)
    {
        $result = $this->settingRepository->trashed($request->all())->toJson();
        // return $result;
        return DefaultResource::paginateCollection($result);
    }

    public function show($id)
    {
        $result = $this->settingRepository->findOrFail($id)->toJson();
        // return $result;
        return DefaultResource::otherCollection($result);
    }

    public function store(StoreSettingRequest $request)
    {
        $result = $this->settingRepository->create($request)->toJson();
        // return $result;
        return DefaultResource::otherCollection($result);
    }

    public function update(UpdateSettingRequest $request, $id)
    {
        $result = $this->settingRepository->update($id, $request)->toJson();
        return DefaultResource::otherCollection($result);
    }

    public function delete($id)
    {
        return $this->settingRepository->delete($id)->toJson();
    }
    public function forceDelete($id)
    {
        return $this->settingRepository->forceDelete($id)->toJson();
    }
    public function restore($id)
    {
        return $this->settingRepository->restore($id)->toJson();
    }
}
