<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Repositories\TestingRepository;
use App\Http\Resources\TestingResource;
use App\Http\Requests\Testing\UpdateTestingRequest;
use App\Http\Requests\Testing\StoreTestingRequest;
use App\Models\Testing;

class TestingController extends Controller
{

    /**
     * For identity menu dashboard active
     *
     * @var [string]
     */
    private $testingRepository;

    public function __construct(TestingRepository $testingRepository)
    {
        $this->testingRepository = $testingRepository;
    }

    /**
     * Display a listing of the resource.
     *
     * @return mixed|\Illuminate\Contracts\View\View
     */
    public function index(Request $request)
    {
        $result = $this->testingRepository->testing()->toJson();
        return $result;
    }

    public function trashed(Request $request)
    {
        $result = $this->testingRepository->trashed($request->all())->toJson();
        // return $result;
        return TestingResource::paginateCollection($result);
    }

    public function show($id)
    {
        $result = $this->testingRepository->findOrFail($id)->toJson();
        // return $result;
        return TestingResource::otherCollection($result);
    }

    public function store(StoreTestingRequest $request)
    {
        $result = $this->testingRepository->create($request)->toJson();
        // return $result;
        return TestingResource::otherCollection($result);
    }

    public function update(UpdateTestingRequest $request, $id)
    {
        $result = $this->testingRepository->update($id, $request)->toJson();
        return TestingResource::otherCollection($result);
    }

    public function delete($id)
    {
        return $this->testingRepository->delete($id)->toJson();
    }
    public function forceDelete($id)
    {
        return $this->testingRepository->forceDelete($id)->toJson();
    }
    public function restore($id)
    {
        return $this->testingRepository->restore($id)->toJson();
    }
}
