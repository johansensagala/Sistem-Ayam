<?php

namespace App\Http\Resources;

use App\Traits\ApiCollectionResource;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class ParentStudentResource extends JsonResource
{
    use ApiCollectionResource;
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        $baseUrl = url('/');
        $data = parent::toArray($request);
        if (isset($data['bank_image'])) {
            $data['bank_image'] = $baseUrl . '/upload/' . $data['bank_image'];
        }
        if (isset($data['ktp_image'])) {
            $data['ktp_image'] = $baseUrl . '/upload/' . $data['ktp_image'];
        }
        if (isset($data['kk_image'])) {
            $data['kk_image'] = $baseUrl . '/upload/' . $data['kk_image'];
        }
        return $data;
    }
}
