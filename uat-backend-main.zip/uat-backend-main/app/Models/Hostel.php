<?php

namespace App\Models;

use App\Traits\BaseScope;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Hostel extends Model
{
    use HasFactory, BaseScope;

    protected $fillable = [
        'name',
        'price_hostel',
        'price_cafetaria',
    ];
}
