<?php

namespace App\Models;

use App\Traits\BaseScope;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class OfferStudent extends Model
{
    use HasFactory, BaseScope;

    protected $fillable = [
        'residence_id',
        'student_id',
        'parent_code',
        'timeline',
        'sks',
        'sub_offer',
        'total_offer',
        'status_parent',
        'status_university',
        'status_instalment'

    ];
}
