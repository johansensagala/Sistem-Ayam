<?php

namespace App\Models;

use App\Traits\BaseScope;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ParentStudent extends Model
{
    use HasFactory, BaseScope;
    protected $fillable = [
        'code',
        'company_name',
        'sallary',
        'position',
        'ktp_image',
        'bank_image',
        'kk_image',
    ];

    public function user()
    {
        return $this->morphOne(User::class, 'ident');
    }
}
