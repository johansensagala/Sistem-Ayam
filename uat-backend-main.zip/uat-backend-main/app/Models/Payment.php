<?php

namespace App\Models;

use App\Traits\BaseScope;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Payment extends Model
{
    use HasFactory, BaseScope;
    protected $fillable = [
        'offer_id',
        'total',
        'status',
        'due_date',
        'image'
    ];

    public function offer()
    {
        return $this->belongsTo(OfferStudent::class, 'offer_id', 'id');
    }
}
