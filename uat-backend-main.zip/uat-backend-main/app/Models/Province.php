<?php

namespace App\Models;

use App\Traits\BaseScope;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Province extends \Laravolt\Indonesia\Models\Province
{
    use HasFactory, BaseScope;

    public function scopeFilter(Builder $query, array $filters)
    {
        $query->when($filters['search']['name'] ?? false, function ($query, $filter) {
            return $query->where('name', 'LIKE', '%' . $filter . '%');
        });
    }
}
