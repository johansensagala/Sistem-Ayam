<?php

namespace App\Models;

use App\Traits\BaseScope;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Student extends Model
{
    use HasFactory, BaseScope;
    protected $fillable = [
        'nim',
        'major_id',
        'generation',
        'image',
    ];

    public function user()
    {
        return $this->morphOne(User::class, 'ident');
    }
}
