<?php


namespace App\Repositories;

use App\Models\ParentStudent;
use App\Traits\HasImage;
use App\Traits\ActivityLog;
use Illuminate\Support\Str;
use App\Traits\ResultService;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Validation\Rules\Exists;
use Illuminate\Pagination\LengthAwarePaginator;
use Cviebrock\EloquentSluggable\Services\SlugService;

class BaseRepository
{
    use ResultService;
    use HasImage;
    use ActivityLog;

    protected $model;
    protected $option;
    protected $title = "";
    protected $create_message = "";
    protected $update_message = "";
    protected $delete_message = "";


    public function __construct(Model $model)
    {
        $this->model = $model;
    }

    public function customPaginate($collection, $request)
    {
        $perPage = $request['limit'] ?? 5;
        $currentPage = $request['page'] ?? 1;
        $currentPageItems = $collection->slice(($currentPage - 1) * $perPage, $perPage)->all();
        $paginator = new LengthAwarePaginator($currentPageItems, count($collection), $perPage, $currentPage, [
            'path' => $request->url(),
            'query' => $request->query(),
        ]);

        return $paginator;
    }

    public function generateCode($column)
    {
        $ref = Str::random(10);
        if ($this->model->where($column, $ref)->exists()) {
            $this->generateCode($column);
        }
        return $ref;
    }

    public function generateCodeV2($code)
    {
        $inputCount = $this->model->count();
        $inputCount += 1;
        $generate = $code . '-' . str_pad($inputCount, 5, '0', STR_PAD_LEFT);

        return $generate;
    }

    public function generateParentCode()
    {
        $code = mt_rand(1000, 9999);
        $check = ParentStudent::where('code', $code)->first();
        if ($check) {
            $this->generateParentCode();
        } else {
            return $code;
        }
    }

    /**
     * Find an item by id
     * @param mixed $id
     * @return $this
     */
    public function find($id)
    {
        try {
            $result = $this->model->withTrashed()->with($this->option['with'] ?? [])->find($id);
            return $this->setResult($result)
                ->setCode(200)
                ->setStatus(true);
        } catch (\Exception $exception) {
            return $this->exceptionResponse($exception);
        }
    }

    /**
     * Find an item by id or fail
     * @param mixed $id
     * @return Model|null
     */
    public function findOrFail($id)
    {
        try {
            if (isset($this->option['trashed']) && $this->option['trashed'] == false) {
                $result = $this->model->with($this->option['with'] ?? [])->withCount($this->option['withCount'] ?? [])->findOrFail($id);
            } else {
                $result = $this->model->withTrashed()->with($this->option['with'] ?? [])->withCount($this->option['withCount'] ?? [])->findOrFail($id);

            }
            return $this->setResult($result)
                ->setCode(200)
                ->setStatus(true);
        } catch (\Exception $exception) {
            return $this->exceptionResponse($exception);
        }
    }

    /**
     * Find an item by where clouse
     * @param mixed $id
     * @return Model|null
     */
    public function whereFirst($column, $data)
    {
        try {
            $result = $this->model->with($this->option['with'] ?? [])->withCount($this->option['withCount'] ?? [])->where($column, $data)->first();
            return $this->setResult($result)
                ->setCode(200)
                ->setStatus(true);
        } catch (\Exception $exception) {
            return $this->exceptionResponse($exception);
        }
    }

    /**
     * Return all items
     * @return Collection|null
     */
    public function all()
    {
        try {
            $result = $this->model->all();
            ;
            return $this->setResult($result)
                ->setCode(200)
                ->setStatus(true);
        } catch (\Exception $exception) {
            return $this->exceptionResponse($exception);
        }
    }


    public function paginate($limit)
    {
        try {
            $result = $this->model->with($this->option['with'] ?? '')->withCount($this->option['withCount'] ?? '')->paginate($limit);
            return $this->setResult($result)
                ->setCode(200)
                ->setStatus(true);
        } catch (\Exception $exception) {
            return $this->exceptionResponse($exception);
        }
    }

    /**
     * Create an item
     * @param array|mixed $data
     * @return $this
     */
    public function create($data)
    {
        try {
            $result = $data->all();
            if ($data->userId) {
                $result['userId'] = $data->userId;
            }
            if ($data->password) {
                $result['password'] = Hash::make($data->password);
            }
            if ($data->image) {
                $result['image'] = $this->uploadImage2($data, 'image');
            }
            $this->model->create($result);
            return $this
                ->setCode(200)
                ->setStatus(true)
                ->setResult($data);
        } catch (\Exception $exception) {
            return $this->exceptionResponse($exception);
        }
    }

    public function filter($data)
    {
        $limitIdent = $data['limit'] ?? '5';
        $limit = $limitIdent < 1 ? PHP_INT_MAX : $limitIdent;
        // $data['guest'] = auth()->user()->admin == 0 ? true : false;
        try {

            $result = $this->model->with($this->option['with'] ?? [])->withCount($this->option['withCount'] ?? [])->filter($data)->orderBy('id', 'desc')->paginate($limit);


            return $this->setCode(200)
                ->setStatus(true)
                ->setResult($result);
        } catch (\Exception $exception) {
            return $this->exceptionResponse($exception);
        }
    }

    public function trashed($data)
    {
        $limitIdent = $data['limit'] ?? '5';
        $limit = $limitIdent < 1 ? PHP_INT_MAX : $limitIdent;
        // $data['guest'] = auth()->user()->admin == 0 ? true : false;
        try {

            $result = $this->model->onlyTrashed()->with($this->option['with'] ?? [])->withCount($this->option['withCount'] ?? [])->filter($data)->orderBy('id', 'desc')->paginate($limit);


            return $this->setCode(200)
                ->setStatus(true)
                ->setResult($result);
        } catch (\Exception $exception) {
            return $this->exceptionResponse($exception);
        }
    }

    public function filterWithOutPaginate($data)
    {
        try {
            $result = $this->model->latest()->filter($data)->get();
            return $this->setCode(200)
                ->setStatus(true)
                ->setResult($result);
        } catch (\Exception $exception) {
            return $this->exceptionResponse($exception);
        }
    }

    /**
     * Update a model
     * @param int|mixed $id
     * @param array|mixed $data
     * @return bool|mixed
     */
    public function update($id, $data)
    {
        try {
            $source = $this->model->findOrFail($id);
            $result = $data->all();
            if ($data->image) {
                $this->deleteImage($source->image);
                $result['image'] = $this->uploadImage($data);
            }

            $source->update($result);
            return $this
                ->setCode(200)
                ->setStatus(true)
                ->setResult($source);
        } catch (\Exception $exception) {
            return $this->exceptionResponse($exception);
        }
    }

    public function storeConfiguration($key, $value)
    {
        $path = base_path('.env');

        if (file_exists($path)) {

            file_put_contents(
                $path,
                str_replace(
                    $key . '=' . env($key),
                    $key . '=' . $value,
                    file_get_contents($path)
                )
            );
        }
    }

    /**
     * Delete a model
     * @param int|Model $id
     */
    public function delete($id)
    {
        try {
            $result = $this->model->findOrFail($id);
            if ($result) {
                $this->model->destroy($id);
            }
            return $this
                ->setCode(200)
                ->setStatus(true)
                ->setMessage('Data has been deleted');
        } catch (\Exception $exception) {
            return $this->exceptionResponse($exception);
        }
    }
    public function forceDelete($id)
    {
        try {
            $result = $this->model->withTrashed()->findOrFail($id);
            if ($result) {
                $result->forceDelete();
            }
            return $this
                ->setCode(200)
                ->setStatus(true)
                ->setMessage('Data has been deleted');
        } catch (\Exception $exception) {
            return $this->exceptionResponse($exception);
        }
    }
    public function restore($id)
    {
        try {
            $result = $this->model->withTrashed()->findOrFail($id);
            if ($result) {
                $result->restore();
            }
            return $this
                ->setCode(200)
                ->setStatus(true)
                ->setMessage('Data has been restore');
        } catch (\Exception $exception) {
            return $this->exceptionResponse($exception);
        }
    }

    /**
     * multiple delete
     * @param array $id
     * @return mixed
     */
    public function destroy(array $id)
    {
        try {
            $this->model->destroy($id);
            return $this
                ->setCode(200)
                ->setStatus(true);
        } catch (\Exception $exception) {
            return $this->exceptionResponse($exception);
        }
    }
}
