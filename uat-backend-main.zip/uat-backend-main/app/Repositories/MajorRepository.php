<?php

namespace App\Repositories;

use App\Models\Major;

class MajorRepository extends BaseRepository
{

    /**
     * Model class to be used in this repository for the common methods inside Eloquent
     * Don't remove or change $this->model variable name
     * @property Model|mixed $model;
     */
    protected $model;

    public function __construct(Major $model)
    {
        $this->model = $model;
        $this->option['with'] = [
            'faculty:id,name'
        ];
    }

    // Write something awesome :)
}
