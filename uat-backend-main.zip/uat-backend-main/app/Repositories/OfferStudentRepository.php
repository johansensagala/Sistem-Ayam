<?php

namespace App\Repositories;

use Carbon\Carbon;
use App\Models\Payment;
use App\Models\OfferStudent;
use App\Models\ParentStudent;
use Illuminate\Support\Facades\DB;

class OfferStudentRepository extends BaseRepository
{

    /**
     * Model class to be used in this repository for the common methods inside Eloquent
     * Don't remove or change $this->model variable name
     * @property Model|mixed $model;
     */
    protected $model;

    public function __construct(OfferStudent $model)
    {
        $this->model = $model;
    }

    public function create($data)
    {
        DB::beginTransaction();
        try {
            $result = $data->all();
            $result['student_id'] = auth()->user()->ident_id;
            $result['parent_code'] = auth()->user()->ident->parent_code;
            $offer = $this->model->create($result);
            if (!$result['status_installment']) {
                $dateToday = Carbon::now()->toDateString();
                $dateIn30Days = Carbon::now()->addDays(30)->toDateString();
                // $result['due_date'] = $dateIn30Days;

                $payment = Payment::create([
                    'offer_id' => $offer->id,
                    'total' => $result['total_offer'],
                    'due_date' => $dateIn30Days
                ]);
            } else {
                // for ($i = 0; $i < (int) $result['timeline']; $i++) {
                //     $dateIn30Days = Carbon::now()->addDays(((int) $result['timeline'] * $i) + 1)->toDateString();
                //     $payment = Payment::create([
                //         'offer_id' => $offer->id,
                //         'total' => $result['sub_offer'],
                //         'due_date' => $dateIn30Days
                //     ]);
                // }
            }
            // $check = ParentStudent::where('code', $data->parent_code)->first();
            // if (!$check) {
            //     throw new \Exception('Code orang tua tidak ada');
            // }
            DB::commit();
            return $this
                ->setCode(200)
                ->setStatus(true)
                ->setResult($data);
        } catch (\Exception $exception) {
            DB::rollBack();
            return $this->exceptionResponse($exception);
        }
    }

    public function filter($data)
    {
        $limitIdent = $data['limit'] ?? '5';
        $limit = $limitIdent < 1 ? PHP_INT_MAX : $limitIdent;
        // $data['guest'] = auth()->user()->admin == 0 ? true : false;
        try {
            $user = auth()->user();
            if ($user->hasRole('student')) {
                $result = $this->model->where('student_id', $user->ident_id);
            }
            if ($user->hasRole('superadmin')) {
                $result = $this->model;
            }
            if ($user->hasRole('parent')) {
                $result = $this->model->where('parent_code', $user->ident->code);
            }
            $result = $result->where('status_instalment', 1)->with($this->option['with'] ?? [])->withCount($this->option['withCount'] ?? [])->filter($data)->orderBy('id', 'desc')->paginate($limit);

            return $this->setCode(200)
                ->setStatus(true)
                ->setResult($result);
        } catch (\Exception $exception) {
            return $this->exceptionResponse($exception);
        }
    }

    // Write something awesome :)
}
