<?php

namespace App\Repositories;

use App\Models\User;
use App\Models\ParentStudent;

class ParentStudentRepository extends BaseRepository
{

    /**
     * Model class to be used in this repository for the common methods inside Eloquent
     * Don't remove or change $this->model variable name
     * @property Model|mixed $model;
     */
    protected $model;

    public function __construct(ParentStudent $model)
    {
        $this->model = $model;
        $this->option['trashed'] = false;
    }

    // Write something awesome :)
    public function update($id, $data)
    {
        try {
            $source = $this->model->findOrFail($id);
            $user = User::where('id', auth()->user()->id)->first();
            $user->name = $data->name;
            $user->username = $data->username;
            $user->phone = $data->phone;
            $user->save();
            $result = $data->all();
            if ($data->bank_image) {
                $this->deleteImage($source->bank_image);
                $result['bank_image'] = $this->uploadImage2($data, 'bank_image');
            }
            if ($data->ktp_image) {
                $this->deleteImage($source->ktp_image);
                $result['ktp_image'] = $this->uploadImage2($data, 'ktp_image');
            }
            if ($data->kk_image) {
                $this->deleteImage($source->kk_image);
                $result['kk_image'] = $this->uploadImage2($data, 'kk_image');
            }

            $source->update($result);
            return $this
                ->setCode(200)
                ->setStatus(true)
                ->setResult($source);
        } catch (\Exception $exception) {
            return $this->exceptionResponse($exception);
        }
    }
}
