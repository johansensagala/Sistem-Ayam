<?php

namespace App\Repositories;

use App\Models\Payment;

class PaymentRepository extends BaseRepository
{

    /**
     * Model class to be used in this repository for the common methods inside Eloquent
     * Don't remove or change $this->model variable name
     * @property Model|mixed $model;
     */
    protected $model;

    public function __construct(Payment $model)
    {
        $this->model = $model;
        $this->option['trashed'] = false;
        $this->option['with'] = [
            'offer'
        ];
    }

    public function update($id, $data)
    {
        try {
            $source = $this->model->findOrFail($id);
            $result = $data->all();
            if (isset($data->role) && $data->role == 'student') {
                if ($data->image) {
                    if ($source->image) {
                        $this->deleteImage($source->image);
                    }
                    $result['image'] = $this->uploadImage($data);
                }
                $result['status'] = 'CHECK';
            }
            if (isset($data->role) && $data->role == 'superadmin') {
                if ($data->status !== 'CANCEL') {
                    $result['status'] = 'SUCCESS';
                } else {
                    $result['status'] = 'PAY';
                }
            }

            $source->update($result);
            return $this
                ->setCode(200)
                ->setStatus(true)
                ->setResult($source);
        } catch (\Exception $exception) {
            return $this->exceptionResponse($exception);
        }
    }

    // Write something awesome :)
}
