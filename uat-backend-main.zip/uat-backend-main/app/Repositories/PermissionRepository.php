<?php

namespace App\Repositories;

use App\Models\Permission;

class PermissionRepository extends BaseRepository
{

    /**
     * Model class to be used in this repository for the common methods inside Eloquent
     * Don't remove or change $this->model variable name
     * @property Model|mixed $model;
     */
    protected $model;

    public function __construct(Permission $model)
    {
        $this->model = $model;
    }

    public function filter($data)
    {
        $limitIdent = $data['limit'] ?? '5';
        $limit = $limitIdent < 1 ? PHP_INT_MAX : $limitIdent;
        // $data['guest'] = auth()->user()->admin == 0 ? true : false;
        try {

            $result = $this->model->with($this->option['with'] ?? [])->withCount($this->option['withCount'] ?? [])->filter($data)->orderBy('name', 'asc')->paginate($limit);


            return $this->setCode(200)
                ->setStatus(true)
                ->setResult($result);
        } catch (\Exception $exception) {
            return $this->exceptionResponse($exception);
        }
    }

    public function create($data)
    {
        try {
            $result = $data->all();
            $user = $this->model->create($result);

            return $this
                ->setCode(200)
                ->setStatus(true)
                ->setResult($user);
        } catch (\Exception $e) {
            return $this->exceptionResponse($e);
        }
    }

    // Write something awesome :)
}
