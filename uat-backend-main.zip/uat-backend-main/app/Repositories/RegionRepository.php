<?php

namespace App\Repositories;

use App\Models\City;
use App\Models\Region;
use App\Models\District;
use App\Models\Province;

class RegionRepository extends BaseRepository
{

    /**
     * Model class to be used in this repository for the common methods inside Eloquent
     * Don't remove or change $this->model variable name
     * @property Model|mixed $model;
     */
    protected $model;
    public function __construct(Region $model)
    {
        $this->model = $model;
    }
    public function province($data)
    {
        $limitIdent = $data['limit'] ?? '5';
        $limit = $limitIdent < 1 ? PHP_INT_MAX : $limitIdent;
        try {
            $result = Province::filter($data)->orderBy('name', 'asc')->paginate($limit);
            return $this
                ->setResult($result)
                ->setCode(200)
                ->setStatus(true);
        } catch (\Exception $exception) {
            return $this->exceptionResponse($exception);
        }
    }
    public function cities($data)
    {
        $limitIdent = $data['limit'] ?? '5';
        $limit = $limitIdent < 1 ? PHP_INT_MAX : $limitIdent;
        try {
            $result = City::whereHas('provinces', function ($query) use ($data) {
                $query->where('id', $data['id']);
            })->filter($data)->orderBy('name', 'asc')->paginate($limit);
            return $this
                ->setResult($result)
                ->setCode(200)
                ->setStatus(true);
        } catch (\Exception $exception) {
            return $this->exceptionResponse($exception);
        }
    }

    public function districts($data)
    {
        $limitIdent = $data['limit'] ?? '5';
        $limit = $limitIdent < 1 ? PHP_INT_MAX : $limitIdent;
        try {
            $result = City::with(['districts'])->filter($data)->where('id', $data['id'])
                ->first()->districts()->orderBy('name', 'asc')->select('id', 'name')->paginate($limit);
            return $this
                ->setResult($result)
                ->setCode(200)
                ->setStatus(true);
        } catch (\Exception $exception) {
            return $this->exceptionResponse($exception);
        }
    }

    public function villages($data)
    {
        $limitIdent = $data['limit'] ?? '5';
        $limit = $limitIdent < 1 ? PHP_INT_MAX : $limitIdent;
        try {
            $result = District::with(['villages'])->filter($data)->where('id', $data['id'])
                ->first()->villages()->orderBy('name', 'asc')->select('id', 'name')->paginate($limit);
            return $this
                ->setResult($result)
                ->setCode(200)
                ->setStatus(true);
        } catch (\Exception $exception) {
            return $this->exceptionResponse($exception);
        }
    }
    // Write something awesome :)
}
