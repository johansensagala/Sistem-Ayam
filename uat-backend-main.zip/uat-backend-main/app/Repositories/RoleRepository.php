<?php

namespace App\Repositories;

use App\Models\Role;
use Spatie\Permission\Models\Permission;



class RoleRepository extends BaseRepository
{

    /**
     * Model class to be used in this repository for the common methods inside Eloquent
     * Don't remove or change $this->model variable name
     * @property Model|mixed $model;
     */
    protected $model;
    protected $permissionRepository;

    public function __construct(Role $model, PermissionRepository $permissionRepository)
    {
        $this->model = $model;
        $this->permissionRepository = $permissionRepository;
    }



    public function givePermission($request, $id)
    {
        try {
            $role = $this->model->find($id);
            if (!$role) {
                throw new \Exception("Role not exist");
            }
            $notExistPermission = [];
            $existPermission = [];
            $countPermission = $request['permission'];
            for ($i = 0; $i < count($request['permission']); $i++) {

                $permission = Permission::where('name', $request['permission'][$i]['name'])->first();
                if (!$permission) {
                    $notExistPermission[] = $request['permission'][$i]['name'];
                } else {
                    $existPermission[] = $request['permission'][$i]['name'];
                    $role->givePermissionTo($request['permission'][$i]['name']);
                }
            }
            $result = [
                'success' => $existPermission,
                'failed' => $notExistPermission
            ];
            return $this
                ->setCode(200)
                ->setStatus(true)
                ->setResult($result);
            // ->setResult($request['permission'][0]);
        } catch (\Exception $e) {
            return $this->exceptionResponse($e);
        }
    }
    // Write something awesome :)
}
