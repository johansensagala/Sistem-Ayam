<?php

namespace App\Repositories;

use App\Models\Vendor;
use App\Models\Testing;
use Illuminate\Support\Facades\DB;

class TestingRepository extends BaseRepository
{

    /**
     * Model class to be used in this repository for the common methods inside Eloquent
     * Don't remove or change $this->model variable name
     * @property Model|mixed $model;
     */
    protected $model;

    public function __construct(Testing $model)
    {
        $this->model = $model;
    }

    public function testing()
    {
        DB::beginTransaction();
        try {
            $vendor = Vendor::with('materialVendors')->whereHas('materialVendors')->get()->random();
            $take = rand(1, 4);
            $materials = collect($vendor->materialVendors)->random($take);
            $detail = [];
            $realTotal = 0;
            for ($i = 0; $i < count($materials); $i++) {
                $count = rand(1, 4);
                $total = $count * $materials[$i]['price'];
                $realTotal = $realTotal + $total;
                $detail[$i] = [
                    'material_vendor_id' => $materials[$i]['id'],
                    'total' => $count,
                    'price' => $total
                ];
            }

            $result = [
                'materials' => $materials,
                'detail' => $detail,
                'realTotal' => $realTotal,
            ];
            DB::commit();
            return $this
                ->setCode(200)
                ->setStatus(true)
                ->setResult($result);
        } catch (\Exception $exception) {
            DB::rollBack();
            return $this->exceptionResponse($exception);
        }
    }
    // Write something awesome :)
}
