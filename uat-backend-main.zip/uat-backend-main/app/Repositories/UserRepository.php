<?php

namespace App\Repositories;

use App\Models\User;
use App\Models\Student;
use App\Models\ParentStudent;
use App\Models\CodeVerification;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;

class UserRepository extends BaseRepository
{

    /**
     * Model class to be used in this repository for the common methods inside Eloquent
     * Don't remove or change $this->model variable name
     * @property Model|mixed $model;
     */
    protected $model;

    public function __construct(User $model)
    {
        $this->model = $model;
        $this->option['with'] = [
            'roles:id,name',
            'roles.permissions',
            'ident'
        ];
    }

    public function create($data)
    {
        try {
            $result = $data->all();
            if ($data->role == 'student') {
                $ident = Student::factory()->create();
                $result['ident_id'] = $ident->id;
                $result['ident_type'] = 'App\\Models\\Student';
                $result['status'] = 1;
            }
            if ($data->role == 'parent') {
                $ident = ParentStudent::factory()->create();
                $result['ident_id'] = $ident->id;
                $result['ident_type'] = 'App\\Models\\ParentStudent';
                $result['status'] = 1;
            }
            if (auth()->user() && auth()->user()->hasRole('superadmin')) {
                $result['password'] = bcrypt('password');
            }
            $this->model->create($result);
            return $this
                ->setCode(200)
                ->setStatus(true)
                ->setResult($data);
        } catch (\Exception $exception) {
            return $this->exceptionResponse($exception);
        }
    }

    public function register($data)
    {
        DB::beginTransaction();
        try {
            $result = $data->all();
            $code = $this->generateParentCode();
            $parent = ParentStudent::create([
                'code' => $code
            ]);
            $result['ident_id'] = $parent->id;
            $result['ident_type'] = 'App\\Models\\ParentStudent';
            $result['passowrd'] = bcrypt($data->password);
            $user = $this->model->create($result);
            $user->syncRoles('parent');
            DB::commit();
            return $this
                ->setCode(200)
                ->setStatus(true)
                ->setResult($data);
        } catch (\Exception $exception) {
            DB::rollBack();
            return $this->exceptionResponse($exception);
        }
    }

    public function sendCode()
    {
        try {
            CodeVerification::create([
                'user_id' => auth()->user()->id,
                'code' => mt_rand(1000, 9999)
            ]);

            return $this
                ->setCode(200)
                ->setStatus(true)
                ->setResult('Code telah dikirimkan');
        } catch (\Exception $e) {
            return $this->exceptionResponse($e);
        }
    }
    public function verifCode($data)
    {
        try {
            $check = CodeVerification::where('user_id', auth()->user()->id)->orderBy('id', 'desc')->first();
            if ($check->code == $data->code) {
                $check->status = 1;
                $check->save();
                $user = User::where('id', auth()->user()->id)->first();
                $user->status = 1;
                $user->save();
                return $this
                    ->setCode(200)
                    ->setStatus(true)
                    ->setResult('Akun anda sudah aktif');
            } else {
                throw new \Exception('Code salah');
            }
            // return $this
            //     ->setCode(200)
            //     ->setStatus(true)
            //     ->setResult('');
        } catch (\Exception $e) {
            return $this->exceptionResponse($e);
        }
    }

    public function updateParentCode($id, $data)
    {
        try {
            $source = $data->all();
            $check = ParentStudent::where('code', $data->parent_code)->first();
            if (!$check) {
                throw new \Exception('Code orang tua tidak ada');
            }
            $student = Student::where('id', $id)->first();
            $student->parent_code = $data->parent_code;
            $student->save();
            return $this
                ->setCode(200)
                ->setStatus(true)
                ->setResult('');
        } catch (\Exception $e) {
            return $this->exceptionResponse($e);
        }
    }

    public function findOrFail($id)
    {
        try {
            $user = User::where('id', auth()->user()->id)->first();
            $result = ParentStudent::where('id', $user->ident_id)->first();
            return $this->setResult($result)
                ->setCode(200)
                ->setStatus(true);
        } catch (\Exception $exception) {
            return $this->exceptionResponse($exception);
        }
    }
    // Write something awesome :)
}
