<?php

namespace App\Repositories;

use App\Models\Unit;
use App\Models\Material;
use App\Models\VariantMaterial;
use App\Models\CategoryMaterial;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;
use App\Models\CategoryVariantMaterial;

class MaterialRepository extends BaseRepository
{

    /**
     * Model class to be used in this repository for the common methods inside Eloquent
     * Don't remove or change $this->model variable name
     * @property Model|mixed $model;
     */
    protected $model;

    public function __construct(Material $model)
    {
        $this->model = $model;
        $this->option['with'] = [
            'categoryMaterials:id,name',
            'units:id,name',
            'entryMaterials:id,name,category_variant_material_id',
            'entryMaterials.categoryVariantMaterials:id,name',
        ];
        $this->option['unset'] = [
            'updated_at',
            'created_at',
            'unit_id',
            'category_material_id',
        ];
    }

    public function create($data)
    {
        try {
            DB::beginTransaction();
            $material = $data->except('variant');
            $material['code'] = $this->generateCodeV2('MT');
            $countMaterial = $this->model->count();
            // $materialCreated = $this->model->create($material);

            $entryExists = false;
            $test1 = '';
            $test2 = '';
            $test3 = '';
            $existingEntries = Material::where('category_material_id', $data->category_material_id)
                ->whereHas('entrys', function ($query) use ($data) {
                    $query->whereIn('entry_variant_id', $data->variant);
                })->get();
            foreach ($existingEntries as $existingEntry) {
                // Mengambil semua entry_variant_id untuk entri saat ini
                $existingVariants = $existingEntry->entrys()->pluck('entry_variant_id')->toArray();
                $new = new Collection($data->variant);
                $check = array_diff($existingVariants, $data->variant);
                $test1 = json_encode($data->variant);
                $test2 = json_encode($existingVariants);
                $test3 = json_encode($check);
                // Memeriksa apakah inputEntryVariantId adalah subset dari existingVariants
                if ($check === array()) {
                    // Jika inputEntryVariantId adalah subset dari existingVariants, maka entri sudah ada
                    $test1 = array_values($data->variant);
                    $test2 = json_encode($existingVariants);
                    $test3 = json_encode($check);
                    throw new \Exception(json_encode($new->toArray()) . ' ' . json_encode($existingVariants) . ' ' . json_encode($check));


                    $entryExists = true;
                    break;
                }
            }
            // $checker = VariantMaterial::where('category_material_id', $data->category_material_id)->whereIn('entry_variant_id', $data->variant)->get();
            // $checker = VariantMaterial::whereHas('materials', function ($query) use ($data) {
            //     $query->where('category_material_id', $data->category_material_id);
            // })->whereIn('entry_variant_id', $data->variant)->get();
            // $checkerCount = $checker->count();
            // $variantCount = count($data->variant);
            if ($entryExists) {
                throw new \Exception('3');
            }
            $variant = $data->variant;
            // if ($variant) {
            //     foreach ($variant as $variant) {
            //         VariantMaterial::create([
            //             'material_id' => $materialCreated->id,
            //             'entry_variant_id' => $variant,
            //             'category_material_id' => $data->category_material_id
            //         ]);
            //     }
            // }
            // $result = new Collection($materialCreated->load($this->option['with']));
            // $result->forget($this->option['unset']);
            // $this->activity(
            //     'created',
            //     $this->model,
            //     $materialCreated->id,
            //     $result

            // );
            DB::commit();
            return $this
                ->setCode(200)
                ->setStatus(true)
                ->setResult($test1 . $test2 . $test3);
        } catch (\Exception $exception) {
            DB::rollBack();
            return $this->exceptionResponse($exception);
        }
    }

    public function component()
    {
        try {
            $unit = Unit::select('id', 'name')->orderBy('id', 'desc')->get();
            $cM = CategoryMaterial::select('id', 'name')->orderBy('id', 'desc')->get();
            $cV = CategoryVariantMaterial::select('id', 'name')->with('entryVariantMaterials:id,name,category_variant_material_id')->orderBy('id', 'desc')->get();
            $result = [
                'unit' => $unit,
                'categoryMaterial' => $cM,
                'categoryVariant' => $cV
            ];
            return $this->setCode(200)
                ->setStatus(true)
                ->setResult($result);

        } catch (\Exception $e) {
            return $this->exceptionResponse(e);
        }
    }

    // Write something awesome :)
}
