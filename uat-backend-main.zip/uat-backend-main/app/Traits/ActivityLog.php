<?php
namespace App\Traits;

use App\Models\Log;
use DateTimeInterface;
use Illuminate\Support\Collection;

trait ActivityLog
{
    protected function activity($log_name = 'default', $model_name, $model_id, $properties, $description = '', $edit = false, $properties_old = null)
    {

        if ($edit) {
            $properties_activity = [
                'attributes' => $properties,
                'old' => $properties_old
            ];
        } else {
            $properties_activity = [
                'attributes' => $properties
            ];
        }

        Log::create([
            'log_name' => 'default',
            'model_name' => 'default',
            'model_id' => 1,
            'user_id' => auth()->user()->id,
            'properties' => new Collection($properties_activity),
            'description' => ''
        ]);
        // Log::create([
        //     'log_name' => $log_name,
        //     'model_name' => $model_name,
        //     'model_id' => $model_id,
        //     'user_id' => 1,
        //     'properties' => $properties_activity,
        //     'description' => $description
        // ]);
        return;
    }
}
