<?php
namespace App\Traits;

use App\Models\Log;
use DateTimeInterface;
use Illuminate\Support\Collection;

trait AllInTrait
{
    protected function generateCodeV2($model, $code)
    {
        $inputCount = $model->count();
        $inputCount += 1;
        $generate = $code . '-' . str_pad($inputCount, 5, '0', STR_PAD_LEFT);

        return $generate;
    }


}
