<?php

namespace Database\Factories;

use App\Models\ParentStudent;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\ParentStudent>
 */
class ParentStudentFactory extends Factory
{

    public function generateCodeV2()
    {
        $code = fake()->randomNumber(5, true);
        $check = ParentStudent::where('code', $code)->first();
        if (!$check) {
            return $code;
        }

        return $this->generateCodeV2();
    }
    public function definition(): array
    {
        return [
            'code' => $this->generateCodeV2()
        ];
    }
}
