<?php

namespace Database\Factories;

use App\Models\Major;
use App\Models\Faculty;
use Illuminate\Support\Str;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Student>
 */
class StudentFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        $randomNumber = '';
        for ($i = 0; $i < 11; $i++) {
            $randomNumber .= mt_rand(0, 9); // Anda dapat mengubah rentang ini sesuai kebutuhan Anda
        }
        return [
            'nim' => $randomNumber,
            'major_id' => Major::all()->random()->id,
            'generation' => fake()->randomElement(['2020', '2021', '2022', '2023', '2024'])
        ];
    }
}
