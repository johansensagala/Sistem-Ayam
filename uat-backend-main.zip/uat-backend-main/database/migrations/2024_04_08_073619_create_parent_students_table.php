<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('parent_students', function (Blueprint $table) {
            $table->id();
            $table->string('code');
            $table->string('company_name')->nullable();
            $table->double('sallary', 20, 0)->nullable();
            $table->string('position')->nullable();
            $table->string('ktp_image')->nullable();
            $table->string('bank_image')->nullable();
            $table->string('kk_image')->nullable();
            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('parent_students');
    }
};
