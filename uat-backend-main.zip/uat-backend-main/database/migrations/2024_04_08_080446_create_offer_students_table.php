<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('offer_students', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('residence_id')->nullable();
            $table->string('parent_code');
            $table->string('student_id');
            $table->integer('sks');
            $table->double('sub_offer', 20, 0)->nullable();
            $table->double('total_offer', 20, 0);
            $table->integer('timeline')->nullable();
            $table->boolean('status_parent')->default(0);
            $table->boolean('status_university')->default(0);
            $table->boolean('status_instalment')->default(0);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('offer_students');
    }
};
