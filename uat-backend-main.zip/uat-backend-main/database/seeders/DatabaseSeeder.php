<?php

namespace Database\Seeders;

// use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use App\Models\MaterialVendor;
use Illuminate\Database\Seeder;
use Database\Seeders\CategoryMaterialSeeder;


class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        $this->call([
            RegionSeeder::class,

            FacultySeeder::class,
            MajorSeeder::class,

            RolePermissionSeeder::class,
            RoleSeeder::class,
            UserSeeder::class,

            ParentSeeder::class,
            StudentSeeder::class,

            SettingSeeder::class,


            LogSeeder::class
        ]);
        // $this->call(MaterialsTableSeeder::class);
    }
}
