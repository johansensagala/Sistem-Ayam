<?php

namespace Database\Seeders;

use App\Models\Faculty;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;

class FacultySeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        Schema::disableForeignKeyConstraints();
        Faculty::truncate();
        Faculty::create([
            'name' => 'TEKNIK'
        ]);
        Faculty::create([
            'name' => 'KEDOKTERAN'
        ]);
        Faculty::create([
            'name' => 'ILMU SOSIAL DAN POLITIK'
        ]);
    }
}
