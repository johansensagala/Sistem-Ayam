<?php

namespace Database\Seeders;

use App\Models\Major;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;

class MajorSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        Schema::disableForeignKeyConstraints();
        Major::truncate();
        Major::create([
            'faculty_id' => 1,
            'name' => 'TEKNIK ELEKTRO'
        ]);
        Major::create([
            'faculty_id' => 1,
            'name' => 'TEKNIK MESIN'
        ]);
        Major::create([
            'faculty_id' => 1,
            'name' => 'TEKNIK SIPIL'
        ]);
        Major::create([
            'faculty_id' => 2,
            'name' => 'KEDOKTERAN UMUM'
        ]);
        Major::create([
            'faculty_id' => 2,
            'name' => 'KEDOKTERAN HEWAN'
        ]);
        Major::create([
            'faculty_id' => 2,
            'name' => 'KEDOKTERAN GIGI'
        ]);
        Major::create([
            'faculty_id' => 3,
            'name' => 'ILMU KOMUNIKASI'
        ]);
        Major::create([
            'faculty_id' => 3,
            'name' => 'HUBUNGAN INTERNASIONAL'
        ]);
    }
}
