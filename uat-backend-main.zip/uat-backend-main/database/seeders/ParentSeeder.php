<?php

namespace Database\Seeders;

use App\Models\User;
use App\Models\ParentStudent;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;

class ParentSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        Schema::disableForeignKeyConstraints();
        ParentStudent::truncate();
        $userC = User::where('name', 'parent')->first();
        $studentC = ParentStudent::factory()->create([
            'code' => '0000'
        ]);
        $userC->ident_id = $studentC->id;
        $userC->ident_type = 'App\\Models\\ParentStudent';

        $userC->syncRoles('parent');
        $userC->save();
        for ($i = 0; $i < 5; $i++) {
            DB::beginTransaction();
            try {
                $user = User::where('ident_id', null)->where('username', '!=', 'superadmin')->get()->random();
                $parent = ParentStudent::factory()->create();

                $user->ident_id = $parent->id;
                $user->ident_type = 'App\\Models\\ParentStudent';
                $user->syncRoles('parent');
                $user->save();


                DB::commit();
            } catch (\Exception $e) {
                DB::rollBack();
                dd($e->getMessage());
            }
        }
    }
}
