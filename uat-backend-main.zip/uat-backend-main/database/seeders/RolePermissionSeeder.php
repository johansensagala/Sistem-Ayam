<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Spatie\Permission\Models\Role;
use Illuminate\Support\Facades\Schema;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\PermissionRegistrar;

class RolePermissionSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run()
    {
        Schema::disableForeignKeyConstraints();
        DB::table('roles')->truncate();
        DB::table('model_has_roles')->truncate();
        DB::table('role_has_permissions')->truncate();
        DB::table('model_has_permissions')->truncate();
        DB::table('permissions')->truncate();
        Schema::enableForeignKeyConstraints();
        // Reset cached roles and permissions
        app()[PermissionRegistrar::class]->forgetCachedPermissions();

        // create permissions
        Permission::create(['name' => 'list_offer', 'model_name' => 'Pengajuan Mahasiswa']);
        Permission::create(['name' => 'list_offer_student', 'model_name' => 'Pengajuan Mahasiswa']);
        Permission::create(['name' => 'list_offer_parent', 'model_name' => 'Pengajuan Mahasiswa']);
        Permission::create(['name' => 'create_offer', 'model_name' => 'Pengajuan Mahasiswa']);
        Permission::create(['name' => 'update_offer', 'model_name' => 'Pengajuan Mahasiswa']);
        Permission::create(['name' => 'delete_offer', 'model_name' => 'Pengajuan Mahasiswa']);

        Permission::create(['name' => 'list_user', 'model_name' => 'User']);
        Permission::create(['name' => 'create_user', 'model_name' => 'User']);
        Permission::create(['name' => 'update_user', 'model_name' => 'User']);
        Permission::create(['name' => 'delete_user', 'model_name' => 'User']);




    }
}
