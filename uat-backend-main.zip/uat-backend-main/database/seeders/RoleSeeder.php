<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Spatie\Permission\Models\Role;
use Spatie\Permission\PermissionRegistrar;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;

class RoleSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $role = Role::create(['name' => 'parent']);
        $role->givePermissionTo('list_offer_parent');

        $role1 = Role::create(['name' => 'student']);
        $role1->givePermissionTo('list_offer_student');

        $role2 = Role::create(['name' => 'user']);
        // $role2->givePermissionTo('list_user');
        // $role2->givePermissionTo('create_user');
        // $role2->givePermissionTo('update_user');
        // $role2->givePermissionTo('delete_user');
        // $role2->givePermissionTo('list_product');
        // $role2->givePermissionTo('create_product');
        // $role2->givePermissionTo('update_product');
        // $role2->givePermissionTo('delete_product');

        $role3 = Role::create(['name' => 'superadmin']);
    }
}
