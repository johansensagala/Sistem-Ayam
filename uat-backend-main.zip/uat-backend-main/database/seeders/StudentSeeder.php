<?php

namespace Database\Seeders;

use App\Models\Student;
use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;

class StudentSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        Schema::disableForeignKeyConstraints();
        Student::truncate();
        $userC = User::where('name', 'student')->first();
        $studentC = Student::factory()->create([
            'parent_code' => '0000'
        ]);
        $userC->ident_id = $studentC->id;
        $userC->ident_type = 'App\\Models\\Student';
        // $userC->parent_code = '0000';
        $userC->syncRoles('student');
        $userC->save();
        for ($i = 0; $i < 5; $i++) {
            DB::beginTransaction();
            try {
                $user = User::where('ident_id', null)->get()->random();
                $student = Student::factory()->create();

                $user->ident_id = $student->id;
                $user->ident_type = 'App\\Models\\Student';

                $user->syncRoles('student');
                $user->save();


                DB::commit();
            } catch (\Exception $e) {
                DB::rollBack();
                dd($e->getMessage());
            }
        }
    }
}
