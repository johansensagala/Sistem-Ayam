<?php

namespace Database\Seeders;

use App\Models\User;
use App\Models\UserLevel;
use App\Models\UserTrinity;
use Illuminate\Support\Str;
use Faker\Generator as Faker;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;

class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(Faker $faker): void
    {
        Schema::disableForeignKeyConstraints();
        User::truncate();

        $user1 = User::factory()->create([
            'name' => 'Super Admin',
            'username' => 'superadmin'
        ]);
        $user1->assignRole('superadmin');


        $user3 = User::factory()->create([
            'name' => 'user',
            'username' => 'user'
        ]);
        $user3->assignRole('user');
        $user4 = User::factory()->create([
            'name' => 'student',
            'username' => 'student'
        ]);
        $user4->assignRole('student');
        $user5 = User::factory()->create([
            'name' => 'parent',
            'username' => 'parent'
        ]);
        $user5->assignRole('parent');

        DB::beginTransaction();
        try {
            for ($i = 0; $i < 100; $i++) {
                $user = User::factory()->create();
                $user->assignRole('user');
            }
            DB::commit();
        } catch (\Exception $e) {
            dd($e->getMessage());
            DB::rollBack();
        }
    }
}
