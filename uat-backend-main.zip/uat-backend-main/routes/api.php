<?php

use App\Http\Controllers\FacultyController;
use App\Http\Controllers\HostelController;
use App\Http\Controllers\MajorController;
use App\Http\Controllers\OfferStudentController;
use App\Http\Controllers\ParentStudentController;
use App\Http\Controllers\PaymentController;
use App\Http\Controllers\SettingController;
use App\Models\Faculty;
use App\Models\Major;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\RoleController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\TestingController;
use App\Http\Controllers\PermissionController;


/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/

// Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
//     return $request->user();
// });
Route::get('/testing', [TestingController::class, 'index']);

Route::group([
    'middleware' => 'api',
    'prefix' => 'auth'
], function ($router) {
    Route::post('login', [AuthController::class, 'login']);
    Route::post('register', [AuthController::class, 'register']);
    Route::post('logout', [AuthController::class, 'logout']);
    Route::post('refresh', [AuthController::class, 'refresh']);
    Route::post('me', [AuthController::class, 'me']);
    Route::post('send-code', [AuthController::class, 'sendCode']);
    Route::post('verif-code', [AuthController::class, 'verifCode']);
});
//parents
Route::group([
    'middleware' => 'auth:api',
    'prefix' => 'parents',
    'controller' => ParentStudentController::class
], function () {
    Route::get('/', 'index');
    Route::get('/trashed', 'trashed');
    Route::get('/show/{id}', 'show');
    Route::post('/', 'store');
    Route::post('/update/{id}', 'update');
    Route::post('/delete/{id}', 'delete');
    Route::post('/restore/{id}', 'restore');
    Route::post('/force-delete/{id}', 'forceDelete');
});
//users
Route::group([
    'middleware' => 'auth:api',
    'prefix' => 'users',
    'controller' => UserController::class
], function () {
    Route::get('/', 'index');
    Route::get('/trashed', 'trashed');
    Route::get('/show/{id}', 'show');
    Route::post('/', 'store');
    Route::get('/parent', 'parent');
    Route::post('/update-parent-code/{id}', 'updateParentCode');
    Route::post('/update/{id}', 'update');
    Route::post('/delete/{id}', 'delete');
    Route::post('/restore/{id}', 'restore');
    Route::post('/force-delete/{id}', 'forceDelete');
});
//Permission
Route::group([
    'middleware' => 'auth:api',
    'prefix' => 'permissions',
    'controller' => PermissionController::class
], function () {
    Route::get('/', 'index');
    Route::get('/show/{id}', 'show');
    Route::post('/', 'store');
    Route::post('/update/{id}', 'update');
    Route::post('/delete/{id}', 'delete');
});
//Role
Route::group([
    'middleware' => 'auth:api',
    'prefix' => 'roles',
    'controller' => RoleController::class
], function () {
    Route::get('/', 'index');
    Route::get('/show/{id}', 'show');
    Route::post('/', 'store');
    Route::post('/update/{id}', 'update');
    Route::post('/delete/{id}', 'delete');
    Route::post('/permission/give/{id}', 'givePermission');
});
//Faculties
Route::group([
    'middleware' => 'auth:api',
    'prefix' => 'faculties',
    'controller' => FacultyController::class
], function () {
    Route::get('/', 'index');
    Route::get('/trashed', 'trashed');
    Route::get('/show/{id}', 'show');
    Route::post('/', 'store');
    Route::post('/update/{id}', 'update');
    Route::post('/delete/{id}', 'delete');
    Route::post('/restore/{id}', 'restore');
    Route::post('/force-delete/{id}', 'forceDelete');
});
//Majors
Route::group([
    'middleware' => 'auth:api',
    'prefix' => 'majors',
    'controller' => MajorController::class
], function () {
    Route::get('/', 'index');
    Route::get('/trashed', 'trashed');
    Route::get('/show/{id}', 'show');
    Route::post('/', 'store');
    Route::post('/update/{id}', 'update');
    Route::post('/delete/{id}', 'delete');
    Route::post('/restore/{id}', 'restore');
    Route::post('/force-delete/{id}', 'forceDelete');
});
//Hostel
Route::group([
    'middleware' => 'auth:api',
    'prefix' => 'hostels',
    'controller' => HostelController::class
], function () {
    Route::get('/', 'index');
    Route::get('/trashed', 'trashed');
    Route::get('/show/{id}', 'show');
    Route::post('/', 'store');
    Route::post('/update/{id}', 'update');
    Route::post('/delete/{id}', 'delete');
    Route::post('/restore/{id}', 'restore');
    Route::post('/force-delete/{id}', 'forceDelete');
});
//Payment
Route::group([
    'middleware' => 'auth:api',
    'prefix' => 'payments',
    'controller' => PaymentController::class
], function () {
    Route::get('/', 'index');
    Route::get('/trashed', 'trashed');
    Route::get('/show/{id}', 'show');
    Route::post('/', 'store');
    Route::post('/update/{id}', 'update');
    Route::post('/delete/{id}', 'delete');
    Route::post('/restore/{id}', 'restore');
    Route::post('/force-delete/{id}', 'forceDelete');
});
//OfferStudent
Route::group([
    'middleware' => 'auth:api',
    'prefix' => 'offers',
    'controller' => OfferStudentController::class
], function () {
    Route::get('/', 'index');
    Route::get('/trashed', 'trashed');
    Route::get('/show/{id}', 'show');
    Route::post('/', 'store');
    Route::post('/update/{id}', 'update');
    Route::post('/delete/{id}', 'delete');
    Route::post('/restore/{id}', 'restore');
    Route::post('/force-delete/{id}', 'forceDelete');
});
//Setting
Route::group([
    'middleware' => 'auth:api',
    'prefix' => 'settings',
    'controller' => SettingController::class
], function () {
    Route::get('/show/{id}', 'index');
    Route::post('/update/{id}', 'update');
});