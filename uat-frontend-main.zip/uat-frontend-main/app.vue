<template>
  <div>
    <NuxtPage />
  </div>
</template>
<script>
import "@fortawesome/fontawesome-free/css/all.min.css";
</script>
