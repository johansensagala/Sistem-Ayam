<template>
    <div class="px-3 py-1 w-fit rounded-full text-sm" :class="`${bg} ${color}`">
        <slot />
    </div>
</template>
<script setup>
const props = defineProps({
    bg: {
        type: String,
        default: 'bg-red-500'
    },
    color: {
        type: String,
        default: 'text-white'
    }
})
</script>