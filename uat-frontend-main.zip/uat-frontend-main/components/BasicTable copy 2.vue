

<template>
  <div>
    <div class="flex  w-full justify-between">
      <div class="flex flex-1 w-full items-center">
        <p class="mr-2">Show</p>
        <Select :search="perPage" :data="sizeData" v-model="perPage" @update:search="perPage = $event" />
      </div>
      <div class="flex flex-grow-0 items-center">
        <p class="mr-4">Search :</p>
        <input type="text" v-model="searchQuery.name" @input="$event.target.composing = false" class="form-control w-48 "
          placeholder="Search Data..." />
      </div>
    </div>
    <div class="flex space-x-2 mt-2">
      <Button @click="trashHandler(false)" :disabled="!trashed"
        :backgroundColor="trashed ? 'bg-gray-300' : 'bg-primary'">View</Button>
      <Button @click="trashHandler(true)" :disabled="trashed"
        :backgroundColor="!trashed ? 'bg-gray-300' : 'bg-red-500'">Trashed</Button>
    </div>
    <div class="overflow-x-auto">
      <table class="text-normal overflow-x-auto table-style-1 mt-2">
        <thead>
          <tr>
            <th width="5%" class="text-center">No</th>
            <th :style="`width:${header.width}`" v-for="(header, index) in headers" :key="index">
              <div>
                <Button @click="handleSort(header.name)" v-if="header.filter" backgroundColor="transparent"
                  textColor="text-inherit" className="space-x-2">
                  <p> {{ header.head }}</p>
                  <div class="flex flex-col">
                    <i class="fas fa-caret-up -mb-1"
                      :class="[sortFilter.sort.columns == header.name && sortFilter.sort.dir == 'asc' ? 'text-black' : 'text-gray-300']"></i>
                    <i class="fas fa-caret-down -mt-1"
                      :class="[sortFilter.sort.columns == header.name && sortFilter.sort.dir == 'desc' ? 'text-black' : 'text-gray-300']"></i>
                  </div>
                </Button>
                <p v-else>{{ header.head }}</p>
              </div>
            </th>
            <th v-if="typeAction.length !== 0" :width="wAction" class="w-72">Action</th>
          </tr>
        </thead>
        <tbody>
          <tr v-if="rows.length > 0" v-for="( row, rowIndex ) in  rowsWithIndexes " :key="rowIndex">
            <td class=" text-center">{{ row.rowIndex }}</td>
            <td v-for="( header, headerIndex ) in  headers " :key="headerIndex">

              <template v-if="header.array">
                <div v-for="(entry, entryIndex) in getNestedPropertyValue(row, header.name)">
                  <p class="font-bold"> {{ getNestedPropertyValue(entry, header.headArray) }} : <span
                      class="font-normal">{{
                        entry[header.textArray]
                      }}</span>
                  </p>
                </div>
              </template>
              <template v-else>
                <template v-if="header.name == 'price'">
                  <div>
                    Rp, {{ initSaldo(row[header.name]) }}
                  </div>
                </template>
                <template v-else>
                  <div>
                    {{ getNestedPropertyValue(row, header.name) }}
                  </div>
                </template>
              </template>
            </td>
            <td v-if="typeAction.length !== 0">
              <div class="flex flex-wrap justify-center space-x-2">
                <template v-for="( action, index ) in typeAction">
                  <div @click="$emit(action.eventName, row.id)"
                    :class="[action.type == 'icon' ? 'w-8 h-8 flex items-center justify-center' : '', action.bg ? action.bg : 'bg-primary']"
                    class="p-2 rounded text-white cursor-pointer">
                    <i v-if="action.type == 'icon'" :class="action.label"></i>
                    <p v-else>{{ action.label }}</p>
                  </div>
                </template>
              </div>
            </td>
          </tr>
          <tr v-else>
            <td :colspan="headers.length + 2" class="bg-gray-100 text-center">Data is empty</td>
          </tr>
        </tbody>
      </table>
    </div>
    <div class="inline-block md:flex mt-4 text-center w-full">
      <div class="flex flex-grow">
        <i class=" text-[12px]">Show {{ perPage ?? 0 }} from {{ totalItems ?? 0 }} data</i>
      </div>
      <Paginate :current-page="currentPage" :total-items="totalItems" :per-page="perPage"
        @update:current-page="currentPage = $event" />
    </div>
  </div>
</template>

<script setup>
import debounce from 'lodash.debounce'
import initSaldo from '@/utils/currency'

const emit = defineEmits()

const props = defineProps({
  headers: {
    type: Array,
    default: () => []
  },
  rows: {
    type: Array,
    default: () => []
  },
  typeAction: {
    type: Array,
    default: () => []
  },
  totalItems: {
    type: Number,
    default: 0
  },
  fetchFunction: {
    type: Function,
    default: null
  },
  trashFunction: {
    type: Function,
    default: null
  },
  loadFilter: {
    type: Boolean,
    default: false
  },
  witoutTrashed: {
    type: Boolean,
    default: false
  },
  wAction: {
    type: String,
    default: '10%'
  },
  trashed: {
    type: Boolean,
    deafult: false
  }
})

const perPage = ref(5)
const sizeData = [
  { id: 5, name: 5 },
  { id: 10, name: 10 },
  { id: 50, name: 50 }
]
const currentPage = ref(1)
const checkLoading = ref(true)
const sortFilter = ref({
  sort: {
    dir: 'desc',
    columns: 'id'
  }
})

let rowsWithIndexes = ref([])

const searchQuery = ref({
  name: "",
});

const trashed = ref(false)

const getNestedPropertyValue = (obj, path) => {
  return path.split('.').reduce((acc, key) => acc?.[key], obj);
}

const queryParams = computed(() => useFilterStore().queryParams)
const sortParams = computed(() => useFilterStore().sortParams)



const getData = async () => {
  useWebStore().onLoading()
  if (!trashed.value) {
    await props.fetchFunction(currentPage.value, perPage.value, queryParams.value + sortParams.value)
  } else {
    await props.trashFunction(currentPage.value, perPage.value, queryParams.value + sortParams.value)
  }
  // initWatch.value = true
  useWebStore().offLoading()
}
const getTrashed = async () => {
  useWebStore().onLoading()
  await props.trashFunction(currentPage.value, perPage.value, queryParams.value + sortParams.value)
  // initWatch.value = true
  useWebStore().offLoading()
}

const getRowIndex = (index) => {
  const startIndex = (currentPage.value - 1) * perPage.value
  return startIndex + index + 1
}

const trashHandler = (action) => {
  if (action) {
    trashed.value = true
    currentPage.value = 1
    useFilterStore().resetFilter()
  } else {
    trashed.value = false
    currentPage.value = 1
    useFilterStore().resetFilter()
  }

  if (searchQuery.value.name == '') {
    getData()
  } else {
    console.log(searchQuery.value.name)
    searchQuery.value.name = ''
  }
}

const handleSort = (filter, wl = null) => {
  useWebStore().onLoading()
  console.log(sortFilter.value)
  console.log(sortFilter.value.sort.columns)
  if (sortFilter.value.sort.columns !== filter) {
    sortFilter.value.sort = {
      dir: 'asc',
      columns: filter,
    }
  }
  else if (sortFilter.value.sort.columns === filter && sortFilter.value.sort.dir == 'asc') {
    sortFilter.value.sort = {
      dir: 'desc',
      columns: filter,
    }
  }
  else if (sortFilter.value.sort.columns === filter && sortFilter.value.sort.dir == 'desc') {
    sortFilter.value.sort = {
      dir: 'desc',
      columns: 'id',
    }
  }
  console.log(sortFilter.value.sort.columns)
  if (wl) {
    checkLoading.value = false
  } else {
    checkLoading.value = true
  }
  useFilterStore().handleFilter(sortFilter.value)
}

const handleFilter = (goFilter, wl = null) => {
  if (wl) {
    checkLoading.value = false
  } else {
    checkLoading.value = true
  }
  useFilterStore().handleFilter(goFilter)
}

rowsWithIndexes.value = props.rows.map((row, index) => {
  return {
    ...row,
    rowIndex: getRowIndex(index)
  }
})

watch(() => props.trashed, (newTrashed) => {
  if (trashed.value) {
    trashed.value = false
  }
})

watch(() => props.rows, (newRows) => {
  console.log(props.rows)
  rowsWithIndexes.value = newRows.map((row, index) => {
    return {
      ...row,
      rowIndex: getRowIndex(index)
    }
  })
})

const currentPageInit = ref(currentPage.value)

// watch(currentPage, (newPage) => {
//   getData()
//   // emit("update:currentPage", newPage);
// });

const debouceFilter = debounce((newQuery) => {
  handleFilter(newQuery, props.loadFilter)
}, 500)

const delayedFetchData = debounce(() => {
  getData()
}, 500);

watch(searchQuery.value, (newQuery) => {
  debouceFilter(newQuery)
  // emit('update:updateQuery', newQuery)
})

watch([queryParams, sortParams], () => {
  delayedFetchData()
  // if (initWatch.value == true) {
  //     delayedFetchData()
  // }
})
watch([currentPage, perPage], () => {
  getData()
  // if (initWatch.value == true) {
  //     delayedFetchData()
  // }
})


onMounted(() => {
  getData()
})


</script>
