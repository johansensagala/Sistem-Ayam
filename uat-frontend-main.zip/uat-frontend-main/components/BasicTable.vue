

<template>
  <div>
    <div class="inline-block md:flex w-full justify-between">
      <div class="flex flex-1 w-full items-center">
        <p class="mr-2">Show</p>
        <Select :search="perPage" :data="sizeData" v-model="perPage" @update:search="perPage = $event" />
      </div>
      <div class="flex mt-2 md:mt-2 flex-grow-0 items-center">
        <p class="mr-4">Search :</p>
        <input type="text" v-model="searchQuery.name" @input="$event.target.composing = false" class="form-control w-48 "
          placeholder="Search Data..." />
      </div>
    </div>
    <div class="flex space-x-2 mt-2" v-if="!withOutTrashed">
      <Button @click="trashHandler(false)" width="w-fit" :disabled="!trashed"
        :backgroundColor="!trashed ? '!bg-primary' : 'bg-gray-300'"
        className="hover:bg-primary transition-all">View</Button>
      <div>
        <Button @click="trashHandler(true)" width="w-fit" :disabled="trashed"
          :backgroundColor="trashed ? '!bg-red-500' : 'bg-gray-300'"
          className="hover:bg-red-500 transition-all">Trashed</Button>
      </div>
    </div>
    <div class="overflow-x-auto overflow-y-visible">
      <table class="text-normal overflow-x-auto table-style-1 mt-2 w-full">
        <thead>
          <tr>
            <th width="5%" class="text-center">No</th>
            <th :style="`min-width:${header.width}`" v-for="(header, index) in headers" :key="index">
              <div>
                <Button @click="handleSort(header.name)" v-if="header.filter" backgroundColor="transparent"
                  textColor="text-inherit" className="space-x-2">
                  <p> {{ header.head }}</p>
                  <div class="flex flex-col">
                    <i class="fas fa-caret-up -mb-1"
                      :class="[sortFilter.sort.columns == header.name && sortFilter.sort.dir == 'asc' ? 'text-black' : 'text-gray-300']"></i>
                    <i class="fas fa-caret-down -mt-1"
                      :class="[sortFilter.sort.columns == header.name && sortFilter.sort.dir == 'desc' ? 'text-black' : 'text-gray-300']"></i>
                  </div>
                </Button>
                <p v-else>{{ header.head }}</p>
              </div>
            </th>
            <th v-if="typeAction.length !== 0" :width="wAction">Action</th>
          </tr>
        </thead>
        <tbody>
          <tr v-if="rows.length > 0" v-for="( row, rowIndex ) in  rowsWithIndexes " :key="rowIndex">
            <td class=" text-center">{{ row.rowIndex }}</td>
            <td v-for="( header, headerIndex ) in  headers " :key="headerIndex" class="md:min-w-20 min-w-32"
              :class="[header.width ?? 'md:min-w-20']">

              <template v-if="header.array">
                <div v-for="(entry, entryIndex) in getNestedPropertyValue(row, header.name)">
                  <div v-if="!header.first">
                    <p class="font-bold"> {{ getNestedPropertyValue(entry, header.headArray) }} : <span
                        class="font-normal">{{
                          entry[header.textArray]
                        }}</span>
                    </p>
                  </div>
                  <div v-else>
                    <p>{{ entry[header.textArray] }}</p>
                  </div>
                </div>
              </template>
              <template v-else>
                <template v-if="header.type == 'price'">
                  <div>
                    Rp, {{ initSaldo(row[header.name]) }}
                  </div>
                </template>
                <template v-if="header.type == 'badge'">
                  <div class="flex justify-center">
                    <Badge>{{ row[header.name] }}</Badge>
                  </div>
                </template>
                <template v-if="header.type == 'image'">
                  <div class="flex justify-center items-center">
                    <img :src="getNestedPropertyValue(row, header.name)" class="max-w-[10rem]" alt="">
                  </div>
                </template>
                <template v-if="header.type == 'dateTime'">
                  <div class="flex justify-center items-center">
                    {{ formatToWIB(getNestedPropertyValue(row, header.name)) }}
                  </div>
                </template>
                <template v-if="header.type == 'date'">
                  <div class="flex justify-center items-center">
                    {{ formatToDate(getNestedPropertyValue(row, header.name)) }}
                  </div>
                </template>
                <template v-if="!header.type">
                  <div>
                    {{ getNestedPropertyValue(row, header.name) }}
                  </div>
                </template>
              </template>
            </td>
            <td v-if="typeAction.length !== 0" class="md:min-w-[9rem] min-w-44">
              <div class="flex flex-wrap justify-center space-x-2">
                <template v-for="( action, index ) in typeAction">

                  <div v-if="action.trash !== true && !trashed" @click="$emit(action.eventName, row.id)"
                    :class="[action.type == 'icon' ? 'w-8 h-8 flex items-center justify-center' : '', action.bg ? action.bg : 'bg-primary']"
                    class="p-2 rounded text-white cursor-pointer">
                    <i v-if="action.type == 'icon'" :class="action.label"></i>
                    <p v-else>{{ action.label }}</p>
                  </div>
                  <div v-if="action.trash == true && trashed" @click="$emit(action.eventName, row.id)"
                    :class="[action.type == 'icon' ? 'w-8 h-8 flex items-center justify-center' : '', action.bg ? action.bg : 'bg-primary']"
                    class="p-2 rounded text-white cursor-pointer">
                    <i v-if="action.type == 'icon'" :class="action.label"></i>
                    <p v-else>{{ action.label }}</p>
                  </div>

                </template>
              </div>
            </td>
          </tr>
          <tr v-else>
            <td :colspan="headers.length + 2" class="bg-gray-100 text-center">Data is empty</td>
          </tr>
        </tbody>
      </table>
    </div>
    <div class="inline-block md:flex mt-4 text-center w-full">
      <div class="flex flex-grow">
        <i class=" text-[12px]">Show {{ rows.length }} from {{ totalItems ?? 0 }} data</i>
      </div>
      <Paginate :current-page="currentPage" :total-items="totalItems" :per-page="perPage"
        @update:current-page="currentPage = $event" />
    </div>
  </div>
</template>

<script setup>
import debounce from 'lodash.debounce'
import initSaldo from '@/utils/currency'
import { formatToWIB } from '@/utils/dateTime';

const emit = defineEmits()

const props = defineProps({
  headers: {
    type: Array,
    default: () => []
  },
  rows: {
    type: Array,
    default: () => []
  },
  typeAction: {
    type: Array,
    default: () => []
  },
  totalItems: {
    type: Number,
    default: 0
  },
  fetchFunction: {
    type: Function,
    default: null
  },
  trashFunction: {
    type: Function,
    default: null
  },
  loadFilter: {
    type: Boolean,
    default: false
  },
  withOutTrashed: {
    type: Boolean,
    default: false
  },
  wAction: {
    type: String,
    default: '10%'
  },
  trashed: {
    type: Boolean,
    deafult: false
  },
  detailSearch: {
    type: String,
    default: ''
  }
})

const perPage = ref(5)
const sizeData = [
  { id: 5, name: 5 },
  { id: 10, name: 10 },
  { id: 50, name: 50 }
]
const currentPage = ref(1)
const checkLoading = ref(true)
const sortFilter = ref({
  sort: {
    dir: 'desc',
    columns: 'id'
  }
})

let rowsWithIndexes = ref([])

const searchQuery = ref({
  name: "",
});

const trashed = ref(false)

const getNestedPropertyValue = (obj, path) => {
  return path.split('.').reduce((acc, key) => acc?.[key], obj);
}

const queryParams = computed(() => useFilterStore().queryParams)
const sortParams = computed(() => useFilterStore().sortParams)



const getData = async () => {
  useWebStore().onLoading()
  if (props.detailSearch) {
    if (!trashed.value) {
      await props.fetchFunction(props.detailSearch, currentPage.value, perPage.value, queryParams.value + sortParams.value)
    } else {
      await props.trashFunction(props.detailSearch, currentPage.value, perPage.value, queryParams.value + sortParams.value)
    }
  } else {
    if (!trashed.value) {
      await props.fetchFunction(currentPage.value, perPage.value, queryParams.value + sortParams.value)
    } else {
      await props.trashFunction(currentPage.value, perPage.value, queryParams.value + sortParams.value)
    }
  }
  // initWatch.value = true
  useWebStore().offLoading()
}
const getTrashed = async () => {
  useWebStore().onLoading()
  await props.trashFunction(currentPage.value, perPage.value, queryParams.value + sortParams.value)
  // initWatch.value = true
  useWebStore().offLoading()
}

const getRowIndex = (index) => {
  const startIndex = (currentPage.value - 1) * perPage.value
  return startIndex + index + 1
}

const trashHandler = (action) => {
  if (action) {
    trashed.value = true
    currentPage.value = 1
    useFilterStore().resetFilter()
  } else {
    trashed.value = false
    currentPage.value = 1
    useFilterStore().resetFilter()
  }

  if (searchQuery.value.name == '') {
    getData()
  } else {
    // console.log(searchQuery.value.name)
    searchQuery.value.name = ''
  }
}

const handleSort = (filter, wl = null) => {
  useWebStore().onLoading()
  // console.log(sortFilter.value)
  // console.log(sortFilter.value.sort.columns)
  if (sortFilter.value.sort.columns !== filter) {
    sortFilter.value.sort = {
      dir: 'asc',
      columns: filter,
    }
  }
  else if (sortFilter.value.sort.columns === filter && sortFilter.value.sort.dir == 'asc') {
    sortFilter.value.sort = {
      dir: 'desc',
      columns: filter,
    }
  }
  else if (sortFilter.value.sort.columns === filter && sortFilter.value.sort.dir == 'desc') {
    sortFilter.value.sort = {
      dir: 'desc',
      columns: 'id',
    }
  }
  // console.log(sortFilter.value.sort.columns)
  if (wl) {
    checkLoading.value = false
  } else {
    checkLoading.value = true
  }
  useFilterStore().handleFilter(sortFilter.value)
}

const handleFilter = (goFilter, wl = null) => {
  if (wl) {
    checkLoading.value = false
  } else {
    checkLoading.value = true
  }
  useFilterStore().handleFilter(goFilter)
}

rowsWithIndexes.value = props.rows.map((row, index) => {
  return {
    ...row,
    rowIndex: getRowIndex(index)
  }
})

watch(() => props.trashed, (newTrashed) => {
  if (trashed.value) {
    trashed.value = false
  }
})

watch(() => props.rows, (newRows) => {
  // console.log(props.rows)
  rowsWithIndexes.value = newRows.map((row, index) => {
    return {
      ...row,
      rowIndex: getRowIndex(index)
    }
  })
})

const currentPageInit = ref(currentPage.value)

// watch(currentPage, (newPage) => {
//   getData()
//   // emit("update:currentPage", newPage);
// });

const debouceFilter = debounce((newQuery) => {
  handleFilter(newQuery, props.loadFilter)
}, 500)

const delayedFetchData = debounce(() => {
  getData()
}, 500);

watch(searchQuery.value, (newQuery) => {
  debouceFilter(newQuery)
})

watch([queryParams, sortParams], () => {
  delayedFetchData()
})
watch([currentPage, perPage], () => {
  getData()
})

onBeforeRouteLeave(() => {
  // Reset store ke nilai defaultnya
  useFilterStore().resetFilter();
});

onMounted(() => {
  getData()
})


</script>
