<template>
    <!-- <div
        class="lg:hidden bottom-nav bg-navBg text-primary fixed bottom-0 bg-an-1 z-30 w-full py-3 flex justify-between container border-t border-primary">
        <a type="button" class="hover:!text-[#a3a3a3]" @click="toggleSidebar">
            <i class="fa-brands fa-windows"></i>
            <span class="block text-xs">Menu</span>
        </a>
        <a type="button" class="hover:!text-[#a3a3a3]" @click="toggleSidebar">
            <i class="fa-brands fa-windows"></i>
            <span class="block text-xs">Menu</span>
        </a>
        <a type="button" class="hover:!text-[#a3a3a3]" @click="toggleSidebar">
            <i class="fa-brands fa-windows"></i>
            <span class="block text-xs">Menu</span>
        </a>
        <a type="button" class="hover:!text-[#a3a3a3]" @click="toggleSidebar">
            <i class="fa-brands fa-windows"></i>
            <span class="block text-xs">Menu</span>
        </a>
    </div> -->
</template>
<script setup>
const toggleSidebar = () => {
    useSidebarStore().toggleSidebar();
}
</script>