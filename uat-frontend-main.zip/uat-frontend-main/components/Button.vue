<template>
    <div :class="width">
        <NuxtLink :to="link" v-if="type == 'link'" :disabled="disabled" :class="`${buttonClasses} ${className} `">
            <slot></slot>
        </NuxtLink>
        <button :disabled="disabled" v-else :class="`${buttonClasses} ${className} disabled:bg-gray-300`">
            <slot></slot>
        </button>
    </div>
</template>
<script setup>
const props = defineProps({
    type: {
        type: String,
        default: 'button'
    },
    link: {
        type: String,
        default: ''
    },
    backgroundColor: {
        type: String,
        default: 'bg-primary'
    },
    textColor: {
        type: String,
        default: 'text-white'
    },
    width: {
        type: String,
        default: 'w-full'
    },
    className: {
        type: String,
        default: ''
    },
    padding: {
        type: String,
        default: 'px-4 py-2'
    },
    disabled: {
        type: Boolean,
        default: false
    }
})
const buttonClasses = ref('')

watchEffect(() => {
    buttonClasses.value = `${props.backgroundColor} ${props.textColor} ${props.width} ${props.padding} rounded-md flex items-center justify-center rounded-md`
})
</script>