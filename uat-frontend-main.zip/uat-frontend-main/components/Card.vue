<script lang="ts" setup>
const props = defineProps({
  height: {
    type: String,
    default: 'h-full'
  },
  width: {
    type: String,
    default: 'w-full'
  },
  className: {
    type: String,
    default: ''
  }
})

</script>

<template>
  <div class="bg-white shadow-[rgba(13,_38,_76,_4%)_0px_0px_10px] p-4 rounded-md" :class="`${height
    } ${width} ${className}`">
    <slot></slot>
  </div>
</template>


<style scoped></style>
