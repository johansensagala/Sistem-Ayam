<template>
  <div class="bg-white text-black flex justify-center py-4 bottom-0">
    <p>
      &copy;Buit with Akmal Riyadi
    </p>
  </div>
</template>


