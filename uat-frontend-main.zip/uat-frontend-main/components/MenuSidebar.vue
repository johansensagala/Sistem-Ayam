<template>
    <div>
        <div v-if="!dropdown">
            <NuxtLink :to="link" :class="{ isActive: isLinkActive(`${link}`) }"
                class="text-gray-500 flex items-center p-2 space-x-4 relative">
                <div :class="className">
                    <i :class="icon" class="text-sm"></i>
                </div>
                <p class="font-normal text-sm">{{ text }}</p>
            </NuxtLink>
        </div>
        <div v-else>
            <a href="#" :class="{ isActive: isParentActive(`${link}`) }">
                <div class="text-gray-500 dropdown-child flex justify-between items-center relative">
                    <div class="flex items-center space-x-4">
                        <div :class="className">
                            <i :class="icon" class="text-sm"></i>
                        </div>
                        <p class="font-normal text-sm">{{ text }}</p>
                    </div>
                    <div class="chev-dropdown mr-1">
                        <i class="fas fa-chevron-down text-sm"></i>
                    </div>
                </div>
            </a>
        </div>
    </div>
</template>
<script setup>
import { ref, computed } from "vue"; // Import ref from Vue
import { useRouter } from 'vue-router';
const router = useRouter();

const props = defineProps({
    link: {
        type: String,
        default: "/",
    },
    text: {
        type: String,
        default: "",
    },
    icon: {
        type: String,
        default: "",
    },
    dropdown: {
        type: Boolean,
        default: false,
    },
});
const isLinkActive = (link) => {
    // Periksa apakah link cocok dengan URL saat ini
    return router.currentRoute.value.path === link;
};
const isParentActive = (link) => {
    return router.currentRoute.value.matched.some((record) =>
        record.path.startsWith(link)
    );
};
const className = 'bg-icon w-9 h-9 flex justify-center items-center rounded-md shadow'
</script>

<style scoped>
.rotate-180 {
    transform: rotate(180deg);
}
</style>
