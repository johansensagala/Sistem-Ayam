<template>
    <div class="bg-[#30629D] lg:pl-[310px] pl-0 fixed w-full top-0 shadow-[rgba(13,_38,_76,_10%)_0px_-20px_10px] z-40">
        <div class="p-4 container flex justify-end">
            <Dropdown>
                <template #button>
                    <div class="flex items-center">
                        <div class="w-10 h-10 bg-red-500 rounded-full">

                        </div>
                        <div class="ml-2 leading-normal text-white">
                            <p class="font-semibold">{{ useAuthStore().getUser().name }}</p>
                            <p class="text-sm">{{ useAuthStore().getUser().roles[0].name }}</p>
                        </div>
                    </div>
                </template>
                <template #body>
                    <DropdownList label="Profile" type="link" link="/admin/profile" />
                    <DropdownList label="Logout" @update:goFunction="handleLogout" />
                </template>
            </Dropdown>
        </div>
    </div>
</template>

<script setup>
const { handleLogout } = useAuthComposables()
</script>