<template>
    <nav class="pagination" aria-label="Pagination">
        <ul class="flex w-full space-x-2 md:justify-end justify-center mt-2 md:mt-0">
            <div class="flex space-x-2 text-black">
                <li class="hidden md:block">
                    <button @click="firstPage" :disabled="currentPage === 1" :class="`${classButton}`">
                        {{ "first page" }} </button>
                </li>
                <li class="">
                    <button @click="previousPage" :disabled="currentPage === 1" :class="`${classButton}`">
                        {{ "back" }} </button>
                </li>
            </div>
            <div class="flex space-x-2">
                <li v-for="pageNumber in displayedPages" :key="pageNumber">
                    <button @click="goToPage(pageNumber)" :class="{
                        'bg-primary  text-white font-semibold border border-primary':
                            currentPage === pageNumber,
                    }"
                        class="px-3 min-w-[39px] min-h-[34px] rounded-md hover:enabled:bg-primary  hover:enabled:text-white border border-primary">
                        {{ pageNumber }}
                    </button>
                </li>
            </div>
            <div class="flex space-x-2 text-black">
                <li class="">
                    <button @click="nextPage" :disabled="currentPage === totalPages" :class="`${classButton}`">
                        {{ "next" }}
                    </button>
                </li>
                <li class="hidden md:block">
                    <button @click="lastPage" :disabled="currentPage === totalPages" :class="`${classButton}`">
                        {{ "last page" }}
                    </button>
                </li>
            </div>
        </ul>
    </nav>
</template>

<script>
import { ref, computed, watch } from "vue";

export default {
    props: {
        currentPage: Number,
        perPage: [String, Number],
        totalItems: Number,
    },
    setup(props, { emit }) {
        const currentPage = ref(props.currentPage);
        const classButton = 'px-3 min-w-[39px] min-h-[34px] bg-white border rounded-md hover:enabled:bg-light  disabled:bg-gray-100'
        const totalPages = computed(() => {
            return Math.ceil(props.totalItems / parseInt(props.perPage));
        });

        const maxVisiblePages = 5; // Tampilkan 3 halaman per kali

        const displayedPages = computed(() => {
            const pages = [];
            let startPage, endPage;

            if (totalPages.value <= maxVisiblePages) {
                startPage = 1;
                endPage = totalPages.value;
            } else {
                startPage = Math.max(currentPage.value - Math.floor(maxVisiblePages / 2), 1);
                endPage = Math.min(startPage + maxVisiblePages - 1, totalPages.value);

                if (endPage - startPage + 1 < maxVisiblePages) {
                    startPage = endPage - maxVisiblePages + 1;
                }
            }

            for (let i = startPage; i <= endPage; i++) {
                pages.push(i);
            }

            return pages;
        });


        const firstPage = () => {
            if (currentPage.value !== 1) {
                currentPage.value = 1;
            }
        };

        const previousPage = () => {
            if (currentPage.value > 1) {
                currentPage.value--;
            }
        };

        const nextPage = () => {
            if (currentPage.value < totalPages.value) {
                currentPage.value++;
            }
        };

        const lastPage = () => {
            if (currentPage.value !== totalPages.value) {
                currentPage.value = totalPages.value;
            }
        };

        const goToPage = (pageNumber) => {
            if (pageNumber !== currentPage.value) {
                currentPage.value = pageNumber;
            }
        };

        watch(currentPage, (newPage) => {
            emit("update:currentPage", newPage);
        });

        return {
            currentPage,
            displayedPages,
            totalPages,
            classButton,
            firstPage,
            previousPage,
            nextPage,
            lastPage,
            goToPage,
        };
    },
};
</script>

<style scoped>
button {
    font-size: 14px;
}
</style>
