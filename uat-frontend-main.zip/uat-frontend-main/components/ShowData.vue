<template>
    <div class="grid grid-cols-12 ">

        <div class="col-span-12 md:col-span-2 border text-gray-500 p-2 bg-gray-100">
            <p class="font-semibold ">{{ label }}</p>
        </div>
        <div class="col-span-12 md:col-span-10 border p-2 flex items-center">
            <p v-if="!custom" class="">{{ value }}</p>
            <div v-else>
                <slot></slot>
            </div>
        </div>
    </div>
</template>

<script setup>
const props = defineProps({
    label: {
        type: String,
        default: ''
    },
    custom: {
        type: Boolean,
        default: false
    },
    value: {
        type: [String, Number, Array, Object],
        default: ''
    }
})
</script>