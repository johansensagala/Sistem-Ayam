<!-- Sidebar.vue -->
<template>
    <div>
        <!-- Sidebar content -->
        <aside ref="scrollableArea" @scroll="handleScroll" :class="isSidebarOpen ? 'translate-x-0' : '-translate-x-full'"
            class="fixed z-50 top-0 left-0 h-full lg:w-[17rem] w-64 bg-an-1  transition-transform transform ease-in-out duration-300 px-4 bg-white overflow-y-auto scrollable-area">
            <div class="flex justify-center py-5 ">
                <img src="/assets/img/loggo2.png" class="" alt="" />
            </div>
            <hr class="h-px mt-0 bg-transparent via-black/40 bg-gradient-to-r from-transparent to-transparent mb-5" />
            <div class="space-y-1 mb-10">
                <MenuSidebar link="/admin/dashboard" text="Dashboard" icon="fas fa-home" />
                <div v-if="checkRoles(['superadmin', 'parent', 'student']) && active">
                    <MenuSidebar link="/admin/payments" text="Pembayaran Kuliah" icon="fas fa-wallet" />
                    <MenuSidebar link="/admin/offers" text="Pengajuan Mahasiswa" icon="fas fa-wallet" />
                </div>
                <div v-if="checkRoles(['superadmin'])">
                    <MenuSidebar link="/admin/faculties" text="Fakultas" icon="fas fa-x-ray" />
                    <MenuSidebar link="/admin/majors" text="Jurusan" icon="fas fa-warehouse" />
                    <MenuSidebar link="/admin/hostels" text="Asrama" icon="fas fa-house" />

                </div>

                <div v-if="checkRoles(['superadmin'])">
                    <div>
                        <p class="text-sm my-3 font-semibold text-gray-400">User Management</p>
                    </div>
                    <MenuSidebar link="/admin/users" text="User" icon="fas fa-user" />
                    <MenuSidebar link="/admin/roles" text="Role" icon="fas fa-walking" />
                    <div>
                        <p class="text-sm my-3 font-semibold text-gray-400">Web Setting</p>
                    </div>
                    <MenuSidebar link="/admin/setting" text="Setting" icon="fas fa-gear" />
                    <!-- <DropdownSidebar :data="user" /> -->
                </div>
                <!-- <MenuSidebar link="/panel/trinity" text="Trinitiy" icon="fas fa-home" /> -->
            </div>
        </aside>
        <div v-if="isSidebarOpen" @click="toggleSidebar()"
            class="fixed lg:hidden top-0 left-0 w-full h-full bg-[#00000045] z-40">
        </div>
    </div>
</template>
<script setup>

const isSidebarOpen = computed(() => useSidebarStore().sidebarOpen)
const roleUser = computed(() => useAuthStore().authUser.roles[0].name)
const active = computed(() => useAuthStore().authUser.status)
const scrollableArea = ref(null);
let scrollTimer;
const handleScroll = () => {
    if (scrollableArea.value) {
        // alert('halo')
        clearTimeout(scrollTimer); // Clear any existing timeout
        scrollableArea.value.classList.add('scroll-active');
        // console.log(scrollableArea.value)
        // Set a timeout to remove the class after a certain delay (e.g., 1 second)
        scrollTimer = setTimeout(() => {
            if (scrollableArea.value) {
                scrollableArea.value.classList.remove('scroll-active');
            }
        }, 1000); // Adjust the delay as needed
    }
}
const checkRoles = (roles) => {
    for (let i = 0; i < roles.length; i++) {
        if (roleUser.value === roles[i]) {
            return true;
        }
    }
    return false;
}
const urlUser = '/admin/user'
const user = {
    head: "Users Management",
    link: urlUser,
    icon: "fas fa-user",
    list: [
        {
            link: urlUser + '',
            text: "List User",
        },
        {
            link: urlUser + '/role',
            text: "Role",
        },
        {
            link: urlUser + '/permission',
            text: "Permission",
        },
    ],
}



const checkScreenWidth = () => {
    if (window.innerWidth >= 768) {
        useSidebarStore().onSidebar()
    } else {
        useSidebarStore().offSidebar()
    }
};

// Toggle sidebar function
const toggleSidebar = () => {
    useSidebarStore().toggleSidebar();
};

// Function to handle window resize event
const handleResize = () => {
    checkScreenWidth(); // Check screen size on resize
};

onMounted(() => {
    // Initial check on component mount
    checkScreenWidth();
    window.addEventListener('resize', handleResize); // Listen for resize events
});

onBeforeUnmount(() => {
    window.removeEventListener('resize', handleResize); // Clean up event listener
});
</script>

