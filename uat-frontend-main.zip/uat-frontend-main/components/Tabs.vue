<template>
    <div class="tabs">
        <ul class="tabs-header flex flex-wrap gap-x-2">
            <li v-for="(tab, index) in tabs" :key="index" @click="selectTab(index)"
                :class="{ 'tab-selected bg-primary text-white': index === selectedIndex }"
                class="tab cursor-pointer px-4 py-2 bg-gray-200 rounded text-gray-500 hover:bg-primary hover:text-white">
                {{ tab.props.title }}
            </li>
        </ul>
        <div class="mt-4">
            <slot></slot>
        </div>
    </div>
</template>
  
<script lang="ts">
import { defineComponent, reactive, provide, onMounted, onBeforeMount, toRefs } from "vue";

interface TabProps {
    title: string;
}

export default defineComponent({
    name: "Tabs",
    setup(_, { slots }) {
        const state = reactive({
            selectedIndex: 0,
            tabs: [],
            count: 0
        });

        provide("TabsProvider", state);

        const selectTab = (i: number) => {
            state.selectedIndex = i;
        };

        onBeforeMount(() => {
            if (slots.default) {
                state.tabs = slots.default().filter((child) => child.type.name === "Tab");
            }
        });

        onMounted(() => {
            selectTab(0);
        });

        return { ...toRefs(state), selectTab };
    }
});
</script>