<template>
    <div class="tooltip-container" @mouseover="showTooltip = true">
        <slot></slot>
        <div v-if="showTooltip" class="tooltip">
            {{ tooltipText }}
        </div>
    </div>
</template>
  
<script>
export default {
    props: {
        tooltipText: {
            type: String,
            required: true
        }
    },
    data() {
        return {
            showTooltip: false
        };
    }
};
</script>
  
<style>
.tooltip-container {
    position: relative;
}

.tooltip {
    position: absolute;
    top: 100%;
    left: 50%;
    transform: translateX(-50%);
    background-color: #333;
    color: #fff;
    padding: 5px 10px;
    border-radius: 5px;
    z-index: 999;
    display: flex;
    width: max-content;
    /* display: none; */
}

/* .tooltip-container:hover .tooltip {
    display: block;
} */
</style>
  