<template>
    <div>
        ini admin
    </div>
</template>