<template>
    <div>

    </div>
    <div v-if="!user.status">
        <div>
            <p>Akun anda belum aktif mohon aktifasi</p>
            <div class="mt-4">
                <Modal :initModal="modal" :onModal="onModal" label="Aktivasi" @update:goFunction="handleVerifCode()">
                    <Input label="Input Code" v-model="form.code" />
                    <p v-if="afterSend" class="mt-2">Kode telah dikirimkan ke {{ user.phone }}</p>
                    <p @click="handleSendCode()" class="mt-2 text-blue-600 cursor-pointer hover:underline">Kirim Code</p>
                </Modal>
            </div>
        </div>

    </div>
</template>
<script setup>
const { sendCode, verifCode, me } = useAuthComposables()
const modal = ref(true)
const code = ref(false)
const onModal = ref(true)
const user = computed(() => useAuthStore().authUser)
const afterSend = ref(false)
const form = ref({
    code: ''
})
const handleSendCode = async () => {
    try {
        await sendCode()
        afterSend.value = true
        setTimeout(() => {
            afterSend.value = false
        }, 60000)
    } catch (e) {
        console.log(e)
    }
}
const handleVerifCode = async () => {
    try {
        await verifCode(form.value)
        await me()
    } catch (e) {
        console.log(e)
        useWebStore().onPopUp('default', e, 'Failed')
    }
}
</script>