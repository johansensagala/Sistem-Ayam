<template>
    <div>
        ini student
    </div>
</template>