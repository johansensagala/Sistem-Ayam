<template>
    <div class="relative cursor-pointer" @click="toggleDropdown" ref="dropdownWrapper">
        <slot name="button"></slot>
        <transition enter-active-class="transition ease-out duration-200" enter-from-class="transform opacity-0 scale-95"
            enter-to-class="transform opacity-100 scale-100" leave-active-class="transition ease-in duration-75"
            leave-from-class="transform opacity-100 scale-100" leave-to-class="transform opacity-0 scale-95">
            <div v-if="isOpen"
                class="absolute z-10 w-44 bg-white text-black shadow-lg rounded-md border mt-1 border-gray-200 overflow-hidden"
                ref="dropdownElement">
                <div class="divide-y divide-gray-300 ">
                    <slot name="body"></slot>
                </div>
            </div>
        </transition>
    </div>
</template>

<script setup>
import { createPopper } from "@popperjs/core";

const isOpen = ref(false);
const dropdownWrapper = ref(null);
const dropdownElement = ref(null);
let popperInstance = null;

const toggleDropdown = () => {
    isOpen.value = !isOpen.value;
    if (isOpen.value) {
        nextTick(() => {
            const dropdown = dropdownWrapper.value;
            const childDropdown = dropdownElement.value;
            const windowWidth = window.innerWidth;
            const dropdownWidth = childDropdown.clientWidth;

            if (dropdownWidth + dropdown.offsetLeft > windowWidth) {
                childDropdown.style.right = "0";
            }
        });
    }
};


const createPopperInstance = () => {
    if (popperInstance) {
        popperInstance.destroy();
    }

    popperInstance = createPopper(
        dropdownWrapper.value,
        dropdownElement.value,
        {
            placement: "bottom-start",
        }
    );
};

const closeDropdownOnClickOutside = (event) => {
    if (!dropdownWrapper.value.contains(event.target)) {
        isOpen.value = false;
    }
};

onMounted(() => {
    createPopperInstance();
    watchEffect(() => {
        if (isOpen.value) {
            document.addEventListener(
                "click",
                closeDropdownOnClickOutside
            );
        } else {
            document.removeEventListener(
                "click",
                closeDropdownOnClickOutside
            );
        }
    });
});

</script>


