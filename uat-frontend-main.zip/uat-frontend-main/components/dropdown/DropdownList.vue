<template>
    <div class="">
        <div v-if="type === 'button'" class="">
            <button @click="handleClick" class="w-full text-sm py-4 px-4 text-left"> {{ label }}</button>
        </div>
        <div v-if="type === 'link'" class="text-sm flex ">
            <NuxtLink :href="link" class="py-4 px-4 text-left w-full">
                {{ label }}
            </NuxtLink>
        </div>
    </div>
</template>
<script setup>
import { ref } from 'vue';

defineProps({
    label: {
        type: String,
        default: "",
    },
    type: {
        type: String,
        default: 'button'
    },
    link: {
        type: String,
        default: ''
    }
});

const emits = defineEmits();
const handleClick = () => {
    emits('update:goFunction');
};

</script>
