<template>
    <div>
        <MenuSidebar class="dropdown-head" dropdown :text="data.head" :link="data.link" :icon="data.icon"
            @click="toggleDropdown" :class="{ isOpen: isOpen }" />

        <transition name="dropdown" mode="out-in">
            <div class="akm-dropdown w-full text-gray-500" ref="dropdownRef" :style="{ height: dropdownHeight + 'px' }">
                <div class="space-y-3 p-3 pl-6 text-sm flex flex-col">
                    <NuxtLink v-for="list in data.list" :href="list.link"
                        :class="{ isActive: isLinkActive(`${list.link}`) }">
                        {{ list.text }}
                    </NuxtLink>
                </div>
            </div>
        </transition>
    </div>
</template>
<script setup>
import { ref, onMounted, nextTick } from "vue";
import { useRouter } from 'vue-router';

const props = defineProps({
    data: {
        type: Object,
        default: () => ({}),
    },
    text: {
        type: String,
        default: '',
    },
});

const isOpen = ref(false);
const dropdownHeight = ref(0);
const dropdownRef = ref(null);
const router = useRouter();

const isLinkActive = (link) => {
    return router.currentRoute.value.path === link;
};

const isParentActive = (link) => {
    return router.currentRoute.value.matched.some((record) =>
        record.path.startsWith(link)
    );
};

const toggleDropdown = () => {
    isOpen.value = !isOpen.value;

    if (isOpen.value) {
        nextTick(() => {
            const dropdownElement = dropdownRef.value;
            if (dropdownElement) {
                dropdownHeight.value = dropdownElement.scrollHeight;
            }
        });
    } else {
        dropdownHeight.value = 0;
    }
};

onMounted(() => {
    if (isParentActive(props.data.link)) {
        toggleDropdown();
    }
});
</script>
<style scoped>
.akm-dropdown {
    transition: height 0.5s ease-in-out;
    overflow: hidden;
}

.dropdown-enter-active,
.dropdown-leave-active {
    transition: height 0.5s ease-in-out;
}

.dropdown-enter-to,
.dropdown-leave {
    height: 0;
    overflow: hidden;
}

.rotate-180 {
    transform: rotate(180deg);
}
</style>
