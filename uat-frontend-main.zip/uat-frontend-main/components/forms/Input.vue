<template>
    <div>
        <label v-if="label && type !== 'radio'" :for="id">{{ label }}</label>
        <div v-if="type == 'radio'" class="flex items-center space-x-3">
            <input :id="id" type="radio" :checked="isChecked(value)" :value="value"
                @change="$emit('update:modelValue', $event.target.value)">
            <label>{{ label }}</label>
        </div>
        <div v-if="type == 'textArea'">
            <textarea class="form-control w-full mt-4" cols="30" rows="10"
                @input="$emit('update:modelValue', $event.target.value)" :class="{
                    '!bg-gray-200 focus:border-0 focus:ring-0 ':
                        readOnly, '!border-red-500': error
                }">{{ modelValue }}</textarea>
            <p v-if="error" class="mt-2 text-red-700 font-light text-sm">
                {{ error[0] }}
            </p>
        </div>
        <div class="relative flex" v-else>
            <div @click="changeViewPassword()" v-if="type == 'password'" class="absolute mt-4 right-4 cursor-pointer">
                <i v-if="passView" class="fas fa-eye-slash"></i>
                <i v-else class="fas fa-eye"></i>
            </div>
            <div class="w-full">
                <input v-if="!custom" :required="required" :hidden="hidden" :readonly="readOnly" :value="modelValue"
                    :type="checkType(type)" :placeholder="placeholder" autocomplete="off" class="w-full form-control mt-2"
                    :class="{
                        '!bg-gray-100 focus:border-0 focus:ring-0 ':
                            readOnly, '!border-red-500': error
                    }" @input="$emit('update:modelValue', $event.target.value)" />
                <input v-else :required="required" :hidden="hidden" :readonly="readOnly" :value="modelValue"
                    :type="checkType(type)" :placeholder="placeholder" autocomplete="off" class="w-full form-control mt-2"
                    :class="{
                        '!bg-gray-200 focus:border-0 focus:ring-0 ':
                            readOnly, '!border-red-500': error
                    }" @input="$emit('update:val', $event.target.value)" />
                <p v-if="error" class="mt-2 text-red-700 font-light text-sm">
                    {{ error[0] }}
                </p>
            </div>
        </div>
    </div>
</template>

<script setup>
const props = defineProps({
    id: {
        type: String
    },
    error: {
        type: [Array, String],
        default: ''
    },
    hidden: {
        type: Boolean,
        default: false
    },
    required: {
        type: Boolean,
        default: false
    },
    custom: {
        type: Boolean,
        default: false
    },
    label: {
        type: String,
        default: "",
    },
    value: {
        type: [String, Number],
        default: "",
    },
    // model: {
    //     type: [String, Number],
    //     default: "",
    // },
    modelValue: {
        type: [String, Number],
        default: "",
    },
    type: {
        type: String,
        default: "text",
    },
    placeholder: {
        type: String,
        default: "",
    },
    readOnly: {
        type: Boolean,
        default: false,
    },
});
const passView = ref(false)
const checkType = (type) => {
    if (type == 'password') {
        if (passView.value) {
            return 'text'
        } else {
            return 'password'
        }
    } else {
        return type
    }
}
const changeViewPassword = () => {
    passView.value = !passView.value
}

const isChecked = (value) => {
    return props.modelValue == value
}
</script>
