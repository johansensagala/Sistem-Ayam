<template>
    <div class="relative min-w-[70px]" ref="dropdownContainer">
        <div class="" :class="{ 'mb-3': label }">
            <label for="" class="">{{ label }}</label>
        </div>
        <div class="flex ">
            <div @click="toggleDropdown"
                class="w-full text-left p-2 pl-4 form-control h-full text-[14px] rounded focus:outline-none focus:ring focus:border-blue-300 border-0"
                :class="{ '!border-red-500': error }">
                <div class="flex justify-between items-center " :class="{ 'text-gray-500': selectedItem }">
                    <div v-if="depend">
                        <p v-if="data.length < 1">{{ depend }}</p>
                        <p v-else>{{ selectedItem || text }}</p>
                    </div>
                    <div v-else>
                        <p v-if="selectedItem" class="font-semibold">{{ selectedItem }}</p>
                        <p v-else>{{ text || 'Choose Option' }}</p>
                    </div>
                    <i class="fas fa-caret-down text-gray-500"></i>
                </div>
            </div>
            <div v-if="wSlot" class="ml-4">
                <slot></slot>
            </div>
        </div>
        <div v-show="isDropdownOpen" class="absolute z-10 top-15 w-full mt-1" ref="dropdownChild"
            :class="{ 'error': error }">
            <ul class="relative shadow-lg border rounded bg-white ">
                <li class="p-2" v-if="select2">
                    <input ref="inputSelected" type="text" v-model="searchQuery" @input="$event.target.composing = false"
                        class="w-full p-2 border-b form-control focus-visible:border-rkYellow focus-visible:ring-rkYellow focus-visible:outline-rkYellow"
                        placeholder="Cari opsi..." autocomplete="off" />
                </li>
                <li class="overflow-y-auto max-h-40">
                    <p v-for="(option, index) in filteredOptions" :key="option.id" @click="selectOption(option)"
                        :class="{ 'bg-slate-200': selectedItem === option.name }"
                        class="p-2 cursor-pointer text-gray-500 hover:bg-gray-100" v-html="option.name">

                    </p>
                </li>
                <li v-if="filteredOptions.length === 0 && searchQuery" class="p-2 text-gray-500">
                    No Data
                </li>
                <li v-if="filteredOptions.length === 0 && !searchQuery" class="p-2 text-gray-500">
                    No Data
                </li>
            </ul>
        </div>
        <p v-if="error" class="mt-2 text-red-700 font-light text-sm">
            {{ error[0] }}
        </p>
    </div>
</template>

<script>
export default {
    props: {
        error: {
            type: [Array, String],
            default: ''
        },
        isLoading: {
            type: Boolean,
            default: true,
        },
        label: {
            type: String,
            default: "",
        },
        labelClass: {
            type: String,
            default: "",
        },
        text: {
            type: String,
            default: "",
        },
        select2: {
            type: Boolean,
            default: false,
        },
        data: {
            type: Array,
            default: () => [],
        },
        multiple: {
            type: Boolean,
            default: false,
        },
        // data: null,
        depend: {
            type: String,
            default: "",
        },
        search: {
            type: [String, Number],
            default: 0,
        },
        pData: {
            type: String,
            default: 'id'
        },
        sData: {
            type: String,
            default: 'name'
        },
        wSlot: {
            type: Boolean,
            default: false
        },
        disableClick: {
            type: Boolean,
            default: true
        }
    },
    data() {
        return {
            isDropdownOpen: false,
            selectedItem: "",
            searchQuery: "",
            select: "",
            dropdownPosition: false
        };
    },
    watch: {
        searchQuery(newSearch, oldSearch) {
        },
        search(newSearch, oldSearch) {
            if (this.pData == 'id') {
                this.select = this.data.find(
                    (item) => parseInt(item.id) === parseInt(newSearch)
                )
            } else {
                this.select = this.data.find(
                    (item) => item.name == this.search
                );
            }
            if (this.select) {
                this.selectedItem = this.select.name;

            } else {
                this.selectedItem = "";

            }
        },
    },
    computed: {
        filteredOptions(props) {
            if (props.search) {
                if (props.pData == 'id') {
                    this.select = this.data.find(
                        (item) => parseInt(item.id) === parseInt(props.search)
                    );
                    // console.log(this.search)
                    // console.log(this.data)
                } else {
                    this.select = this.data.find(
                        (item) => (item.name).toString() === (this.search).toString()
                    );
                    // console.log(this.search)
                    // console.log(this.data)
                }
                if (this.select) {
                    this.selectedItem = this.select.name;
                }
            }
            this.data.map((item) =>
                item.name = item[props.sData]
            )
            // console.log(props.data)
            // console.log(props.search)
            return this.data.filter((data) =>
                (data[props.sData].toString()).toLowerCase().includes(this.searchQuery.toLowerCase())
            );
        },
    },
    methods: {
        toggleDropdown(props) {
            this.isDropdownOpen = !this.isDropdownOpen;

            this.calculateDropdownPosition();

            if (this.isDropdownOpen && this.select2) {
                this.$nextTick(() => {
                    this.$refs.inputSelected.focus();
                });
            }
        },
        selectOption(option) {
            if (!option.notClick) {
                if (this.disableClick) {
                    if (this.selectedItem == option.name) {
                        this.selectedItem = '';
                        if (this.pData == 'id') {
                            this.$emit("update:search", null);
                        } else {
                            this.$emit("update:search", '');
                        }
                    } else {
                        this.selectedItem = option.name;
                        if (this.pData == 'id') {
                            this.$emit("update:search", parseInt(option.id));
                        } else {
                            this.$emit("update:search", option.name);
                        }
                    }
                } else {
                    this.selectedItem = option.name;
                    if (this.pData == 'id') {
                        this.$emit("update:search", parseInt(option.id));
                    } else {
                        this.$emit("update:search", option.name);
                    }
                }

            }
            this.isDropdownOpen = false;
        },
        filterOptions() { },
        closeDropdownOnClickOutside(event) {
            if (!this.$refs.dropdownContainer.contains(event.target)) {
                this.isDropdownOpen = false;
            }
        },
        calculateDropdownPosition() {
            this.$nextTick(() => {
                if (this.isDropdownOpen) {
                    const dropdownContainer = this.$refs.dropdownChild;
                    const dropdownRect = dropdownContainer.getBoundingClientRect();
                    const windowHeight = window.innerHeight;
                    const dropdownHeight = dropdownRect.height;
                    const dropdownTop = dropdownRect.top;
                    const dropdownBottom = dropdownRect.bottom;
                    const compareHeight = windowHeight - dropdownHeight

                    // if(compareHeight > 20)
                    const bottomWindowLimit = windowHeight - 10;
                    const minDropdown = dropdownTop + dropdownHeight
                    const minDropdown2 = dropdownBottom + dropdownHeight + 100
                    let checker = true
                    if (!this.dropdownPosition) {
                        checker = minDropdown > bottomWindowLimit;

                    } else {

                        checker = minDropdown2 > bottomWindowLimit;
                    }
                    //250 + 35 > 391
                    //285 > 391
                    // console.log(dropdownContainer)
                    // console.log(dropdownRect)
                    // console.log(windowHeight)
                    // console.log(dropdownHeight)
                    // console.log(dropdownTop)
                    // console.log(minDropdown)
                    // console.log('ini compare: ' + compareHeight)
                    // console.log(`inimindropdown2: ` + minDropdown2)
                    // console.log(bottomWindowLimit)
                    // console.log(checker)


                    if (checker) {
                        if (!this.dropdownPosition) {
                            this.dropdownPosition = true
                            dropdownContainer.classList.add('dropdown-above');
                        }
                    } else {
                        if (this.dropdownPosition) {
                            this.dropdownPosition = false
                            dropdownContainer.classList.remove('dropdown-above');
                        }
                    }
                }
            })
        },
        handleScroll() {
            this.calculateDropdownPosition();
        },
    },
    mounted() {
        document.addEventListener("click", this.closeDropdownOnClickOutside);
        window.addEventListener('scroll', this.handleScroll);

    },
    beforeUnmount() {
        document.removeEventListener("click", this.closeDropdownOnClickOutside);
        window.removeEventListener('scroll', this.handleScroll);

    },
};
</script>

<style scoped>
.dropdown-above {
    bottom: 50%;
    top: auto;
}

.error.dropdown-above {
    bottom: 65%;
    top: auto;
}
</style>
