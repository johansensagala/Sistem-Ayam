<template>
    <div class="relative min-w-[60px]" ref="dropdownContainer">
        <div class="" :class="{ 'mb-3': label }">
            <label for="" class="">{{ label }}</label>
        </div>
        <div class="flex">
            <div @click="toggleDropdown"
                class="w-full text-left p-2 pl-4 form-control h-full text-[14px] rounded focus:outline-none focus:ring focus:border-blue-300 border-0"
                :class="{ '!border-red-500': error }">
                <div class="flex justify-between items-center " :class="{ 'text-black': selectedItem }">
                    <div v-if="depend">
                        <p v-if="data.length < 1">{{ depend }}</p>
                        <p v-else>{{ selectedItem || text }}</p>
                    </div>
                    <p v-else>{{ selectedItem || text }}</p>
                    <i class="fas fa-caret-down text-black"></i>
                </div>
            </div>
            <div>
                <slot></slot>
            </div>
        </div>
        <div v-show="isDropdownOpen" class="absolute z-10 top-15 w-full mt-1">
            <ul class="relative mb-10 shadow-lg border rounded bg-white">
                <li class="p-2" v-if="select2">
                    <input ref="inputSelected" type="text" v-model="searchQuery" @input="$event.target.composing = false"
                        class="w-full p-2 border-b form-control focus-visible:border-rkYellow focus-visible:ring-rkYellow focus-visible:outline-rkYellow"
                        placeholder="Cari opsi..." autocomplete="off" />
                </li>
                <li class="overflow-y-auto max-h-72">
                    <p v-for="(option, index) in filteredOptions" :key="option.id" @click="selectOption(option)"
                        :class="{ 'bg-slate-200': selectedItem === option.name }"
                        class="p-2 cursor-pointer text-black hover:bg-gray-100">
                        {{ option.name }}
                    </p>
                </li>
                <li v-if="filteredOptions.length === 0 && searchQuery" class="p-2 text-gray-500">
                    No Data.
                </li>
                <li v-if="filteredOptions.length === 0" class="p-2 text-gray-500">
                    No Data
                </li>
            </ul>
        </div>
        <p v-if="error" class="mt-2 text-red-700 font-light text-sm">
            {{ error[0] }}
        </p>
    </div>
</template>

<script>
export default {
    props: {
        error: {
            type: [Array, String],
            default: ''
        },
        isLoading: {
            type: Boolean,
            default: true,
        },
        label: {
            type: String,
            default: "",
        },
        text: {
            type: String,
            default: "",
        },
        select2: {
            type: Boolean,
            default: false,
        },
        data: {
            type: Array,
            default: () => [],
        },
        multiple: {
            type: Boolean,
            default: false,
        },
        // data: null,
        depend: {
            type: String,
            default: "",
        },
        search: {
            type: [String, Number],
            default: 0,
        },
        pData: {
            type: String,
            default: 'id'
        },
        sData: {
            type: String,
            default: 'id'
        }
    },
    data() {
        return {
            isDropdownOpen: false,
            selectedItem: "",
            searchQuery: "",
            select: "",
        };
    },
    watch: {
        searchQuery(newSearch, oldSearch) {
        },
        search(newSearch, oldSearch) {
            if (this.pData == 'id') {
                this.select = this.data.find(
                    (item) => parseInt(item.id) === parseInt(newSearch)
                )
            } else {
                this.select = this.data.find(
                    (item) => item.name == this.search
                );
            }
            if (this.select) {
                this.selectedItem = this.select.name;

            } else {
                this.selectedItem = "";

            }
        },
    },
    computed: {
        filteredOptions(props) {
            if (props.search) {

                if (props.pData == 'id') {
                    this.select = this.data.find(
                        (item) => parseInt(item.id) === parseInt(props.search)
                    );
                } else {
                    this.select = this.data.find(
                        (item) => (item.name).toString() === (this.search).toString()
                    );
                    console.log(this.search)
                    console.log(this.data)
                }
                if (this.select) {
                    this.selectedItem = this.select.name;
                }
            }

            return this.data.filter((data) =>
                (data.name.toString()).toLowerCase().includes(this.searchQuery.toLowerCase())
            );
        },
    },
    methods: {
        toggleDropdown(props) {
            this.isDropdownOpen = !this.isDropdownOpen;
            if (this.isDropdownOpen && props.select2) {
                this.$nextTick(() => {
                    this.$refs.inputSelected.focus();
                });
            }
        },
        selectOption(option) {
            if (!option.notClick) {
                this.selectedItem = option.name;
                if (this.pData == 'id') {
                    this.$emit("update:search", parseInt(option.id));
                } else {
                    this.$emit("update:search", option.name);
                }
            }
            this.isDropdownOpen = false;
        },
        filterOptions() { },
        closeDropdownOnClickOutside(event) {
            if (!this.$refs.dropdownContainer.contains(event.target)) {
                this.isDropdownOpen = false;
            }
        },
    },
    mounted() {
        document.addEventListener("click", this.closeDropdownOnClickOutside);
    },
    beforeUnmount() {
        document.removeEventListener("click", this.closeDropdownOnClickOutside);
    },
};
</script>
