<template>
    <div class="relative min-w-[70px]" ref="dropdownContainer">
        <div class="" :class="{ 'mb-3': label }">
            <label for="" class="">{{ label }}</label>
        </div>
        <div class="flex ">
            <div @click="toggleDropdown"
                class="w-full text-left p-2 pl-4 form-control h-full text-[14px] rounded focus:outline-none focus:ring focus:border-blue-300 border-0"
                :class="{ '!border-red-500': error }">
                <div class="flex justify-between items-center " :class="{ 'text-gray-500': selectedItem }">
                    <div v-if="depend">
                        <p v-if="data.length < 1">{{ depend }}</p>
                        <p v-else>{{ selectedItem || text }}</p>
                    </div>
                    <div v-else>
                        <p v-if="selectedItem" class="font-semibold">{{ selectedItem }}</p>
                        <p v-else>{{ text || 'Choose Option' }}</p>
                    </div>
                    <i class="fas fa-caret-down text-gray-500"></i>
                </div>
            </div>
            <div v-if="wSlot" class="ml-4">
                <slot></slot>
            </div>
        </div>
        <div v-show="isDropdownOpen" class="absolute z-[49] top-15 w-full mt-1" ref="dropdownChild"
            :class="{ 'error': error }">
            <ul class="relative shadow-lg border rounded bg-white ">
                <li class="p-2" v-if="select2">
                    <input ref="inputSelected" type="text" v-model="searchQuery[sData]"
                        @input="$event.target.composing = false"
                        class="w-full p-2 border-b form-control focus-visible:border-rkYellow focus-visible:ring-rkYellow focus-visible:outline-rkYellow"
                        placeholder="Search Data..." autocomplete="off" />
                </li>
                <li class="overflow-y-auto max-h-40" ref="dropdownList">
                    <div v-if="isLoading && initLoading">
                        <p class="flex flex-wrap w-full p-2 justify-center">
                            <Spinner />
                        </p>
                    </div>
                    <div v-else>
                        <p class="p-2" v-if="filteredOptions.length === 0 && !isLoading">
                            No Data
                        </p>
                        <p v-if="!checkItems && !searchQuery[sData] && filteredOptions.length > 0 && selectedItem"
                            :class="{ 'bg-slate-200': selectedItem === search[sData] }"
                            class="p-2 cursor-pointer text-gray-500 hover:bg-gray-100">
                            {{ selectedItem }}
                        </p>
                        <p v-if="!isLoading" v-for="(option, index) in filteredOptions" :key="option.id"
                            @click="selectOption(option)"
                            :class="{ 'bg-slate-200 selected': selectedItem === option[sData] }"
                            class="p-2 cursor-pointer text-gray-500 hover:bg-gray-100" v-html="option[sData]">
                        </p>
                        <p v-show="!finish && !initLoading || isLoading" class="flex flex-wrap w-full p-2 justify-center">
                            <Spinner />
                        </p>
                    </div>
                </li>
            </ul>
        </div>
        <p v-if="error" class="mt-2 text-red-700 font-light text-sm">
            {{ error[0] }}
        </p>
    </div>
</template>

<script setup>
import debounce from 'lodash.debounce'
const props = defineProps({
    error: {
        type: [Array, String],
        default: ''
    },
    isLoading: {
        type: Boolean,
        default: true,
    },
    label: {
        type: String,
        default: "",
    },
    labelClass: {
        type: String,
        default: "",
    },
    text: {
        type: String,
        default: "",
    },
    select2: {
        type: Boolean,
        default: false,
    },
    data: {
        type: Array,
        default: () => [],
    },
    multiple: {
        type: Boolean,
        default: false,
    },
    depend: {
        type: String,
        default: "",
    },
    isDepend: {
        type: Boolean,
        default: false,
    },
    dependSelect: {
        type: [String, Number],
        default: '',
    },
    search: {
        type: [String, Number, Object],
        default: 0,
    },
    pData: {
        type: String,
        default: 'id'
    },
    sData: {
        type: String,
        default: 'name'
    },
    wSlot: {
        type: Boolean,
        default: false
    },
    disableClick: {
        type: Boolean,
        default: true
    },
    fetchFunction: {
        type: Function,
        default: null
    },
    total: {
        type: Object,
        default: {}
    },
    custom: {
        type: Boolean,
        default: false
    }
})
const emit = defineEmits()
//Refs
const inputSelected = ref(null)
const dropdownContainer = ref(null)
const dropdownChild = ref(null)
const dropdownList = ref(null)
const dropdownPosition = ref(false)
//Data
const selectedItem = ref(null)
const isDropdownOpen = ref(false)
const currentPage = ref(1)
const pageSize = ref(100)
// const total = ref(0)
const initCurrentPage = ref(1)
const initPageSize = ref(100)
const initQueryParams = ref(null)
const isLoading = ref(false)
const initLoading = ref(true)
const realData = ref([])
const select = ref('')
const isSelect = ref(false)
const resetDepend = ref(true)
const filter = ref(true)
const extend = ref(false)
const finish = ref(false)
const searchQuery = ref({
    [props.sData]: ''
})
const queryParams = computed(() => useFilterStore().queryParams)

const toggleDropdown = async () => {
    isDropdownOpen.value = !isDropdownOpen.value
    isLoading.value = true
    // console.log(isLoading.value)
    if (!isDropdownOpen.value) {
        searchQuery.value[props.sData] = ''
    }
    if (isDropdownOpen.value) {
        await getDataFetch()
    }
    if (isDropdownOpen.value && props.select2) {
        nextTick(() => {
            inputSelected.value.focus()
            const selectedOption = dropdownContainer.value.querySelector('.selected');
            if (selectedOption) {
                // Gulir ke opsi yang dipilih
                selectedOption.scrollIntoView({ behavior: 'smooth', block: 'nearest', inline: 'nearest' });
            }
        })
    }

}

const selectOption = (data) => {
    try {
        console.log(data)
        selectedItem.value = data[props.sData]
        isDropdownOpen.value = false
        isSelect.value = true
        searchQuery.value[props.sData] = ''
        handleFilter(searchQuery.value)
        if (typeof props.fetchFunction === 'function' || props.custom) {
            emit("update:search", data)
        } else {
            emit("update:search", data[props.pData])
        }
    } catch (e) {
        console.log(e)
    }
}

const combineData = async () => {
    realData.value = [...realData.value, ...props.data]
}

const getDataFetch = async () => {
    try {
        if (!props.isDepend || props.isDepend && props.dependSelect !== '') {
            if (typeof props.fetchFunction === 'function') {
                if (initCurrentPage.value !== currentPage.value || initPageSize.value !== pageSize.value || initQueryParams.value !== queryParams.value && isDropdownOpen.value || resetDepend.value && isDropdownOpen.value) {
                    initCurrentPage.value = currentPage.value
                    initPageSize.value = pageSize.value
                    initQueryParams.value = queryParams.value
                    isLoading.value = true
                    initLoading.value = false
                    resetDepend.value = false


                    if (!props.isDepend) {
                        await props.fetchFunction(currentPage.value, pageSize.value, queryParams.value)
                    } else {
                        await props.fetchFunction(props.dependSelect, currentPage.value, pageSize.value, queryParams.value)
                    }
                    if (extend.value) {
                        await combineData()
                        extend.value = false
                    } else {
                        realData.value = props.data
                    }
                    // console.log(realData.value.length)
                    // console.log(props.total.total)
                    if (realData.value.length == props.total.total) {
                        finish.value = true
                    } else {
                        finish.value = false
                    }
                }

            }
        }
        isLoading.value = false
        if (isDropdownOpen.value && props.select2) {
            nextTick(() => {
                const selectedOption = dropdownContainer.value.querySelector('.selected');
                if (selectedOption) {
                    // Gulir ke opsi yang dipilih
                    selectedOption.scrollIntoView({ behavior: 'smooth', block: 'nearest', inline: 'nearest' });
                }
            })
        }
    } catch (e) {
        console.log(e)
        isLoading.value = false
    }
}

const moveDropdownToBody = () => {
    const dropdownChildElement = dropdownChild.value;
    const dropdownContainerElement = dropdownContainer.value;
    if (dropdownChildElement && dropdownContainerElement) {
        // Hitung koordinat klik terhadap jendela
        const rect = dropdownContainerElement.getBoundingClientRect();
        const top = rect.top + window.scrollY;
        const left = rect.left + window.scrollX;

        // Set posisi absolut elemen dropdownChild saat memindahkannya ke dalam <body>
        dropdownChildElement.style.position = 'absolute';
        dropdownChildElement.style.top = `${top}px`;
        dropdownChildElement.style.left = `${left}px`;

        // Append dropdownChild ke dalam <body>
        document.body.appendChild(dropdownChildElement);
    }
};


// Metode untuk menghapus elemen dropdown dari <body>
const removeDropdownFromBody = () => {
    const dropdownChildElement = dropdownChild.value;
    if (dropdownChildElement && dropdownChildElement.parentNode === document.body) {
        document.body.removeChild(dropdownChildElement);
    }
};

const filteredOptions = computed(() => {
    if (typeof props.fetchFunction === 'function') {
        return realData.value
    } else {
        select.value = props.data.find(
            (item) => item[props.pData] == props.search
        )
        if (select.value) {
            selectedItem.value = select.value[props.sData]
        }
        return props.data.filter(
            (item) => (item[props.sData].toString()).toLowerCase().includes((searchQuery.value[props.sData].toString()).toLowerCase())
        )
    }
})

const checkItems = computed(() => {
    return realData.value.find(
        (item) => item[props.sData] == selectedItem.value
    )
})

const handleFilter = (goFilter) => {
    useFilterStore().handleFilter(goFilter)
}

const debouceFilter = debounce((newQuery) => {
    handleFilter(newQuery, props.loadFilter)
}, 500)

const delayedFetchData = debounce(() => {
    getDataFetch()
}, 500);

watch(searchQuery.value, (newQuery) => {
    if (isDropdownOpen) {
        if (typeof props.fetchFunction === 'function') {
            realData.value = []
            isLoading.value = true
            currentPage.value = 1
            debouceFilter(newQuery)
        }
    }
})
// watch(() => isDropdownOpen.value, (newValue) => {
//     if (newValue) {
//         moveDropdownToBody();
//     } else {
//         removeDropdownFromBody();
//     }
// })

watch(() => props.dependSelect, (newQuery) => {
    resetDepend.value = true
})

watch(() => props.search, (newSearch) => {
    if (typeof props.fetchFunction === 'function') {
        selectedItem.value = props.search[props.sData]
    } else {
        select.value = realData.value.find(
            (item) => item[props.pData] == props.search
        )
        if (select.value) {
            selectedItem.value = select.value[props.sData]
        } else {
            selectedItem.value = ''
        }
    }
})

// watch([queryParams], () => {
//     delayedFetchData()
// })
watch([currentPage, pageSize, queryParams], () => {
    delayedFetchData()
})
let isMouseDownInsideDropdown = false;
let isMouseDownOutSideDropdown = false;


const closeDropdownOnClickOutside = (event) => {
    const clickedInsideDropdown = dropdownContainer.value.contains(event.target);
    if (!clickedInsideDropdown && !isMouseDownOutSideDropdown && isDropdownOpen.value) {
        isDropdownOpen.value = false;
        searchQuery.value[props.sData] = '';
    }
};

const handleDropdownScroll = () => {

    const bottomPosition = dropdownList.value.scrollHeight - dropdownList.value.clientHeight;
    if (bottomPosition <= dropdownList.value.scrollTop && !isLoading.value) {
        if (realData.value.length < props.total.total) {
            extend.value = true
            currentPage.value = currentPage.value + 1
        }
    }

}

const calculateDropdownPosition = () => {
    nextTick(() => {
        if (isDropdownOpen.value) {
            const dropdownContainer = dropdownChild.value;
            const dropdownRect = dropdownContainer.getBoundingClientRect();
            const windowHeight = window.innerHeight;
            const dropdownHeight = dropdownRect.height;
            const dropdownTop = dropdownRect.top;
            const dropdownBottom = dropdownRect.bottom;
            const compareHeight = windowHeight - dropdownHeight

            // if(compareHeight > 20)
            const bottomWindowLimit = windowHeight - 10;
            const minDropdown = dropdownTop + dropdownHeight
            const minDropdown2 = dropdownBottom + dropdownHeight + 100
            let checker = true
            if (!dropdownPosition.value) {
                checker = minDropdown > bottomWindowLimit;

            } else {

                checker = minDropdown2 > bottomWindowLimit;
            }
            //250 + 35 > 391
            //285 > 391
            console.log(dropdownContainer)
            console.log(dropdownRect)
            console.log(windowHeight)
            console.log(dropdownHeight)
            console.log(dropdownTop)
            console.log(minDropdown)
            console.log('ini compare: ' + compareHeight)
            console.log(`inimindropdown2: ` + minDropdown2)
            console.log(bottomWindowLimit)
            console.log(checker)


            if (checker) {
                if (!dropdownPosition.value) {
                    dropdownPosition.value = true
                    dropdownContainer.classList.add('dropdown-above');
                }
            } else {
                if (dropdownPosition.value) {
                    dropdownPosition.value = false
                    dropdownContainer.classList.remove('dropdown-above');
                }
            }
        }
    })
}

const handleMouseDown = () => {
    isMouseDownInsideDropdown = dropdownContainer.value.contains(event.target);

}
const handleMouseUp = () => {
    if (isMouseDownInsideDropdown) {
        isMouseDownOutSideDropdown = true
    } else {
        isMouseDownOutSideDropdown = false
    }

}

onMounted(() => {
    document.addEventListener("click", closeDropdownOnClickOutside);
    document.addEventListener("mousedown", handleMouseDown);
    document.addEventListener("mouseup", handleMouseUp);
    // window.addEventListener('scroll', calculateDropdownPosition);
    dropdownList.value.addEventListener("scroll", handleDropdownScroll)
    dropdownContainer.value.addEventListener("scroll", handleDropdownScroll)
    realData.value = props.data
})

onBeforeUnmount(() => {
    document.removeEventListener("click", closeDropdownOnClickOutside);
    document.removeEventListener("mousedown", handleMouseDown);
    document.removeEventListener("mouseup", handleMouseUp);
    // window.removeEventListener('scroll', calculateDropdownPosition);
    dropdownList.value.removeEventListener("scroll", handleDropdownScroll)
    dropdownContainer.value.removeEventListener("scroll", handleDropdownScroll)
})

onUnmounted(() => {
    // Pastikan untuk menghapus elemen dropdown dari <body> saat komponen di-unmount
    removeDropdownFromBody();
});

</script>

<style scoped>
.dropdown-above {
    bottom: 50%;
    top: auto;
}

.error.dropdown-above {
    bottom: 65%;
    top: auto;
}
</style>
