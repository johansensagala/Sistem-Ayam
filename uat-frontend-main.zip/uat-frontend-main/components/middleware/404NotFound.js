export default function ({ redirect }) {
    // Redirect to homepage
    redirect('/')
}
