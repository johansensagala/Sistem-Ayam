<template>
    <div>
        <div ref="buttonModalCheck" v-if="!wb">
            <div v-if="!withOutButton">
                <Button v-if="buttonModal" @click="toggleModal" :backgroundColor="bg" :text="textButton" :width="width"
                    :className="className" :isDisabled="isDisabled">
                    {{ label }}
                </Button>
                <div v-else @click="toggleModal">
                    <div
                        class='w-[35px] h-[35px] flex justify-center items-center bg-primary rounded text-white cursor-pointer'>
                        <i class='fas fa-plus'></i>
                    </div>
                </div>
            </div>
        </div>

        <div class="fixed top-0 inset-0 block items-center justify-center z-[50] overflow-y-auto h-100 bg-[#00000040]"
            v-show="isOpen">
            <div class="relative block">
                <div class="modal-container flex items-center my-5 relative bg-white text-light w-full lg:max-w-lg md:max-w-md mx-auto rounded shadow-lg z-50 "
                    ref="modalModal">
                    <!-- Modal content -->
                    <div class="modal-content py-4 text-left px-6 mx-auto w-full h-full">
                        <!-- Modal body -->
                        <div class="modal-body mt-4 text-black">
                            <!-- {{ width }} -->
                            <slot></slot>
                        </div>

                        <!-- Modal footer -->
                        <div class="modal-footer mt-4 flex justify-end space-x-3">
                            <Button :disabled="disabled" @click="customFunction" width="inline-block">Submit</Button>
                            <Button width="inline-block" backgroundColor="bg-slate-300" text="text-white"
                                @click="toggleModal">Cancel</Button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>
  
<script setup>
const emit = defineEmits()
const isOpen = ref(false);
const modalModal = ref(null)
const buttonModalCheck = ref(null)

const props = defineProps({
    label: {
        type: String,
        default: 'Button',
    },
    isDisabled: {
        type: Boolean,
        default: false,
    },
    wb: {
        type: Boolean,
        default: false,
    },
    type: {
        type: String,
        default: 'delete',
    },
    bg: {
        default: 'bg-primary',
    },
    textButton: {
        default: 'text-buttonText',
    },
    width: {
        default: 'w-full',
    },
    className: {
        default: '',
    },
    text: {
        type: String,
        default: '',
    },
    onModal: {
        type: Boolean,
        default: false,
    },
    buttonModal: {
        type: Boolean,
        default: true,
    },
    disabled: {
        type: Boolean,
        default: false
    },
    withOutButton: {
        type: Boolean,
        default: false
    },
    initModal: {
        type: Boolean,
        default: false
    }
});

const initModal = ref(props.onModal)
const checkModal = ref(false)

const textBody = computed(() => {
    if (props.type === 'delete') {
        return `Apakah Kamu Yakin ingin ${props.label} item ini ?`;
    } else {
        return props.text;
    }
});

const toggleModal = () => {
    isOpen.value = !isOpen.value;
    checkModal.value = !checkModal.value
    console.log('check')
    if (isOpen.value) {
        document.body.classList.add('modal-open');
    } else {
        document.body.classList.remove('modal-open');
    }
};

const customFunction = () => {
    if (!props.onModal) {
        toggleModal();
    }
    console.log('hale')
    emit('update:goFunction');
};

watch(() => props.onModal, () => {
    toggleModal()
})

const closeModal = () => {
    emit('close');
};

const updateOverlayPosition = () => {
    const overlay = document.querySelector('.modal-overlay');
    if (overlay) {
        const scrollY = window.scrollY || window.pageYOffset;
        overlay.style.top = `${scrollY}px`;
    }
};

const closeModalOnClickOutside = (event) => {
    const clickedInsideModal = modalModal.value.contains(event.target);
    const clickedInsideModal2 = buttonModalCheck.value.contains(event.target);
    if (!clickedInsideModal2 && !clickedInsideModal && isOpen.value && !isMouseDownOutSideDropdown) {
        isOpen.value = false;
        document.body.classList.remove('modal-open');
    }
};

let isMouseDownInsideDropdown = false;
let isMouseDownOutSideDropdown = false;

const handleMouseDown = () => {
    isMouseDownInsideDropdown = modalModal.value.contains(event.target);;

}
const handleMouseUp = () => {
    if (isMouseDownInsideDropdown) {
        isMouseDownOutSideDropdown = true
    } else {
        isMouseDownOutSideDropdown = false
    }

}

onMounted(() => {
    // document.addEventListener("click", closeModalOnClickOutside);
    document.addEventListener("mousedown", handleMouseDown);
    document.addEventListener("mouseup", handleMouseUp);
    isOpen.value = props.initModal

})

onBeforeUnmount(() => {
    // document.removeEventListener("click", closeModalOnClickOutside);
    document.removeEventListener("mousedown", handleMouseDown);
    document.removeEventListener("mouseup", handleMouseUp);
    document.body.classList.remove('modal-open');

})

</script>


  
<style scoped>
/* Gaya CSS sesuai kebutuhan Anda */
</style>
  