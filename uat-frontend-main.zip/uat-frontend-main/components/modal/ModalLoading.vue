<template>
    <div class=" fixed inset-0 flex items-center justify-center z-[51]" v-if="isLoading">
        <div class="modal-overlay fixed inset-0 bg-black opacity-50"></div>

        <div class="modal-container bg-white w-11/12 md:max-w-md mx-auto rounded shadow-lg z-50 overflow-y-auto">
            <!-- Modal content -->
            <div class="modal-content py-8 text-left px-6">
                <!-- Modal body -->
                <div class="modal-body flex justify-center">
                    <!-- Isi konten modal di sini -->
                    <div class="flex flex-col items-center space-y-5">
                        <Spinner />
                        <p class="text-black ">Loading ...</p>
                    </div>
                </div>

                <!-- Modal footer -->
            </div>
        </div>
    </div>
</template>

<script>

export default {
    props: {
        isLoading: {
            type: Boolean,
            default: false,
        },
    },

};
</script>

<style scoped>
/* Gaya CSS sesuai kebutuhan Anda */
</style>
