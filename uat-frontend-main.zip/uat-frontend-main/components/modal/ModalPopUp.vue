<template>
    <div>
        <div class=" fixed inset-0 flex items-center justify-center z-[100]" v-if="isOpen && !useWebStore().isLoading">
            <div class="modal-overlay fixed inset-0 bg-black opacity-50" @click="toggleModal2"></div>

            <div class="modal-container bg-white w-11/12 md:max-w-md mx-auto rounded shadow-lg z-50 overflow-y-auto">
                <!-- Modal content -->
                <div class="modal-content py-4 text-left px-6">
                    <!-- Modal body -->
                    <div class="modal-body mt-4 flex-row items-center justify-center">
                        <div class="flex justify-center">
                            <div
                                class="w-16 h-16 rounded-full border-2 border-green-500 text-green-500 flex justify-center items-center">
                                <i :class="iconClasses" class="text-2xl"></i>
                            </div>
                        </div>
                        <h1 class="text-2xl text-center text-black font-bold mt-4">{{ titlePopUp }}</h1>
                        <!-- <slot></slot> -->
                        <p v-html="textPopUp" class="flex justify-center mt-2 text-center"></p>
                    </div>

                    <!-- Modal footer -->
                    <div class="modal-footer mt-4 mb-4 flex justify-center">
                        <Button width="inline-block" @click="toggleModal2()">Oke</Button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script setup>
const icon = computed(() => useWebStore().iconPopUp)
const isOpen = computed(() => useWebStore().popUpOpen);
const textPopUp = computed(() => useWebStore().textPopUp);
const titlePopUp = computed(() => useWebStore().titlePopUp);


const iconClasses = computed(() => {
    const iconMappings = {
        info: "fa-solid fa-exclamation",
        success: "fa-solid fa-check",
        default: "fa-solid fa-xmark",
    };
    return iconMappings[icon.value] ?? iconMappings["default"];
});
const toggleModal2 = () => {
    useWebStore().togglePopUp()
};
</script>

<style scoped>
/* Gaya CSS sesuai kebutuhan Anda */
</style>
