
<template>
    <div>
        <h1 class="text-2xl font-bold mb-4 text-gray-700">Buat Asrama</h1>
        <Card>
            <div class="space-y-4">
                <Input label="Nama Asrama" v-model="form.name" />
                <div>
                    <label for="">Harga Asrama</label>
                    <input class="form-control w-full mt-2" :value="filterPrice[0] ?? 0"
                        @input="validateInput(0, $event.target.value)" type="text">
                </div>
                <div>
                    <label for="">Harga Cafetaria</label>
                    <input class="form-control w-full mt-2" :value="filterPrice[1] ?? 0"
                        @input="validateInput(1, $event.target.value)" type="text">
                </div>
                <div>
                    <Button width="w-fit" @click="handleSubmit()">Submit</Button>
                </div>
            </div>
        </Card>
    </div>
</template>

<script setup>
import initSaldo from '@/utils/currency'
const { data, postData, findData, error } = useHostelComposables()
const form = ref({
    name: '',
    price_hostel: '',
    price_cafetaria: ''
})
const edit = ref(false)
const price = ref([])
const route = useRoute()
const filterPrice = computed(() => {
    return price.value.map(item => item.price)
})
const validateInput = (index, value) => {
    try {
        if (!price.value[index]) {
            price.value[index] = {
                real: 0,
                price: 0
            }
        }
        price.value[index].real = value.toString().replace(/\D/g, '')

        if (value == '') {
            price.value[index].price = 0
        } else {
            price.value[index].price = initSaldo(price.value[index].real)
        }
    } catch (e) {
        console.log(e)
    }
};
const handleSubmit = async () => {
    try {
        useWebStore().onLoading()
        form.value.price_cafetaria = price.value[1].real
        form.value.price_hostel = price.value[0].real
        if (route.params.id) {
            await postData(form.value, true, route.params.id)
        } else {
            await postData(form.value)
        }
        useWebStore().offLoading()
        navigateTo('/admin/hostels')
    } catch (e) {
        useWebStore().offLoading()
        console.log(e)
    }
}
const getData = async () => {
    try {
        useWebStore().onLoading()
        await findData(route.params.id)
        form.value = {
            name: data.value.data.name,
            price_hostel: data.value.data.price_hostel,
            price_cafetaria: data.value.data.price_cafetaria
        }
        console.log(form.value)
        validateInput(0, form.value.price_hostel)
        validateInput(1, form.value.price_cafetaria)
        console.log('iniprice')
        console.log(price.value)
        useWebStore().offLoading()
    } catch (e) {
        useWebStore().offLoading()

    }
}
onMounted(() => {
    if (route.params.id) {
        getData()
    }
})
</script>