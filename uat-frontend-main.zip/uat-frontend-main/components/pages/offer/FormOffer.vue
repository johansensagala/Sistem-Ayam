<template>
    <div>
        <h1 class="text-2xl font-bold mb-4 text-gray-700">Buat Pembayaran</h1>
        <!-- <p>{{ parentCode }}</p> -->
        <Card>
            <div class="space-y-4" v-if="parentCode">
                <!-- <Input type="number" label="SKS" v-model="form.sks" /> -->
                <label for="">SKS</label>
                <input class="form-control w-full mt-2" type="number" v-model="form.sks"
                    @input="validateInput(4, $event.target.value, true)">
                <Select :data="host" label="Status Tinggal" :search="statusHost" @update:search="statusHost = $event" />
                <div v-if="statusHost == 1">
                    <Select label="Kategori Asrama" :data="dataHostel.data" @update:search="updateHostel($event)" />
                </div>
                <div>
                    <p class="font-semibold text-xl mb-2">Pembayaran</p>
                    <div class="border p-4">
                        <div class="grid grid-cols-12">
                            <div class="col-span-6 flex items-center">
                                <p>Fix</p>
                            </div>
                            <div class="col-span-6">
                                <input readonly class="form-control w-full mt-2" :value="filterPrice[0] ?? 0"
                                    @input="validateInput(0, $event.target.value)" type="text">
                            </div>
                        </div>
                        <div class="grid grid-cols-12">
                            <div class="col-span-6 flex items-center">
                                <p>Cafetaria</p>
                            </div>
                            <div class="col-span-6">
                                <input readonly class="form-control w-full mt-2" :value="filterPrice[2] ?? 0"
                                    @input="validateInput(2, $event.target.value)" type="text">
                            </div>
                        </div>
                        <div class="grid grid-cols-12">
                            <div class="col-span-6 flex items-center">
                                <p>Asrama</p>
                            </div>
                            <div class="col-span-6">
                                <input readonly class="form-control w-full mt-2" :value="filterPrice[3] ?? 0"
                                    @input="validateInput(3, $event.target.value)" type="text">
                            </div>
                        </div>
                        <div class="grid grid-cols-12">
                            <div class="col-span-6 flex items-center">
                                <div>
                                    <p>SKS</p>
                                    <p>(<span class="font-semibold">{{ initSaldo(setData.sks) }}</span> x {{ form.sks }})
                                    </p>
                                </div>
                            </div>
                            <div class="col-span-6">
                                <input readonly class="form-control w-full mt-2" :value="filterPrice[4] ?? 0" type="text">
                            </div>
                        </div>
                        <div class="grid grid-cols-12">
                            <div class="col-span-6 flex items-center">
                                <p>Total Pembayaran</p>
                            </div>
                            <div class="col-span-6">
                                <input readonly class="form-control w-full mt-2" :value="totalPrice" type="text">
                            </div>
                        </div>
                    </div>
                </div>
                <div>
                    <div class="grid grid-cols-12 gap-4">
                        <div class="col-span-12 md:col-span-6">
                            <div
                                v-if="statusHost == 1 && form.residence_id !== 0 && form.sks !== 0 && form.sks !== '' || form.sks !== 0 && form.sks !== '' && statusHost !== 1">
                                <Modal label="Cicil Pembayaran" bg="bg-yellow-500" @update:goFunction="handleCreateOffer()">
                                    <div class="space-y-4">
                                        <div>
                                            <label for="">Nominal Pembayaran</label>
                                            <input readonly class="form-control w-full mt-2" type="text"
                                                :value="totalPrice">
                                        </div>
                                        <Select label="Durasi Cicilan" :data="duration"
                                            @update:search="form.timeline = $event" />
                                        <div>
                                            <label for="">Nominal cicilan</label>
                                            <input readonly class="form-control w-full mt-2" :value="installmentPrice"
                                                type="text">
                                        </div>

                                        <!-- <Input label="Kode Orang Tua" v-model="form.parent_code" /> -->
                                    </div>
                                </Modal>
                            </div>
                            <div v-else>
                                <Button disabled backgroundColor="bg-yellow-500">Cicil Pembayaran</Button>
                            </div>
                            <!-- <Button @click="" backgroundColor="bg-yellow-500">
                                Cicil Pembayaran
                            </Button> -->
                        </div>
                        <div class="col-span-12 md:col-span-6">
                            <Button>
                                Bayar
                            </Button>
                        </div>
                    </div>
                </div>
            </div>
            <div v-else class="space-y-4">
                <Input label="Kode orang tua" v-model="parentStudent.parent_code" />
                <p class="text-red-500" v-if="parentError">{{ parentError }}</p>
                <Button @click="handleParentCode()">
                    Submit
                </Button>
            </div>
        </Card>
    </div>
</template>

<script setup>
import initSaldo from '@/utils/currency'
const { postData: offerPost } = useOfferComposables()
const { me } = useAuthComposables()
const { postParentCode } = useUserComposables()
const { data: dataHostel, fetchData: fetchHostel } = useHostelComposables()
const { data: dataSetting, findData: findSetting } = useSettingComposables()
const form = ref({
    sks: 0,
    timeline: '',
    sub_offer: 0,
    total_offer: 0,
    residence_id: 0
})
const parentStudent = ref({
    parent_code: ''
})
const setData = ref({
    sks: 0,
    fix: 0
})
const statusHost = ref(2)
const host = [
    { id: 1, name: 'Inside' },
    { id: 2, name: 'Outside' }
]
const duration = [
    { id: 3, name: '3 bulan' },
    { id: 6, name: '6 bulan' },
    { id: 12, name: '12 bulan' }
]
const parentCode = computed(() => useAuthStore().authUser.ident.parent_code)
const price = ref([])
const totalInitPrice = ref(0)
const totalPrice = ref(0)
const installmentInitPrice = ref(0)
const installmentPrice = ref(0)
const filterPrice = computed(() => {
    return price.value.map(item => item.price)
})
const parentError = ref(null)
const validateInput2 = (value) => {

    installmentInitPrice.value = value.toString().replace(/\D/g, '')
    if (value == '') {
        installmentPrice.value = 0
    } else {
        installmentPrice.value = initSaldo(installmentInitPrice.value)
    }
}
const validateInput = (index, value, sks = false) => {
    try {
        if (!price.value[index]) {
            price.value[index] = {
                real: 0,
                price: 0
            }
        }
        if (sks) {
            price.value[index].real = setData.value.sks * value
        } else {
            price.value[index].real = value.toString().replace(/\D/g, '')
        }

        if (value == '') {
            price.value[index].price = 0
        } else {
            price.value[index].price = initSaldo(price.value[index].real)
        }

        totalInitPrice.value = price.value.reduce((total, currentItem) => total + parseInt(currentItem.real), 0)
        console.log(totalInitPrice.value)
        console.log(price.value)
        totalPrice.value = initSaldo(totalInitPrice.value)
    } catch (e) {
        console.log(e)
    }
};
const updateHostel = (id) => {
    const check = dataHostel.value.data.find(item => item.id == id)
    if (check) {
        form.value.residence_id = id
        validateInput(2, check.price_cafetaria)
        validateInput(3, check.price_hostel)
    }
}
const getMe = async () => {
    try {
        useWebStore().onLoading()
        await me()
        useWebStore().offLoading()
    } catch (e) {
        console.log(e)
        useWebStore().offLoading()
    }
}
const getHostel = async () => {
    try {
        useWebStore().onLoading()
        await fetchHostel(1, 0)
        useWebStore().offLoading()
    } catch (e) {
        console.log(e)
        useWebStore().offLoading()
    }
}
const getSetting = async () => {
    try {
        useWebStore().onLoading()
        await findSetting(1)
        const response = dataSetting.value.data
        setData.value.sks = response.price_sks
        setData.value.fix = response.price_fix
        console.log(setData.value.sks)
        validateInput(0, setData.value.fix)
        // validateInput(1, setData.value.sks)
        useWebStore().offLoading()
    } catch (e) {
        console.log(e)
        useWebStore().offLoading()
    }
}

const handleRequired = () => {
    useWebStore().onPopUp('default', 'Mohon isi semua form terlebih dulu', 'Gagal')
}

const handleCreateOffer = async () => {
    try {
        useWebStore().onLoading()
        form.value.total_offer = totalInitPrice.value
        form.value.sub_offer = installmentInitPrice.value
        await offerPost(form.value)
        useWebStore().offLoading()
    } catch (e) {
        console.log(e)
        useWebStore().offLoading()
        // useWebStore().onPopUp('default', e.response.message.error_message, 'Gagal')
    }
}

const handleParentCode = async () => {
    try {
        useWebStore().onLoading()
        const response = await postParentCode(parentStudent.value, useAuthStore().getUser().ident.id)
        await getMe()
        console.log(parentCode.value)
        console.log('halo')
        useWebStore().offLoading()
    } catch (e) {
        console.log(e)
        if (e.response) {
            parentError.value = e.response.data.message
        } else {
            parentError.value = e
        }
        useWebStore().offLoading()
    }
}
onMounted(() => {
    getMe()
    getHostel()
    getSetting()
})
</script>