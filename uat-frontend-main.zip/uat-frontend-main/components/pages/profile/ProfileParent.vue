
import type userVue from '~/layouts/user.vue';

import type userVue from '~/layouts/user.vue';
<template>
    <div>
        <h1 class="text-2xl font-bold mb-4 text-gray-700">Profile</h1>
        <Card>
            <div class="space-y-4">
                <Input label="name" v-model="form.name" />
                <Input label="username" v-model="form.username" />
                <Input label="No Hp" v-model="form.phone" />
                <div class="grid grid-cols-12 gap-4">
                    <div class="col-span-3">
                        <label for="">KTP Image</label>
                        <ImageUpload v-model="form.ktp_image" @update:imageInput="form.ktp_image = $event"
                            :imageData="imageKtp" :error="error.ktp_image" />
                    </div>
                    <div class="col-span-3">
                        <label for="">KK Image</label>
                        <ImageUpload v-model="form.kk_image" @update:imageInput="form.kk_image = $event"
                            :imageData="imageKk" :error="error.kk_image" />
                    </div>
                    <div class="col-span-3">
                        <label for="">Bank Image</label>
                        <ImageUpload v-model="form.bank_image" @update:imageInput="form.bank_image = $event"
                            :imageData="imageBank" :error="error.bank_image" />
                    </div>
                </div>
                <div>
                    <Button @click="updateParent()">
                        Update
                    </Button>
                </div>
            </div>
        </Card>
    </div>
</template>
<script setup>
const { me } = useAuthComposables()
const { postData: postParent, error, findData: findParent, data: dataParent } = useParentStudentComposables()
const user = computed(() => useAuthStore().authUser)
const form = ref({
    name: '',
    username: '',
    phone: '',
    ktp_image: '',
    bank_image: '',
    kk_image: '',
})
const imageKtp = ref('')
const imageBank = ref('')
const imageKk = ref('')
const getData = async () => {
    try {
        useWebStore().onLoading()
        await me()
        await findParent(user.value.ident_id)
        console.log(dataParent.value)
        form.value.phone = user.value.phone
        form.value.name = user.value.name
        form.value.username = user.value.username
        imageKtp.value = dataParent.value.data.ktp_image
        imageKk.value = dataParent.value.data.kk_image
        imageBank.value = dataParent.value.data.bank_image
        console.log(imageBank.value)
        useWebStore().offLoading()
    } catch (e) {
        console.log(e)
        useWebStore().offLoading()
    }
}
const updateParent = async () => {
    try {
        useWebStore().onLoading()
        console.log(user)
        await postParent(form.value, true, user.value.ident_id)
        await getData()
        useWebStore().offLoading()
    } catch (e) {
        console.log(e)
        useWebStore().offLoading()
    }
}
onMounted(() => {
    getData()
})
</script>