<template>
    <div>
        <Card>
            <div>
                <Input label="name" v-model="form.name" />
                <Input label="username" v-model="form.username" />
                <Input label="phone" v-model="form.phone" />
                <Select label="Role" :data="role" @update:search="form.role = $event" />
                <div class="mt-2">
                    <Button @click="handleCreateUser()">
                        Submit
                    </Button>
                </div>
            </div>
        </Card>
    </div>
</template>
<script setup>
const { postData, error } = useUserComposables()
const form = ref({
    name: '',
    username: '',
    phone: '',
    role: ''
})
const handleCreateUser = async () => {
    try {
        useWebStore().onLoading()
        await postData(form.value)
        useWebStore().offLoading()
        navigateTo('/admin/users')
    } catch (e) {
        useWebStore().offLoading()
        console.log(e)
    }
}
const role = [
    { id: 1, name: 'superadmin' },
    { id: 2, name: 'student' },
    { id: 3, name: 'parent' }
]
</script>