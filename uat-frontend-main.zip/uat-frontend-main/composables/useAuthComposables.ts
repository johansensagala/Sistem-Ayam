export default function useAuthComposables() {
    const url = '/auth'
    const core = useCoreComposables(url)
    const useBase = useBaseComposables()

    async function me() {
        try {
            const response = await useBase.fetchData('/auth/me', 'post', '')
            console.log(response)
            useAuthStore().setAuth(response)
        } catch (error) {
            console.log(error)
        }
    }

    async function handleLogin(form: Record<string, any>) {
        try {
            const response = await useBase.post('/auth/login', 'post', form)
            if (response.data.status == false) {
                core.error.value = [];
                core.error.value.init = response.data.message
                throw response.data.message
            } else {
                await useAuthStore().setToken(response.data.access_token)
                // console.log(useAuthStore().getToken)
                await me()
                core.error.value = [];
                navigateTo('/admin/dashboard')
            }
        } catch (e: any) {
            if (e.response && e.response.status === 422) {
                const errors = e.response.data.errors;
                core.error.value = errors;
            }
            throw e
        }
    }
    async function handleRegister(form: Record<string, any>) {
        try {
            // console.log(form.username)
            const response = await useBase.post('/auth/register', 'post', form)
            if (response.data.status == false) {
                core.error.value = [];
                core.error.value.init = response.data.message
                throw response.data.message
            } else {
                core.error.value = [];
                useWebStore().onPopUp('success', 'Akun telah dibuat mohon login dan aktifasi', 'success')
                navigateTo('/login')
            }
        } catch (e: any) {
            if (e.response && e.response.status === 422) {
                const errors = e.response.data.errors;
                core.error.value = errors;
            }
            throw e
        }
    }

    async function handleLogout() {
        try {
            useWebStore().onLoading()
            await useBase.fetchData('/auth/logout', 'post', '')
            useAuthStore().setToken('')
            useAuthStore().setAuth('')
            useWebStore().offLoading()
            navigateTo('/login')
        } catch (e: any) {
            throw e
        }
    }

    async function sendCode() {
        try {
            const response = await useBase.fetchData('/auth/send-code', 'post')
        } catch (e) {
            console.log(e)
        }

    }
    async function fetchParent() {
        try {
            const response = await useBase.fetchData('/users/parent', 'get')
            return response
        } catch (e) {
            console.log(e)
        }
    }

    async function verifCode(form) {
        try {
            const response = await useBase.fetchData('/auth/verif-code', 'post', form)

        } catch (e) {
            throw e
        }
    }


    return {
        ...core,
        handleLogin,
        handleLogout,
        handleRegister,
        me,
        sendCode,
        verifCode,
        fetchParent
    }
}