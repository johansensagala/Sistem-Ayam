import axios from "axios"

export default function useBaseComposables() {
    const api = axios.create({
        baseURL: 'http://localhost:8001/api',
        headers: {
            'Content-Type': 'application/json',
            // 'Access-Control-Allow-Origin': '*',
        }
    });
    const urlLogin = '/login'
    async function fetchData(endpoint: string, method: string, params: Object = {}) {
        try {
            const response = await api.request({
                url: endpoint,
                method: method,
                params: params,
                headers: {
                    Authorization: 'Bearer ' + useAuthStore().getToken(),
                    'Content-Type': 'application/json'
                }
            });
            if (response.data.code === 500) {
                throw (response.data.message.error_message);
            }
            return response.data;
        } catch (e: any) {
            if (e.response && e.response.status === 401) {
                console.log('ini error' + e)
                useAuthStore().setToken('')
                navigateTo(urlLogin)
            } else {
                console.log(e)
                throw e;
            }
        }
    }
    async function fetch(endpoint: string, method: string, params: Object = {}) {
        try {
            const response = await api.request({
                url: endpoint,
                method: method,
                params: params
            });
            return response.data;
        } catch (e: any) {
            if (e.response && e.response.status === 401) {
                useAuthStore().setToken('')
                navigateTo(urlLogin)
            } else {
                throw e;
            }
        }
    }
    async function postData(endpoint: string, method: string, data: Object = {}) {
        try {
            const response = await api.request({
                url: endpoint,
                method: method,
                data: data,
                headers: {
                    Authorization: 'Bearer ' + useAuthStore().getToken(),
                    'Content-Type': 'multipart/form-data'
                }
            });
            if (response.data.code === 500) {
                throw (response.data.message.error_message);
            }
            return response;
        } catch (e: any) {
            if (e.response && e.response.status === 401) {
                useAuthStore().setToken('')
                navigateTo(urlLogin)
            }
            throw e;
        }
    }
    async function post(endpoint: string, method: string, data: Object = {}) {
        try {
            const response = await api.request({
                url: endpoint,
                method: method,
                data: data,
                headers: {
                    'Content-Type': 'multipart/form-data'
                }
            });
            return response;
        } catch (e: any) {
            if (e.response.status === 401) {
                useAuthStore().setToken('')
                navigateTo(urlLogin)
            }
            throw e;
        }
    }
    return {
        fetchData,
        fetch,
        postData,
        post
    }
}