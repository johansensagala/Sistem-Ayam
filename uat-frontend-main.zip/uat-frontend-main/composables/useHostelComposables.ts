export default function useHostelComposables() {
    const url = '/hostels'
    const core = useCoreComposables(url)
    const useBase = useBaseComposables()



    return {
        ...core,
    }
}