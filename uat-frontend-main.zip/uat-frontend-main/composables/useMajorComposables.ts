export default function useRoleComposables() {
    const url = '/majors'
    const core = useCoreComposables(url)
    const useBase = useBaseComposables()

    return {
        ...core,
    }
}