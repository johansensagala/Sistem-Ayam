export default function useParentStudentComposables() {
    const url = '/parents'
    const core = useCoreComposables(url)
    const useBase = useBaseComposables()

    return {
        ...core,
    }
}