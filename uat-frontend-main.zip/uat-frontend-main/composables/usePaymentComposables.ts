export default function useRoleComposables() {
    const url = '/payments'
    const core = useCoreComposables(url)
    const useBase = useBaseComposables()

    return {
        ...core,
    }
}