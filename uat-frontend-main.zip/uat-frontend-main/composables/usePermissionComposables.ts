export default function usePermisionComposables() {
    const url = '/permissions'
    const core = useCoreComposables(url)
    const useBase = useBaseComposables()

    return {
        ...core,
    }
}