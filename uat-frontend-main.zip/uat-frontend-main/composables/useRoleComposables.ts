export default function useRoleComposables() {
    const url = '/roles'
    const core = useCoreComposables(url)
    const useBase = useBaseComposables()

    return {
        ...core,
    }
}