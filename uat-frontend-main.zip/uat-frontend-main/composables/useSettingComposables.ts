export default function useSettingComposables() {
    const url = '/settings'
    const core = useCoreComposables(url)
    const useBase = useBaseComposables()



    return {
        ...core,
    }
}