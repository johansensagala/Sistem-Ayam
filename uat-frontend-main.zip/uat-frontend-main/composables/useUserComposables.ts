export default function useAuthComposables() {
    const url = '/users'
    const core = useCoreComposables(url)
    const useBase = useBaseComposables()

    async function postParentCode(form: Record<string, any>, id: Number) {
        try {
            const response = await core.postData(form, true, id, '/update-parent-code/')
            return response
        } catch (e: any) {
            throw e
        }
    }

    return {
        ...core,
        postParentCode
    }
}