<template>
    <div>
        <main>

            <Sidebar />
            <Navbar />
            <div class="pl-0 container pt-24 py-10 pb-[100px] w-full min-h-screen  bg-[#F2F6F9]" :class="leftPadding">
                <ModalPopUp />
                <ModalLoading :isLoading="isLoading" />
                <slot />

            </div>
            <div>
                <BottomNav />
                <div class="mt-[-3.5rem]">
                    <Footer class="" :class="leftPadding" />
                </div>
            </div>
        </main>
    </div>
</template>
<script setup>
const isLoading = computed(() => useWebStore().isLoading);
const leftPadding = 'lg:!pl-[293px]'
</script>