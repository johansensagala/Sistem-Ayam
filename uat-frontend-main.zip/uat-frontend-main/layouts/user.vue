<template>
    <ModalPopUp />
    <div class="grid grid-cols-12 min-h-screen">
        <div class="lg:col-span-7 lg:block hidden">
            <div class="bg-auth">
                <div class='flex justify-end'>
                    <img src="/assets/img/logo-white.png" alt="" />
                </div>
                <div class='flex justify-center items-center h-full'>
                    <img src="/assets/img/img-auth.png" alt="" />
                </div>
            </div>
        </div>
        <div class="lg:col-span-5 col-span-12 flex items-center">
            <slot />
        </div>
    </div>
</template>

