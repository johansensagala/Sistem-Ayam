// import { useAuthStore } from '@/store/authStore'

export default defineNuxtRouteMiddleware((to, from) => {
    const user = computed(() => useAuthStore().authUser)
    console.log('halo')
    try {
        // if (!user.value.status) {
        //     return navigateTo('/admin/dashboard', {
        //         replace: false
        //     });
        // }
    } catch (error) {
        // Tangani kesalahan jika terjadi saat dekode token
        console.error('Error decoding token:', error);
        return navigateTo('/login');
    }

})