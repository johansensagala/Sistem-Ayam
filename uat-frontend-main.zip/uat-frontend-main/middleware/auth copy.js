// import jwt from 'jsonwebtoken';

export default defineNuxtRouteMiddleware((to, from) => {
    const token = localStorage.getItem('authToken')

    function isTokenExpired(token) {
        const decodedToken = jwt.decode(token);
        if (!decodedToken) {
            return true; // Token tidak valid atau tidak ada
        }

        const currentTime = Math.floor(Date.now() / 1000); // Waktu saat ini dalam detik
        return decodedToken.exp < currentTime; // Mengembalikan true jika token sudah kedaluwarsa
    }

    if (token && isTokenExpired(token)) {
        return navigateTo('/login')
    }
})