// import { useAuthStore } from '@/store/authStore'

export default defineNuxtRouteMiddleware((to, from) => {
    const user = computed(() => useAuthStore().authUser)
    const authToken = localStorage.getItem('authToken')
    console.log('halo')
    if (authToken) {
        try {
            // Decode token untuk mendapatkan informasi waktu kedaluwarsa
            const tokenData = JSON.parse(atob(authToken.split('.')[1]));
            const tokenExpiration = tokenData.exp * 1000; // Konversi dari detik ke milidetik
            const currentTime = new Date().getTime();

            // Periksa apakah waktu kedaluwarsa token telah tercapai
            if (currentTime > tokenExpiration) {
                // Token telah kedaluwarsa, lakukan sesuai dengan kebutuhan aplikasi Anda
                // Misalnya, hapus token dan navigateTo ke halaman login
                localStorage.removeItem('authToken');
                return navigateTo('/login');
            }

            // if (!user.status) {
            //     return navigateTo('/register/confirmation');
            // }
        } catch (error) {
            // Tangani kesalahan jika terjadi saat dekode token
            console.error('Error decoding token:', error);
            return navigateTo('/login');
        }
    } else {
        // Tidak ada token, navigateTo ke halaman login
        return navigateTo('/login');
    }
})