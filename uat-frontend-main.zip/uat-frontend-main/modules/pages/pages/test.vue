<template>
    <NuxtLayout name="admin">
        <div>
            <h1 class="text-2xl font-bold mb-4 text-gray-700">Create Material</h1>
            <div class="grid grid-cols-12 gap-4">
                <div class="col-span-8 space-y-4">
                    <div class="flex gap-4 w-full">
                        <Card class="space-y-4 w-full">
                            <div class="flex w-full">
                                <div class="w-full">
                                    <Select select2 label="Material Category" text="Select Material Category"
                                        :search="dataMaterial.category_material_id" :data="dataCategoryMaterial.data"
                                        @update:search="dataMaterial.category_material_id = $event">
                                        <div class="self-end">
                                            <Modal @update:goFunction="handleCreateCategoryMaterial()" :buttonModal="false"
                                                width="!w-fit" :onModal="onModalCategoryMaterial" ref="myChild">
                                                <div class="space-y-2">
                                                    <Input label="Name Material Category" v-model="categoryMaterial.name"
                                                        :error="errorCategoryMaterial.name" />
                                                    <Select select2 label="Material Unit" text="Select Material Unit"
                                                        :data="dataUnit.data"
                                                        @update:search="categoryMaterial.unit_id = $event"
                                                        :search="categoryMaterial.unit_id"
                                                        :error="errorCategoryMaterial.unit_id">
                                                        <div class="self-end">
                                                            <Modal @update:goFunction="handleCreateUnit()"
                                                                :buttonModal="false" width="!w-fit" :onModal="onModalUnit"
                                                                ref="myChild">
                                                                <Input label="Name Unit" v-model="unit.name"
                                                                    :error="errorUnit.name" />
                                                            </Modal>
                                                        </div>
                                                    </Select>
                                                </div>
                                            </Modal>
                                        </div>
                                    </Select>
                                </div>
                            </div>
                        </Card>

                    </div>
                    <Card height="h-fit">
                        <p class="mb-4">Variant Material</p>
                        <Modal label="Create Variant" @update:goFunction="handleCreateCategoryVariantMaterial()"
                            width="!w-fit" :onModal="onModalCategoryVariant">
                            <Input label="Name Variant" v-model="categoryVariantMaterial.name" />
                        </Modal>
                        <div>
                            <div class="grid grid-cols-12 gap-6 mt-4">
                                <div class="col-span-4" v-for="(cvMaterial, cvIndex) in dataCategoryVariantMaterial.data">
                                    <p class="font-semibold">{{ cvMaterial.name }}</p>
                                    <div class="mt-2">
                                        <Select select2 :data="cvMaterial.entry_variant_materials"
                                            :text="`Choose ${cvMaterial.name}`"
                                            @update:search="handleRadio(cvMaterial.id, $event)"
                                            :search="checkEntry(cvMaterial.entry_variant_materials, dataMaterial.variant)">
                                            <Modal @update:goFunction="handleCreateEvm(cvMaterial.id)" :buttonModal="false"
                                                width="!w-fit" :onModal="onModalEvm[cvMaterial.id]" ref="myChild">
                                                <div>
                                                    <label for="">Nama {{ cvMaterial.name }}</label>
                                                    <input class="form-control w-full mt-2"
                                                        :value="formEvNames[cvMaterial.id]"
                                                        @input="updateFormName(cvMaterial.id, $event.target.value)" />
                                                </div>
                                            </Modal>
                                        </Select>
                                    </div>
                                    <!-- <div v-for="(evMaterial, index) in cvMaterial.entry_variant_materials"
                                    @click="handleRadio(cvIndex, evMaterial.id)" id="check" class="">
                                    <Input type="radio" :label="evMaterial.name" :value="evMaterial.id"
                                        v-model="variantMaterial[cvIndex]" :id="`input-ev-${evMaterial.name}`" />
                                </div> -->

                                    <!-- <form @submit.prevent="handleCreateEvm(cvMaterial.id)"
                                    class="flex items-center space-x-2 mt-2">
                                    <div class="grow">
                                        <div class="w-full">
                                            <input class="form-control w-full " :value="formEvNames[cvMaterial.id]"
                                                @input="updateFormName(cvMaterial.id, $event.target.value)" />
                                        </div>
                                    </div>
                                    <button :disabled="disabledCv[cvMaterial.id] ?? true"
                                        class='w-10 h-10 flex justify-center items-center bg-primary rounded text-white cursor-pointer flex-none disabled:bg-gray-400 disabled:cursor-default'>
                                        <i class='fas fa-plus'></i>
                                    </button>
                                </form> -->
                                </div>
                            </div>
                        </div>
                    </Card>
                </div>
                <div class="col-span-4 space-y-4">
                    <Card height="h-fit">
                        <Button @click="handleCreateMaterial()">Submit</Button>
                    </Card>
                    <Card height="h-fit">
                        <p class="mb-4">Price</p>
                        <input class="form-control w-full" v-model="price" @input="validateInput($event.target.value)"
                            type="text">
                    </Card>
                </div>
            </div>
        </div>
    </NuxtLayout>
</template>

<script setup>
import debounce from 'lodash.debounce'
import initSaldo from '@/utils/currency'
definePageMeta({
    layout: false,
})
const route = useRoute()

const { data: dataEditedMaterial, fetchComponentMaterial, postData: postDataMaterial, findData: findDataMaterial } = useMaterialComposables()

const { data: dataCategoryMaterial, fetchData: fetchCategoryMaterial, postData: postCategoryMaterial, error: errorCategoryMaterial } = useCategoryMaterialComposables()

const { data: dataCategoryVariantMaterial, fetchData: fetchCategoryVariantMaterial, postData: postCategoryVariantMaterial, error: errorCategoryVariantMaterial } = useCategoryVariantMaterialComposables()

const { data: dataEvm, fetchData: fetchEvm, postData: postEvm } = useEntryVariantMaterialComposables()

const { data: dataUnit, fetchData: fetchUnit, postData: postUnit, error: errorUnit } = useUnitComposables()

const emit = defineEmits()

const categoryMaterial = ref({
    name: '',
    unit_id: ''
})
const categoryVariantMaterial = ref({
    name: ''
})


const formEv2 = ref([
    {
        name: '',
        category_variant_material_id: ''
    }
]);

const formEv = ref([
    {
        name: '',
        category_variant_material_id: ''
    }
]);

const dataMaterial = ref({
    category_material_id: '',
    price: '',
    variant: []
})

const variantMaterial = ref([])

const onModalCategoryMaterial = ref(false)
const onModalCategoryVariant = ref(false)
const onModalUnit = ref(false)
const onModalEvm = ref([])


const initPrice = ref(0)
const price = ref(0)

const disabledCv = ref([])

const formEvNames = computed(() => {
    return formEv.value.map(item => item.name);
});

const updateFormName = debounce((index, value) => {
    disabledCv.value[index] = true
    if (!formEv.value[index]) {
        formEv.value[index] = {
            name: '',
            category_variant_material_id: ''
        }
    }
    formEv.value[index].name = value;
    disabledCv.value[index] = false;
    if (formEv.value[index].name == '') {
        disabledCv.value[index] = true;
    }
    console.log(formEv.value);

}, 500);



const validateInput = (value) => {
    initPrice.value = value.replace(/\D/g, '')
    dataMaterial.value.price = initPrice.value
    if (value == '') {
        price.value = 0
    } else {
        price.value = initSaldo(initPrice.value)
    }
};

const getMaterial = async () => {
    try {
        useWebStore().onLoading()
        const response = await fetchComponentMaterial();
        dataCategoryMaterial.value.data = response.data.categoryMaterial
        dataCategoryVariantMaterial.value.data = response.data.categoryVariant
        useWebStore().offLoading()
    } catch (e) {
        console.log(e)
        useWebStore().offLoading()
    }
}

const getUnit = async () => {
    useWebStore().onLoading()
    await fetchUnit(1, 0)
    useWebStore().offLoading()
}

const getCategoryMaterial = async () => {
    useWebStore().onLoading()
    await fetchCategoryMaterial(1, 0)
    useWebStore().offLoading()
}

const getCategoryVariant = async () => {
    useWebStore().onLoading()
    await fetchCategoryVariantMaterial(1, 0)
    useWebStore().offLoading()
}



const getEditedDataMaterial = async () => {
    try {
        useWebStore().onLoading()
        await findDataMaterial(route.params.id)
        const response = dataEditedMaterial.value.data
        dataMaterial.value.unit_id = response.unit_id
        dataMaterial.value.category_material_id = response.category_material_id
        dataMaterial.value.price = response.price
        dataMaterial.value.variant = response.entry_materials
        // console.log(dataMaterial.value)
        price.value = initSaldo(response.price)
        useWebStore().offLoading()
    } catch (e) {
        console.log(e)
    }
}

const checkEntry = (initData, checkData) => {
    for (const item1 of initData) {
        for (const item2 of checkData) {
            if (item1.id === item2.id) {
                console.log(item1.id)
                return item1.id;
            } else {
                return;
            }
        }
    }
    // const ids1 = initData.map(item => item.id);
    // const ids2 = checkData.map(item => item.id);
    // const commonIds = ids1.filter(id => ids2.includes(id));
    // console.log(commonIds)
    // return commonIds
    // checkData.forEach((value, index) => {
    //     console.log(value)
    //     console.log(initData)
    // })
    // const checkEv = initData.find(
    //     (item) =>
    // )
}

const handleRadio = (index, value) => {
    if (variantMaterial.value[index] === value) {
        variantMaterial.value[index] = null
    } else {
        variantMaterial.value[index] = value
    }
    console.log(value)
}

const handleCreateMaterial = async () => {
    try {
        useWebStore().onLoading()
        dataMaterial.value.variant = [...variantMaterial.value]
        if (!route.params.id) {
            await postDataMaterial(dataMaterial.value)
        } else {
            await postDataMaterial(dataMaterial.value, true, route.params.id)
        }
        useWebStore().offLoading()
        useWebStore().onPopUp('success', 'Data has Created', 'Success')
        navigateTo('/admin/material')
    } catch (e) {
        console.log(e)
        if (!e.response) {
            useWebStore().onPopUp('failed', e, 'Failed')
        }
        useWebStore().offLoading()
    }
}

const handleCreateEvm = async (id) => {
    try {
        useWebStore().onLoading()
        formEv.value[id].category_variant_material_id = id
        await postEvm(formEv.value[id])
        formEv.value[id].category_variant_material_id = ''
        formEv.value[id].name = ''
        onModalEvm.value[id] = !onModalEvm.value[id]
        disabledCv.value[id] = true;
        console.log(formEv.value)
        await getCategoryVariant()
        useWebStore().offLoading()
        useWebStore().onPopUp('success', 'Data has Created', 'Success')
    } catch (e) {
        useWebStore().onPopUp('danger', 'Data must unique name', 'Error')
        useWebStore().offLoading()
    }
}

const handleCreateCategoryMaterial = async () => {
    try {
        useWebStore().onLoading()
        await postCategoryMaterial(categoryMaterial.value)
        getCategoryMaterial()
        useWebStore().offLoading()
        onModalCategoryMaterial.value = !onModalCategoryMaterial.value
        categoryMaterial.value.name = ''
        categoryMaterial.value.unit_id = ''
        useWebStore().onPopUp('success', 'Data has Created', 'Success')
    } catch (e) {
        useWebStore().offLoading()
    }
}

const handleCreateCategoryVariantMaterial = async () => {
    try {
        useWebStore().onLoading()
        await postCategoryVariantMaterial(categoryVariantMaterial.value)
        getCategoryVariant()
        useWebStore().offLoading()
        onModalCategoryVariant.value = !onModalCategoryVariant.value
        categoryVariantMaterial.value.name = ''
        useWebStore().onPopUp('success', 'Data has Created', 'Success')
    } catch (e) {
        useWebStore().offLoading()
    }
}

onMounted(() => {
    if (route.params.slug == 'create') {
        if (route.params.id) {
            navigateTo('/admin/dashboard')
        }
    }
    if (route.params.slug == 'edit') {
        getEditedDataMaterial()
        if (!route.params.id) {
            navigateTo('/admin/dashboard')
        }
    }
    getMaterial()
    getUnit()
})
</script>