import { createResolver } from "nuxt/kit"
// https://nuxt.com/docs/api/configuration/nuxt-config
export default defineNuxtConfig({
  ssr: false,
  plugins: [
    // '~/plugins/tooltip.js'
  ],
  devtools: {
    enabled: false,

    // timeline: {
    //   enabled: true,
    // },
  },
  modules: [
    '@nuxtjs/tailwindcss',
    '@pinia/nuxt',
    // '~/modules/pages/index',
  ],
  css: ["@/assets/scss/main.scss"],
  components: [
    {
      path: '~/components',
      pathPrefix: false,
    },
  ],
  imports: {
    dirs: [
      'composables',
      'composables/*/index.{ts,js,mjs,mts}',
      'composables/**',
      'stores',
      'stores/*/index.{ts,js,mjs,mts}',
      'stores/**'
    ]
  },
  generate: { fallback: true },
  routeRules: {
    '/': { redirect: '/login' },
    '/admin': { redirect: '/admin/dashboard' },
  },

})