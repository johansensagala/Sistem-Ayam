<script>
export default {
    asyncData({ redirect }) {
        return redirect('/')
    }
}
</script>