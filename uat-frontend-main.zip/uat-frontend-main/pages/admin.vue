

<template>
    <!-- <NuxtPage></NuxtPage> -->

    <NuxtLayout name="admin">
        <NuxtPage></NuxtPage>
    </NuxtLayout>
</template>

<script setup>

definePageMeta({
    middleware: 'auth'
})
</script>

