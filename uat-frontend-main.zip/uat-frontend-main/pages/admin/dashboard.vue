<template>
    <Card class="bg-slate-50">
        <div v-if="roleUser == 'parent'">
            <DashboardParent />
        </div>
        <div v-if="roleUser == 'superadmin'">
            <DashboardAdmin />
        </div>
        <div v-if="roleUser == 'student'">
            <DashboardStudent />
        </div>
    </Card>
</template>

<script setup>
const roleUser = computed(() => useAuthStore().getUser().roles[0].name)
</script>