<template>
    <FormHostel />
</template>