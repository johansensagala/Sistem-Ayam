<template>
    <div>
        <h1 class="text-2xl font-bold mb-4 text-gray-700">List {{ title }}</h1>
        <div class="grid grid-cols-12 gap-4">
            <div class="col-span-4">
                <Card height="w-fit">
                    <div class="space-y-3">
                        <div>
                            <Input label="Nama Jurusan" v-model="form.name" :error="error.name" />
                            <div class="flex w-full mt-2">
                                <div class="w-full">
                                    <Select select2 label="Fakultas" text="Select Fakultas" :data="facultyData.data" wSlot
                                        @update:search="form.faculty_id = $event" :search="form.faculty_id"
                                        :error="error.faculty_id">
                                        <div class="self-end">
                                            <Modal @update:goFunction="handleCreateFaculty()" :buttonModal="false"
                                                width="!w-fit" :onModal="onModal" ref="myChild">
                                                <Input label="Nama Fakultas" v-model="faculty.name"
                                                    :error="errorFaculty.name" />
                                            </Modal>
                                        </div>
                                    </Select>
                                </div>
                            </div>
                        </div>
                        <Button @click="handleSubmit()">Save</Button>
                    </div>
                </Card>
            </div>
            <div class="col-span-8">
                <Card>
                    <BasicTable :headers="headers" :fetch-function="fetchData" :trash-function="fetchTrash"
                        :rows="data.data" withOutTrashed :typeAction="typeAction" :trashed="trashed" :total-items="total"
                        @showData="handleShow($event)" @editData="handleEdit($event)" @deleteData="handleDelete($event)"
                        @forceDelete="handleForce($event)" @restore="handleRestore($event)" loadFilter wAction="10%" />
                </Card>
            </div>
        </div>
    </div>
</template>

<script setup>

const { data, postData, fetchData, findData, total, deleteData, fetchTrash, forceDelete, restoreData, error } = useMajorComposables()

const { data: facultyData, postData: postFaculty, fetchData: fetchFaculty, error: errorFaculty } = useFacultyComposables()

const trashed = ref(false)
const url = '/admin/majors/'
const title = 'Jurusan'

const selectId = ref(null)
const edit = ref(false)

const onModal = ref(false)

const form = ref({
    name: '',
    faculty_id: ''
})

const faculty = ref({
    name: ''
})

// const permission = ref({})

const headers = [
    { head: 'Name', name: 'name', filter: true },
    { head: 'Fakultas', name: 'faculty.name', filter: true },
]

const typeAction = [
    { label: 'fas fa-pencil-alt', type: 'icon', eventName: 'editData', bg: '' },
    { label: 'fas fa-trash', type: 'icon', eventName: 'deleteData', bg: 'bg-red-500' },
    { label: 'fas fa-water', type: 'icon', eventName: 'restore', bg: '', trash: true },
    { label: 'fas fa-trash', type: 'icon', eventName: 'forceDelete', bg: 'bg-red-500', trash: true },
]

const handleEdit = (id) => {
    selectId.value = id
    edit.value = true
    const checkData = data.value.data.find(
        (item) => item.id == selectId.value
    )
    if (checkData) {
        form.value.name = checkData.name
        form.value.faculty_id = checkData.faculty_id
    }

}
const handleShow = (id) => {
    navigateTo(url + 'show/' + id)
}

const handleForce = async (id) => {
    try {
        useWebStore().onLoading()
        await forceDelete(id)
        await fetchTrash()
        useWebStore().offLoading()
        useWebStore().onPopUp('success', 'Data has Delete', 'Success')
    } catch (e) {
        console.log(e)
        useWebStore().offLoading()
    }
}

const handleRestore = async (id) => {
    try {
        useWebStore().onLoading()
        await restoreData(id)
        await fetchTrash()
        useWebStore().offLoading()
        useWebStore().onPopUp('success', 'Data has Restore', 'Success')
    } catch (e) {
        console.log(e)
        useWebStore().offLoading()
    }
}

const handleDelete = async (id) => {
    try {
        useWebStore().onLoading()
        await deleteData(id)
        await fetchData()
        useWebStore().offLoading()
        useWebStore().onPopUp('success', 'Data has Delete', 'Success')
    } catch (e) {
        console.log(e)
        useWebStore().offLoading()
    }
}

const getFaculty = async () => {
    try {
        useWebStore().onLoading()
        await fetchFaculty(1, 0)
        console.log(facultyData.value.data)
        useWebStore().offLoading()
    } catch (e) {
        console.log(e)
        useWebStore().offLoading()
    }
}

const handleCreateFaculty = async () => {
    try {
        useWebStore().onLoading()
        await postFaculty(faculty.value)
        onModal.value = !onModal.value
        useWebStore().onPopUp('success', 'Data has Created', 'Success')
        await fetchFaculty(1, 0)
        useWebStore().offLoading()
    } catch (e) {
        console.log(e)
        useWebStore().offLoading()
    }
}

const handleSubmit = async () => {
    try {
        useWebStore().onLoading()
        if (!edit.value) {
            await postData(form.value)
            form.value.name = ''
            form.value.faculty_id = ''
        } else {
            await postData(form.value, true, selectId.value)
            edit.value = false
            form.value.name = ''
            selectId.value = ''
        }
        await fetchData()
        useWebStore().offLoading()
    } catch (e) {
        console.log(e)
        useWebStore().offLoading()
    }
}



onMounted(() => {
    getFaculty()
})
</script>