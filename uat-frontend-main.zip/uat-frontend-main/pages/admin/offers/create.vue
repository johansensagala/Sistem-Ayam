<template>
    <div>
        <FormOffer />
    </div>
</template>