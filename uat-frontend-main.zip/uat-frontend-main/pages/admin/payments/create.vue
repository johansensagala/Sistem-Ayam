<template>
    <div>
        <FormPayment />
    </div>
</template>