<template>
    <div>
        <h1 class="text-2xl font-bold mb-4 text-gray-700">Pembayaran</h1>
        <Card v-if="!isLoading">
            <ShowData label="Tempat tinggal" :value="`${dataPayment.offer.sks}`" />
            <ShowData label="Tempat tinggal" :value="`${dataPayment.offer.residence_id ? 'Inside' : 'Outside'}`" />
            <ShowData label="Total Pembayaran" :value="`Rp. ${initSaldo(dataPayment.total)}`" />
            <ShowData label="Status" :value="`${dataPayment.status}`" />
            <ShowData label="Due Date" :value="`${formatToDate(dataPayment.due_date)}`" />
        </Card>
        <Card>
            <p>Upload Bukti Pembayaran</p>
            <div class="grid grid-cols-12">
                <div class="col-span-3" :class="[roleUser == 'superadmin' ? 'pointer-events-none' : '']">
                    <ImageUpload v-model="form.image" @update:imageInput="form.image = $event" :imageData="imageData"
                        :error="error.image" />
                </div>
            </div>
            <div class="mt-2">
                <div class="flex space-x-4">
                    <div>
                        <Button @click="handleUpdatePayment()">
                            Submit
                        </Button>
                    </div>
                    <div v-if="roleUser == 'superadmin'">
                        <Button backgroundColor="bg-red-500" @click="handleUpdatePayment2()">
                            Cancel
                        </Button>
                    </div>
                </div>
            </div>
        </Card>
    </div>
</template>
<script setup>
import { formatToWIB, formatToDate } from '@/utils/dateTime';
import initSaldo from '@/utils/currency'
const { data: dataPayment, findData: findPayment, fetchData: fetchPayment, error, postData: postPatyment } = usePaymentComposables()
const roleUser = computed(() => useAuthStore().getUser().roles[0].name)
const isLoading = ref(true)
const imageData = ref(null)
// const dataPay = ref([])
const form = ref({
    image: ''
})
const handleUpdatePayment = async () => {
    try {
        useWebStore().onLoading()
        if (roleUser.value == 'superadmin') {
            form.value.role = 'superadmin'
        } else {
            form.value.role = 'student'
        }
        await postPatyment(form.value, true, useRoute().params.id)
        await getData()
        navigateTo('/admin/payments')
        useWebStore().offLoading()
    } catch (e) {
        console.log(e)
        useWebStore().offLoading()
    }
}
const handleUpdatePayment2 = async () => {
    try {
        useWebStore().onLoading()
        if (roleUser.value == 'superadmin') {
            form.value.role = 'superadmin'
        } else {
            form.value.role = 'student'
        }
        form.value.status = 'CANCEL'
        // await postPatyment(form.value, true, useRoute().params.id)
        // await getData()
        navigateTo('/admin/payments')
        useWebStore().offLoading()
    } catch (e) {
        console.log(e)
        useWebStore().offLoading()
    }
}
const getData = async () => {
    try {
        useWebStore().onLoading()
        await findPayment(useRoute().params.id)
        dataPayment.value = dataPayment.value.data
        imageData.value = dataPayment.value.image
        isLoading.value = false
        useWebStore().offLoading()
    } catch (e) {
        console.log(e)
        useWebStore().offLoading()
    }
}
onMounted(() => {
    getData()
})
</script>