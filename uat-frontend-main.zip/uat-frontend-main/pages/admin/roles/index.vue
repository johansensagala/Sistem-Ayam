<template>
    <div>
        <h1 class="text-2xl font-bold mb-4 text-gray-700">List {{ title }}</h1>
        <div class="grid grid-cols-12 gap-4">
            <div class="col-span-4">
                <Card height="w-fit">
                    <div class="space-y-3">
                        <div>
                            <Input label="Nama Role" v-model="form.name" :error="error.name" />
                        </div>
                        <Button @click="handleSubmit()">Save</Button>
                    </div>
                </Card>
            </div>
            <div class="col-span-8">
                <Card>
                    <BasicTable :headers="headers" :fetch-function="fetchData" :trash-function="fetchTrash"
                        :rows="data.data" :typeAction="typeAction" :trashed="trashed" :total-items="total"
                        @showData="handleShow($event)" @editData="handleEdit($event)" @deleteData="handleDelete($event)"
                        @forceDelete="handleForce($event)" @restore="handleRestore($event)" loadFilter wAction="10%" />
                </Card>
            </div>
        </div>
    </div>
</template>

<script setup>

const { data, postData, fetchData, findData, total, deleteData, fetchTrash, forceDelete, restoreData, error } = useRoleComposables()

const trashed = ref(false)
const url = '/admin/roles/'
const title = 'Roles'

const form = ref({
    name: ''
})

const permission = ref({})

const selectId = ref(null)
const edit = ref(false)

const headers = [
    { head: 'Name', name: 'name', filter: true },
]

const typeAction = [
    { label: 'fas fa-pencil-alt', type: 'icon', eventName: 'editData', bg: '' },
    { label: 'fas fa-trash', type: 'icon', eventName: 'deleteData', bg: 'bg-red-500' },
    { label: 'fas fa-water', type: 'icon', eventName: 'restore', bg: '', trash: true },
    { label: 'fas fa-trash', type: 'icon', eventName: 'forceDelete', bg: 'bg-red-500', trash: true },
]

const handleEdit = (id) => {
    selectId.value = id
    edit.value = true
    const checkData = data.value.data.find(
        (item) => item.id == selectId.value
    )
    if (checkData) {
        form.value.name = checkData.name
    }
}
const handleShow = (id) => {
    navigateTo(url + 'show/' + id)
}

const handleForce = async (id) => {
    try {
        useWebStore().onLoading()
        await forceDelete(id)
        await fetchTrash()
        useWebStore().offLoading()
        useWebStore().onPopUp('success', 'Data has Delete', 'Success')
    } catch (e) {
        console.log(e)
        useWebStore().offLoading()
    }
}

const handleRestore = async (id) => {
    try {
        useWebStore().onLoading()
        await restoreData(id)
        await fetchTrash()
        useWebStore().offLoading()
        useWebStore().onPopUp('success', 'Data has Restore', 'Success')
    } catch (e) {
        console.log(e)
        useWebStore().offLoading()
    }
}

const handleDelete = async (id) => {
    try {
        useWebStore().onLoading()
        await deleteData(id)
        await fetchData()
        useWebStore().offLoading()
        useWebStore().onPopUp('success', 'Data has Delete', 'Success')
    } catch (e) {
        console.log(e)
        useWebStore().offLoading()
    }
}

const handleSubmit = async () => {
    try {
        useWebStore().onLoading()
        if (!edit.value) {
            await postData(form.value)
        } else {
            await postData(form.value, true, selectId.value)
            edit.value = false
            form.value.name = ''
            selectId.value = ''
        }
        await fetchData()
        useWebStore().offLoading()
    } catch (e) {
        console.log(e)
        useWebStore().offLoading()
    }
}

onMounted(() => {

})
</script>