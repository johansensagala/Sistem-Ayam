<template>
    <div>
        <h1 class="text-2xl font-bold mb-4 text-gray-700">Setting</h1>
        <Card>
            <div class="space-y-3">
                <!-- <Input label="Harga Fix" v-model="form.price_fix" /> -->
                <!-- <Input label="Harga SKS" v-model="form.price_sks" /> -->
                <div>
                    <label for="">Harga Fix</label>
                    <input class="form-control w-full" v-model="price" @input="validateInput($event.target.value)"
                        type="text">
                </div>
                <div>
                    <label for="">Harga Sks</label>
                    <input class="form-control w-full" v-model="price2" @input="validateInput2($event.target.value)"
                        type="text">
                </div>

            </div>
            <div class="mt-4">
                <Button @click="handleSubmit()" width="w-fit">Submit</Button>
            </div>
        </Card>
    </div>
</template>
<script setup>
import initSaldo from '@/utils/currency'
const { data, findData, postData } = useSettingComposables()
const form = ref({
    price_fix: '',
    price_sks: ''
})
const price = ref(0)
const initPrice = ref(0)
const price2 = ref(0)
const initPrice2 = ref(0)

const validateInput = (value) => {
    initPrice.value = value.replace(/\D/g, '')
    if (value == '') {
        price.value = 0
    } else {
        price.value = initSaldo(initPrice.value)
        form.value.price_fix = initPrice.value
    }
};
const validateInput2 = (value) => {
    initPrice2.value = value.replace(/\D/g, '')
    if (value == '') {
        price2.value = 0
    } else {
        price2.value = initSaldo(initPrice2.value)
        form.value.price_sks = initPrice2.value
    }
};

const getData = async () => {
    try {
        useWebStore().onLoading()
        await findData(1)
        form.value = {
            price_fix: data.value.data.price_fix,
            price_sks: data.value.data.price_sks
        }
        price.value = initSaldo(data.value.data.price_fix)
        price2.value = initSaldo(data.value.data.price_sks)
        useWebStore().offLoading()
    } catch (e) {
        console.log(e)
        useWebStore().offLoading()
    }
}

const handleSubmit = async () => {
    try {
        useWebStore().onLoading()
        await postData(form.value, true, 1)
        await getData()
        useWebStore().onPopUp('success', 'Data has Update', 'Success')
        useWebStore().offLoading()
    } catch (e) {
        console.log(e)
        useWebStore().offLoading()
    }
}

onMounted(() => {
    getData()
})
</script>