<template>
    <div>
        <FormUser />
    </div>
</template>