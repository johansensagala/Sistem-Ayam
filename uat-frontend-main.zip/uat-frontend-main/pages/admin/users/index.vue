<template>
    <div>
        <h1 class="text-2xl font-bold mb-4 text-gray-700">List {{ title }}</h1>
        <Button width="w-fit" className="mb-4" type="link" :link="`${url}create`">Buat {{ title }}</Button>
        <Card>
            <BasicTable :headers="headers" :fetch-function="fetchData" :trash-function="fetchTrash" :rows="data.data"
                :typeAction="typeAction" :trashed="trashed" :total-items="total" @showData="handleShow($event)"
                @editData="handleEdit($event)" @deleteData="handleDelete($event)" @forceDelete="handleForce($event)"
                @restore="handleRestore($event)" loadFilter wAction="10%" />
        </Card>
    </div>
</template>

<script setup>

const { data, fetchData, findData, total, deleteData, fetchTrash, forceDelete, restoreData } = useUserComposables()

const trashed = ref(false)
const url = '/admin/users/'
const title = 'User'

const headers = [

    { head: 'Name', name: 'name', filter: true },
    { head: 'Username', name: 'username', filter: true },
    { head: 'Role', name: 'roles', array: true, first: true, textArray: 'name' },
]

const typeAction = [
    { label: 'fas fa-pencil-alt', type: 'icon', eventName: 'editData', bg: '' },
    { label: 'fas fa-trash', type: 'icon', eventName: 'deleteData', bg: 'bg-red-500' },
    { label: 'fas fa-water', type: 'icon', eventName: 'restore', bg: '', trash: true },
    { label: 'fas fa-trash', type: 'icon', eventName: 'forceDelete', bg: 'bg-red-500', trash: true },
]

const handleEdit = (id) => {
    navigateTo(url + 'edit/' + id)
}
const handleShow = (id) => {
    navigateTo(url + 'show/' + id)
}

const handleForce = async (id) => {
    try {
        useWebStore().onLoading()
        await forceDelete(id)
        await fetchTrash()
        useWebStore().offLoading()
        useWebStore().onPopUp('success', 'Data has Delete', 'Success')
    } catch (e) {
        console.log(e)
        useWebStore().offLoading()
    }
}

const handleRestore = async (id) => {
    try {
        useWebStore().onLoading()
        await restoreData(id)
        await fetchTrash()
        useWebStore().offLoading()
        useWebStore().onPopUp('success', 'Data has Restore', 'Success')
    } catch (e) {
        console.log(e)
        useWebStore().offLoading()
    }
}

const handleDelete = async (id) => {
    try {
        useWebStore().onLoading()
        await deleteData(id)
        await fetchData()
        useWebStore().offLoading()
        useWebStore().onPopUp('success', 'Data has Delete', 'Success')
    } catch (e) {
        console.log(e)
        useWebStore().offLoading()
    }
}
</script>