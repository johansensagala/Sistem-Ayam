<template>
    <div class="w-full">
        <div v-if="error.init" class="w-full flex justify-center">
            <div class="absolute bg-red-500 text-white px-4 py-2 rounded top-5">
                {{ error.init }}
            </div>
        </div>
        <div class="flex justify-center items-center h-full">
            <div class="flex flex-col w-full max-w-md lg:max-w-[20rem]">
                <h1 class="text-3xl text-gray-700 mb-8 font-bold text-center">Welcome to<br> Convection App</h1>
                <form @submit.prevent="handleSubmit()" class="flex flex-col space-y-4">
                    <Input id="username" label="Username" v-model="form.username" :error="error.username" />
                    <Input type="password" id="password" label="Password" v-model="form.password" :error="error.password" />
                    <div class="flex items-center">
                        <div class="flex">
                            <input id="remember-me" v-model="form.remember" type="checkbox"
                                class="shrink-0 mt-0.5 border-gray-200 rounded text-primary  focus:ring-primary dark:bg-bgdark dark:border-white/10 dark:checked:bg-primary dark:checked:border-primary dark:focus:ring-offset-white/10" />
                        </div>
                        <div class="ml-4">
                            <label htmlFor="remember-me" class="text-sm cursor-pointer">Remember
                                me
                            </label>
                        </div>
                    </div>
                    <Button>
                        <p v-if="isLoading">Loading ...</p>
                        <p v-else>Login</p>
                    </Button>
                    <div>
                        <p>Belum punya akun? <NuxtLink to="register" class="hover:text-primary hover:underline">Daftar
                                disini</NuxtLink>
                        </p>
                    </div>
                </form>
            </div>
        </div>
    </div>
</template>

<script setup>
const { handleLogin, error, initError } = useAuthComposables()
const isLoading = computed(() => useWebStore().isLoading);
const form = ref({
    username: '',
    password: '',
    remember: false
})
const handleSubmit = async () => {
    useWebStore().onLoading()
    try {
        console.log(form.value)
        await handleLogin(form.value)
        useWebStore().offLoading()

    } catch (e) {
        console.log(e)
        console.log(error.value)
        useWebStore().offLoading()

    }
}
</script>