

<template>
    <!-- <NuxtPage></NuxtPage> -->

    <NuxtLayout :name="layout">
        <NuxtPage></NuxtPage>
    </NuxtLayout>
</template>

<script setup>
const layout = "user";
definePageMeta({
    // middleware: 'guest'
})
</script>

