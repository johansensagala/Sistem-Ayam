<template>
    <div class="w-full">
        <div class="flex justify-center items-center h-full">
            <div class="flex flex-col w-full max-w-md lg:max-w-[20rem]">
                <h1 class="text-3xl text-gray-700 mb-8 font-bold text-center">
                    Konfirmasi Akun
                </h1>
            </div>
            <div>
                <Buton @clikc="handleLogout()">
                    Logout
                </Buton>
            </div>
        </div>
    </div>
</template>
<script setup>

</script>