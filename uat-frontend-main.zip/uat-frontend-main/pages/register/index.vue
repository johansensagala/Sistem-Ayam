<template>
    <div class="w-full">
        <div v-if="error.init" class="relative w-full flex justify-center">
            <div class="absolute bg-red-500 text-white px-4 py-2 rounded top-5">
                {{ error.init }}
            </div>
        </div>
        <div class="flex justify-center items-center h-full">
            <div class="flex flex-col w-full max-w-md lg:max-w-[20rem]">
                <h1 class="text-3xl text-gray-700 mb-8 font-bold text-center">
                    Daftar Orang Tua
                </h1>
                <form @submit.prevent="handleSubmit()" class="flex flex-col space-y-4">
                    <Input id="name" label="name" v-model="form.name" :error="error.name" />
                    <Input id="username" label="username" v-model="form.username" :error="error.username" />
                    <Input id="phone" label="phone" v-model="form.phone" :error="error.phone" />
                    <Input type="password" id="password" label="Password" v-model="form.password" :error="error.password" />
                    <Button>
                        <p v-if="isLoading">Loading ...</p>
                        <p v-else>Register</p>
                    </Button>
                    <div>
                        <p>Sudah punya akun? <NuxtLink to="login" class="hover:text-primary hover:underline">Masuk
                                disini</NuxtLink>
                        </p>
                    </div>
                </form>
            </div>
        </div>
    </div>
</template>

<script setup>
const { handleRegister, error, initError } = useAuthComposables()
const isLoading = computed(() => useWebStore().isLoading);
const form = ref({
    username: '',
    name: '',
    password: '',
    phone: '',
    remember: false
})
const handleSubmit = async () => {
    useWebStore().onLoading()
    try {
        console.log(form.value)
        await handleRegister(form.value)
        useWebStore().offLoading()

    } catch (e) {
        console.log(e)
        console.log(error.value)
        useWebStore().offLoading()

    }
}
</script>