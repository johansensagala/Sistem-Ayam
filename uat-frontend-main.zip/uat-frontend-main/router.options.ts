import type { RouterConfig } from '@nuxt/schema'

export default <RouterConfig>{
    // https://router.vuejs.org/api/interfaces/routeroptions.html#routes
    // routes: (_routes) => [
    //     {
    //         name: 'home',
    //         path: '/admin/material/edit/:id',
    //         component: () => import('@/pages/admin/material/create.vue')
    //     }
    // ],
}
