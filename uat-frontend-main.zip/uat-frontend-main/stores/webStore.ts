import { defineStore } from 'pinia';

export const useWebStore = defineStore('webStore', {
    state: () => ({
        popUpOpen: false,
        textPopUp: '',
        titlePopUp: '',
        iconPopUp: '',
        isLoading: false,
    }),
    actions: {
        togglePopUp() {
            this.popUpOpen = !this.popUpOpen;
        },
        onPopUp(icon: string, text: string, titlePopUp: string) {
            this.iconPopUp = icon
            this.textPopUp = text
            this.titlePopUp = titlePopUp
            this.popUpOpen = true
        },
        offPopUp() {
            this.popUpOpen = false
        },
        toogleLoading() {
            this.isLoading = !this.isLoading
        },
        onLoading() {
            this.isLoading = true
        },
        offLoading() {
            this.isLoading = false
        },
    },
});
