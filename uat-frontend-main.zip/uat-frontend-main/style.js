const init = {
    primary: '#7257ff',
    light: '#E2E2EC'
}

const Style = {
    primary: init.primary,
    dark: '#1e1a37',
    light: init.light,
    formBg: '#232e48',
    buttonBg: '#E2E2EC',
    buttonText: init.primary,
    navBg: init.light
}
export default Style

