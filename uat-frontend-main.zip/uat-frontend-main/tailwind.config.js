/** @type {import('tailwindcss').Config} */
import Style from './style'

export default {
  content: [
    'node_modules/flowbite-vue/**/*.{js,jsx,ts,tsx,vue}',
    'node_modules/flowbite/**/*.{js,jsx,ts,tsx}'
  ],
  corePlugins: {
    container: false
  },
  theme: {
    extend: {
      colors: {
        primary: Style.primary,
        dark: Style.dark,
        formBg: Style.formBg,
        buttonBg: Style.buttonBg,
        buttonText: Style.buttonText,
        navBg: Style.navBg,
        light: Style.light
      },
    },
  },
  plugins: [
    require('flowbite/plugin')
  ],
}

