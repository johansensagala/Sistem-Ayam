

<template>
  <div>
    <div class="flex justify-between">
      <div class="flex items-end">
        <i class=" text-[12px]">Show {{ perPage ?? 0 }} from {{ totalItems ?? 0 }} data</i>
      </div>
      <input type="text" v-model="searchQuery.name" @input="$event.target.composing = false" class="form-control w-48 "
        placeholder="Cari data..." />
    </div>
    <table class="w-full text-normal table-style-1 mt-2">
      <thead>
        <tr>
          <th width="5%" class="text-center">No</th>
          <th :width="header.width" v-for="(header, index) in headers" :key="index">{{ header.head }}</th>
          <th v-if="typeAction.length !== 0">Action</th>
        </tr>
      </thead>
      <tbody>
        <tr v-if="rows.length > 0" v-for="( row, rowIndex ) in  rowsWithIndexes " :key="rowIndex">
          <td class=" text-center">{{ row.rowIndex }}</td>
          <td v-for="( header, headerIndex ) in  headers " :key="headerIndex">
            {{ row[header.name] }}
          </td>
          <td v-if="typeAction.length !== 0" v-for="( action, index ) in  typeAction " class="flex justify-center">
            <button @click="$emit(action.eventName, row.id)" class="p-2 bg-primary rounded text-white">{{ action.label
            }}</button>
          </td>
        </tr>
        <tr v-else>
          <td :colspan="headers.length + 2" class="bg-gray-100 text-center"> data tidak ada</td>
        </tr>
      </tbody>
    </table>
    <div class="flex mt-4">
      <Paginate :current-page="currentPageInit" :total-items="totalItems" :per-page="perPage"
        @update:current-page="currentPageInit = $event" />
    </div>
  </div>
</template>

<script setup>
import { watch, ref } from 'vue'

let rowsWithIndexes = ref([])

const searchQuery = ref({
  name: "",
});

const emit = defineEmits()

const props = defineProps({
  headers: {
    type: Array,
    default: () => []
  },
  rows: {
    type: Array,
    default: () => []
  },
  typeAction: {
    type: Array,
    default: () => []
  },
  currentPage: {
    type: Number,
    default: 1
  },
  perPage: {
    type: [String, Number],
    default: 5
  },
  totalItems: {
    type: Number,
    default: 0
  },
  fetchFunction: {
    type: Function,
    default: null
  }
})

const getRowIndex = (index) => {
  const startIndex = (currentPageInit.value - 1) * props.perPage
  return startIndex + index + 1
}

rowsWithIndexes.value = props.rows.map((row, index) => {
  return {
    ...row,
    rowIndex: getRowIndex(index) // Inisialisasi rowIndex untuk setiap objek row
  }
})

watch(() => props.rows, (newRows) => {
  console.log(props.rows)
  rowsWithIndexes.value = newRows.map((row, index) => {
    return {
      ...row,
      rowIndex: getRowIndex(index) // Inisialisasi rowIndex untuk setiap objek row yang baru
    }
  })
})

const currentPageInit = ref(props.currentPage)

watch(currentPageInit, (newPage) => {
  emit("update:currentPage", newPage);
});

watch(searchQuery.value, (newQuery) => {
  emit('update:updateQuery', newQuery)
})


</script>
