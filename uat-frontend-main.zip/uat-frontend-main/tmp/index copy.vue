<template>
    <Card>
        <BasicTable :headers="headers" :rows="data.data" :total-items="total" :per-page="pageSize"
            :current-page="currentPage" @update:current-page="currentPage = $event"
            @update:update-query="handleFilter($event, true)" />
    </Card>
</template>

<script setup>
import debounce from 'lodash.debounce'
const { data, fetchData, total } = useUserComposables()
const currentPage = ref(1);
const pageSize = ref("5");
const initWatch = ref(false);
const checkLoading = ref(true)

const getData = async () => {
    useWebStore().onLoading()
    await fetchData(currentPage.value, pageSize.value)
    initWatch.value = true
    useWebStore().offLoading()
}

const queryParams = computed(() => useFilterStore().queryParams)
const sortParams = computed(() => useFilterStore().sortParams)
const handleFilter = (goFilter, wl = null) => {
    if (wl) {
        checkLoading.value = false
    } else {
        checkLoading.value = true
    }
    useFilterStore().handleFilter(goFilter)
}
const headers = [
    { head: 'Username', name: 'username' }
]

const delayedFetchData = debounce(() => {
    getData()
}, 500);

watch([currentPage, pageSize, queryParams, sortParams], () => {
    if (initWatch.value == true) {
        delayedFetchData()
    }
})

onMounted(() => {
    useWebStore().onLoading()
    getData()
})
</script>