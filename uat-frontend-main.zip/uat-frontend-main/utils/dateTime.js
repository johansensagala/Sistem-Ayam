import moment from 'moment-timezone';

function formatToWIB(isoTime) {
    // Mengonversi waktu ke zona waktu Indonesia (WIB)
    const indonesiaTime = moment(isoTime).tz('Asia/Jakarta');
    // Format waktu sesuai preferensi
    return indonesiaTime.format('YYYY-MM-DD HH:mm:ss');
}
function formatToDate(isoTime) {
    // Mengonversi waktu ke zona waktu Indonesia (WIB)
    const indonesiaTime = moment(isoTime).tz('Asia/Jakarta');
    // Format waktu sesuai preferensi
    return indonesiaTime.format('YYYY-MM-DD ');
}

export { formatToWIB, formatToDate }
